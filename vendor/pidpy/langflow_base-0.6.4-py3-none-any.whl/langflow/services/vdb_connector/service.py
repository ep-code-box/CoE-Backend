import asyncio
from abc import ABC, abstractmethod
from typing import Optional

from chromadb import AsyncHttpClient, CloudClient, HttpClient
from chromadb.config import Settings
from pymilvus import Collection, AsyncMilvusClient
from qdrant_client import AsyncQdrantClient

from langflow.services.database.models.data_asset_vdb.model import (
    VDBConnectionConf,
)
from langflow.services.database.models.datasource.constants import DataAssetType


class VDBMetadata:
    """Class to hold metadata information about a vector database table."""

    def __init__(
        self,
        collection_name: str,
        n_dimensions: Optional[int] = None,
        distance_metric: Optional[str] = None,
        n_rows: Optional[int] = None,
        embedding_model: Optional[str] = None,
    ):
        self.collection_name = collection_name
        self.n_dimensions = n_dimensions
        self.distance_metric = distance_metric
        self.n_rows = n_rows
        self.embedding_model = embedding_model

    def to_dict(self):
        """Convert metadata to dictionary format."""
        return {
            "collection_name": self.collection_name,
            "n_dimensions": self.n_dimensions,
            "distance_metric": self.distance_metric,
            "n_rows": self.n_rows,
            "embedding_model": self.embedding_model,
        }


class VDBConnectorService(ABC):
    """Abstract base class for vector database connector services."""
    
    def __init__(self, connection: VDBConnectionConf):
        self.connection = connection
        self.client = None
    
    @abstractmethod
    async def connect(self):
        """Establish a connection to the VDB."""
        pass

    @abstractmethod
    async def disconnect(self):
        """Close the connection to the VDB."""
        pass

    @abstractmethod
    async def list_tables(self) -> list[str]:
        """List all collections/indexes/tables in the VDB."""
        pass

    @abstractmethod
    async def get_table_metadata(self, table_name: str) -> VDBMetadata:
        """Retrieve metadata about a specific table in the VDB."""
        pass
    

class ChromaConnectorService(VDBConnectorService): # DANGER: blocking client used in async code
    """Service for connecting to ChromaDB."""
    
    async def connect(self):
        """Establish a connection to ChromaDB."""
        def _sync_create_client():
            if self.connection.host and self.connection.port:
                return HttpClient(
                    host=self.connection.host,
                    port=int(self.connection.port),
                    settings=Settings(
                        chroma_client_auth_provider="chromadb.auth.token_authn.TokenAuthClientProvider",
                        chroma_client_auth_credentials=self.connection.api_key or "_",
                        chroma_auth_token_transport_header="Authorization",
                    ),
                )
            else:
                return CloudClient(
                    database=self.connection.database_name,
                    api_key=self.connection.api_key,
                    tenant=self.connection.tenant_id
                )
        # if self.connection.host and self.connection.port:
            # self.client = await AsyncHttpClient(
            #     host=self.connection.host,
            #     port=self.connection.port,
            #     database=self.connection.database_name,
            #     tenant=self.connection.tenant_id,
            #     headers={
            #         "Authorization": f"Bearer {self.connection.api_key}"
            #     }
            # )
        self.client = await asyncio.to_thread(_sync_create_client)
    
    async def disconnect(self):
        """Close the connection to ChromaDB."""
        if self.client:
            # ChromaDB async client doesn't have an explicit close method
            self.client = None
    
    async def list_tables(self) -> list[str]:
        """List all collections in ChromaDB."""
        if not self.client:
            await self.connect()
        
        def _sync_list_collections():
            return self.client.list_collections()

        collections = await asyncio.to_thread(_sync_list_collections)
        return [collection.name for collection in collections]
    
    async def get_table_metadata(self, table_name: str) -> VDBMetadata:
        """Retrieve metadata about a specific collection in ChromaDB."""
        if not self.client:
            await self.connect()
        
        def _sync_get_collection():
            return self.client.get_collection(table_name)

        collection = await asyncio.to_thread(_sync_get_collection)
        count = collection.count()
        
        # Get collection metadata
        metadata = collection.metadata or {}
        
        # Get vector dimensions by fetching a sample record
        n_dimensions = None
        if count > 0:
            try:
                result = collection.get(limit=1, include=["embeddings"])
                if result and result.get("embeddings") and len(result["embeddings"]) > 0:
                    n_dimensions = len(result["embeddings"][0])
            except Exception:
                pass
         
        return VDBMetadata(
            collection_name=table_name,
            n_dimensions=n_dimensions,
            distance_metric=metadata.get("hnsw:space"),
            n_rows=count,
            embedding_model=metadata.get("embedding_model"),
        )


class MilvusConnectorService(VDBConnectorService):
    """Service for connecting to Milvus."""
    
    async def connect(self):
        """Establish a connection to Milvus."""
        # Use AsyncMilvusClient which supports async operations
        self.client = AsyncMilvusClient(
            uri=self.connection.uri,
            token=self.connection.api_key,
            db_name=self.connection.database_name
        )
    
    async def disconnect(self):
        """Close the connection to Milvus."""
        if self.client:
            await self.client.close()
            self.client = None
    
    async def list_tables(self) -> list[str]:
        """List all collections in Milvus."""
        if not self.client:
            await self.connect()
        
        return await self.client.list_collections()

    async def describe_collection(self, collection_name: str) -> dict:
        """Return the raw describe_collection dict for the given collection."""
        if not self.client:
            await self.connect()

        return await self.client.describe_collection(collection_name)
    
    async def get_table_metadata(self, table_name: str) -> VDBMetadata:
        """Retrieve metadata about a specific collection in Milvus."""
        if not self.client:
            await self.connect()
        
        # Get collection description which includes schema and stats
        collection_info = await self.client.describe_collection(table_name)
        
        # Get collection stats
        stats = await self.client.get_collection_stats(table_name)
        num_entities = stats.get('row_count', 0)
        
        # Get schema information (AsyncMilvusClient returns fields at top level)
        fields = collection_info.get('fields', [])
        
        vector_field = None
        for field in fields:
            if field.get('type') in ['FLOAT_VECTOR', 'BINARY_VECTOR']:
                vector_field = field
                break
        
        n_dimensions = None
        if vector_field:
            params = vector_field.get('params', {})
            n_dimensions = params.get('dim')
        
        # Get distance metric from index
        distance_metric = None
        try:
            indexes = await self.client.list_indexes(table_name)
            if indexes:
                index_info = await self.client.describe_index(table_name, indexes[0])
                distance_metric = index_info.get('metric_type')
        except Exception:
            pass
        
        return VDBMetadata(
            collection_name=table_name,
            n_dimensions=n_dimensions,
            distance_metric=distance_metric,
            n_rows=num_entities,
            embedding_model=None,  # Milvus doesn't store embedding model info
        )


class QdrantConnectorService(VDBConnectorService):
    """Service for connecting to Qdrant."""
    
    async def connect(self):
        """Establish a connection to Qdrant."""
        if self.connection.host:
            self.client = AsyncQdrantClient(
                host=self.connection.host, 
                port=self.connection.port,
                api_key=self.connection.api_key
            )
        else:
            self.client = AsyncQdrantClient(
                url=self.connection.uri,
                api_key=self.connection.api_key
            )
    
    async def disconnect(self):
        """Close the connection to Qdrant."""
        if self.client:
            await self.client.close()
            self.client = None
    
    async def list_tables(self) -> list[str]:
        """List all collections in Qdrant."""
        if not self.client:
            await self.connect()
        
        collections = await self.client.get_collections()
        return [collection.name for collection in collections.collections]
    
    async def get_table_metadata(self, table_name: str) -> VDBMetadata:
        """Retrieve metadata about a specific collection in Qdrant."""
        if not self.client:
            await self.connect()
        
        collection_info = await self.client.get_collection(table_name)
        
        # Get vector configuration
        config = collection_info.config
        vector_size = None
        distance_metric = None
        
        if config.params and config.params.vectors:
            # Handle both dict and VectorParams cases
            if isinstance(config.params.vectors, dict):
                # Multiple named vectors
                first_vector = next(iter(config.params.vectors.values()))
                vector_size = first_vector.size
                distance_metric = first_vector.distance.name if first_vector.distance else None
            else:
                # Single unnamed vector
                vector_size = config.params.vectors.size
                distance_metric = config.params.vectors.distance.name if config.params.vectors.distance else None
        
        # Get point count
        point_count = collection_info.points_count
        
        return VDBMetadata(
            collection_name=table_name,
            n_dimensions=vector_size,
            distance_metric=distance_metric,
            n_rows=point_count,
            embedding_model=None,  # Qdrant doesn't store embedding model info
        )


def get_vdb_connector(vdb_type: DataAssetType, connection: VDBConnectionConf) -> VDBConnectorService:
    """Factory function to get the appropriate VDB connector service."""    
    if vdb_type == DataAssetType.CHROMADB:
        return ChromaConnectorService(connection)
    elif vdb_type == DataAssetType.MILVUS:
        return MilvusConnectorService(connection)
    elif vdb_type == DataAssetType.QDRANT:
        return QdrantConnectorService(connection)
    else:
        raise ValueError(f"Unsupported VDB type: {vdb_type}")
