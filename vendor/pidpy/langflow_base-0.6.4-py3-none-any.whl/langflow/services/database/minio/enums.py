"""
Define all enums in minio.
"""

class MinioEnv:
    """
    Enum for MinIO environment variables.
    """

    MINIO_ENDPOINT = "MINIO_ENDPOINT"
    MINIO_ACCESS_KEY = "MINIO_ACCESS_KEY"
    MINIO_SECRET_KEY = "MINIO_SECRET_KEY"
    MINIO_STORAGE_USE_HTTPS = "MINIO_STORAGE_USE_HTTPS"
    MINIO_HOST = "MINIO_HOST"
    MINIO_PORT = "MINIO_PORT"


class MinioBucket:
    """
    Enum for MinIO bucket names.
    """

    LANGFLOW = "langflow"