"""
Define all connection to minio.
"""
import os
import time

from minio import Minio
from minio.error import S3Error
from .enums import MinioEnv, MinioBucket


import logging
import sys
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Avoid adding duplicate handlers if module is reloaded
if not logger.handlers:
    _handler = logging.StreamHandler(sys.stdout)  # Force output to stdout
    _handler.setLevel(logging.INFO)
    _formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - [%(threadName)s] - %(message)s'
    )
    _handler.setFormatter(_formatter)
    logger.addHandler(_handler)

# Ensure propagation is enabled (so root logger also sees it if configured)
logger.propagate = True


def get_minio_connection() -> Minio:
    """
    Get a connection to the MinIO server.

    Returns:
        A MinIO client instance.
    """

    host = os.environ.get(MinioEnv.MINIO_HOST, "localhost")
    port = os.environ.get(MinioEnv.MINIO_PORT, "9010")
    endpoint = f"{host}:{port}"
    access_key = os.environ.get(MinioEnv.MINIO_ACCESS_KEY)
    secret_key = os.environ.get(MinioEnv.MINIO_SECRET_KEY)
    secure = os.environ.get(MinioEnv.MINIO_STORAGE_USE_HTTPS, "false").lower() == "true"
    logger.info(f"MinIO connection parameters - Endpoint: {endpoint}, Secure: {secure}")
    cnt = 0
    while cnt < 5:
        try:
            minio_client = Minio(
                endpoint=endpoint,
                access_key=access_key,
                secret_key=secret_key,
                secure=secure,
            )
            # Check if the connection is successful by listing buckets

            # get or create bucket
            if not minio_client.bucket_exists(MinioBucket.LANGFLOW):
                minio_client.make_bucket(MinioBucket.LANGFLOW)
                logger.info(f"Created MinIO bucket: {MinioBucket.LANGFLOW}")
            break
        except S3Error as e:
            logger.info(f"Attempt {cnt + 1}: Failed to connect to MinIO server: {str(e)}")
            time.sleep(5)  # Wait for 5 seconds before retrying
            cnt += 1

    return minio_client

