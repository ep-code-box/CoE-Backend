import asyncio
from uuid import UUID
import re
from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError, OperationalError, DatabaseError
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy import create_engine, MetaData
from .model import DatasourceRdb, DatasourceRdbUpdate
from langflow.services.database.models.datasource.constants import DatasourceRDB


def parse_database_error(error: Exception, datasource_type: str) -> str:
    """
    Parse database connection errors into user-friendly messages.
    
    Args:
        error: The exception that occurred
        datasource_type: The type of database being connected to (MySQL, PostgreSQL, etc.)
    
    Returns:
        A user-friendly error message
    """
    error_str = str(error)
    error_lower = error_str.lower()
    
    # Check for specific error patterns and return friendly messages
    
    # DNS/Hostname resolution errors
    if "temporary failure in name resolution" in error_lower or "nodename nor servname provided" in error_lower:
        # Extract hostname if possible
        hostname_match = re.search(r"on '([^']+)'", error_str)
        hostname = hostname_match.group(1) if hostname_match else "the specified host"
        return f"Unable to resolve hostname '{hostname}'. Please verify the host address is correct and accessible."
    
    # Connection refused
    if "connection refused" in error_lower or "can't connect" in error_lower:
        return f"Connection refused by the {datasource_type} server. Please verify:\n• The server is running\n• The host and port are correct\n• Firewall rules allow the connection"
    
    # Timeout errors
    if "timeout" in error_lower or "timed out" in error_lower:
        return f"Connection to {datasource_type} server timed out. Please check:\n• Network connectivity\n• Server is responding\n• No firewall blocking the connection"
    
    # Authentication errors
    if "access denied" in error_lower or "authentication failed" in error_lower or "password authentication failed" in error_lower:
        return f"Authentication failed. Please verify:\n• Username is correct\n• Password is correct\n• User has permission to access the database"
    
    # Database not found
    if "unknown database" in error_lower or "database" in error_lower and "does not exist" in error_lower:
        db_match = re.search(r"database['\"]?\s*['\"]?([^'\"]+)", error_str, re.IGNORECASE)
        db_name = db_match.group(1) if db_match else "specified"
        return f"Database '{db_name}' not found. Please verify the database name is correct."
    
    # SSL/TLS errors
    if "ssl" in error_lower or "tls" in error_lower:
        return f"SSL/TLS connection error. Please check SSL configuration and certificates."
    
    # Wrong database type (protocol mismatch)
    if "protocol" in error_lower or "packet" in error_lower or "handshake" in error_lower:
        return f"Protocol error detected. Please verify:\n• The datasource type ({datasource_type}) matches the actual database server\n• Server version is compatible"
    
    # Port errors
    if "port" in error_lower and ("invalid" in error_lower or "must be" in error_lower):
        return f"Invalid port number. Please specify a valid port (1-65535)."
    
    # Network errors
    if "network" in error_lower or "host is unreachable" in error_lower:
        return f"Network error: Unable to reach the database server. Please check network connectivity."
    
    # Generic connection error - try to extract useful info
    if "operational" in error_lower or "can't connect" in error_lower:
        # Try to extract error code
        code_match = re.search(r"\((\d+),", error_str)
        if code_match:
            error_code = code_match.group(1)
            return f"Connection failed (Error {error_code}). Please verify all connection parameters are correct."
        return f"Unable to connect to {datasource_type} database. Please verify all connection parameters (host, port, username, password, database name)."
    
    # If no specific pattern matched, return a cleaned up version
    # Remove technical stack traces and keep only the main error message
    if "Background on this error at:" in error_str:
        error_str = error_str.split("Background on this error at:")[0].strip()
    
    # Extract just the error message without the exception type prefix
    if error_str.startswith("("):
        # Format: (ExceptionType) (code, "message")
        msg_match = re.search(r'"\s*([^"]+)\s*"', error_str)
        if msg_match:
            return f"Connection error: {msg_match.group(1)}"
    
    # Fallback: return cleaned error
    return f"Connection failed: {error_str[:200]}"  # Limit length


async def get_datasource_rdb_by_datasource_id(db: AsyncSession, datasource_id: UUID) -> DatasourceRdb | None:
    if isinstance(datasource_id, str):
        datasource_id = UUID(datasource_id)
    stmt = select(DatasourceRdb).where(DatasourceRdb.datasource_id == datasource_id)
    return (await db.exec(stmt)).first()


async def update_datasource_rdb(rdb_db: DatasourceRdb | None, rdb_data: DatasourceRdbUpdate,
                                db: AsyncSession) -> DatasourceRdb:
    if not rdb_db:
        raise HTTPException(status_code=404, detail="DatasourceRdb not found")

    rdb_update_data = rdb_data.model_dump(exclude_unset=True)
    changed = False
    for attr, value in rdb_update_data.items():
        if hasattr(rdb_db, attr) and value is not None:
            setattr(rdb_db, attr, value)
            changed = True

    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")

    try:
        await db.commit()
        await db.refresh(rdb_db)
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return rdb_db


def _sync_connect(connection_info):
    """
    Synchronous blocking DB connection — intended to be run via asyncio.to_thread.
    Creates engine, opens connection, and reflects metadata.
    """
    ENGINE_CONNECT_ARGS = {
        "connect_timeout": 30,  # 30 seconds timeout for initial connection
    }

    ENGINE_OPTIONS = {
        "pool_pre_ping": True,  # Verify connections before using them
        "pool_recycle": 3600,   # Recycle connections after 1 hour
        "pool_size": 1,         # Minimal pool size for test connections
        "max_overflow": 0,      # No overflow connections for tests
        "pool_timeout": 5,      # 5 seconds timeout when getting connection from pool
    }

    engine = None
    conn = None
    try:
        if connection_info["type"].lower() == DatasourceRDB.POSTGRESQL.value.lower():
            engine = create_engine(
                f'postgresql://{connection_info["username"]}:{connection_info["password"]}@{connection_info["host"]}:{connection_info["port"]}/{connection_info["database_name"]}',
                connect_args=ENGINE_CONNECT_ARGS,
                **ENGINE_OPTIONS
            )
            conn = engine.connect()
            metadata = MetaData()
            with conn.execution_options(timeout=10):
                metadata.reflect(bind=conn)
        elif connection_info["type"].lower() == DatasourceRDB.ORACLE.value.lower():
            engine = create_engine(
                f'oracle+oracledb://{connection_info["username"]}:{connection_info["password"]}@{connection_info["host"]}:{connection_info["port"]}/?service_name={connection_info["database_name"]}',
                connect_args=ENGINE_CONNECT_ARGS,
                **ENGINE_OPTIONS
            )
            conn = engine.connect()
            metadata = MetaData()
            with conn.execution_options(timeout=10):
                metadata.reflect(bind=conn)
        elif connection_info["type"].lower() == DatasourceRDB.MYSQL.value.lower() or connection_info["type"].lower() == DatasourceRDB.MARIA_DB.value.lower():
            mysql_connect_args = {
                "connect_timeout": 10,
                "read_timeout": 10,
                "write_timeout": 10,
            }
            engine = create_engine(
                f'mysql+pymysql://{connection_info["username"]}:{connection_info["password"]}@{connection_info["host"]}:{connection_info["port"]}/{connection_info["database_name"]}',
                connect_args=mysql_connect_args,
                **ENGINE_OPTIONS
            )
            conn = engine.connect()
            metadata = MetaData()
            with conn.execution_options(timeout=10):
                metadata.reflect(bind=conn)
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported datasource type for connection test: {type}"
            )
    except Exception as e:
        if conn:
            conn.close()
        if engine:
            engine.dispose()
        wrapper_message = parse_database_error(e, connection_info.get("type", "database"))
        raise HTTPException(
            status_code=400,
            detail=wrapper_message
        ) from e

    return engine, conn, metadata


async def rdb_perform_connect(session, datasource_id, datasource_type, connection_config):
    """
    Connect to RDB. Blocking engine/connection work is offloaded to a thread
    via asyncio.to_thread so the event loop is not blocked.
    """
    connection_info = await get_rdb_connection_config(session, datasource_id, datasource_type, connection_config)
    return await asyncio.to_thread(_sync_connect, connection_info)


async def get_rdb_connection_config(session, datasource_id, datasource_type, connection_config):
    if datasource_id:
        config = await get_datasource_rdb_by_datasource_id(session, datasource_id)
        if not config:
            raise HTTPException(status_code=404, detail="RDB configuration not found")
        
        return {
            "type": datasource_type,
            "host": config.host,
            "port": config.port,
            "database_name": config.database_name,
            "username": config.username,
            "password": config.password
        }
        
    else:
        if not all([datasource_type, connection_config]):
            raise HTTPException(
                status_code=400, 
                detail="Connection test requires connection type and configuration"
            )
            
        return {
            "type": datasource_type.value,
            "host": connection_config.get("host"),
            "port": connection_config.get("port"),
            "database_name": connection_config.get("database_name"),
            "username": connection_config.get("username"),
            "password": connection_config.get("password")
        }
