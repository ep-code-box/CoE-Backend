from urllib.parse import quote_plus
from typing import Optional

from langflow.services.database.models.datasource.constants import DatasourceRDB


# Mapping of datasource types to their SQLAlchemy driver names
RDB_DRIVER_MAPPING = {
    DatasourceRDB.POSTGRESQL: "postgresql",
    DatasourceRDB.MYSQL: "mysql",
    DatasourceRDB.MARIA_DB: "mysql",  # MariaDB uses MySQL driver
    DatasourceRDB.ORACLE: "oracle",
}

# Default ports for each database type
RDB_DEFAULT_PORTS = {
    DatasourceRDB.POSTGRESQL: 5432,
    DatasourceRDB.MYSQL: 3306,
    DatasourceRDB.MARIA_DB: 3306,
    DatasourceRDB.ORACLE: 1521,
}


def build_database_url(
    host: str,
    port: int,
    database_name: str,
    username: str,
    password: str,
    driver: str = "postgresql",
    dialect: Optional[str] = None,
) -> str:
    """
    Build a database connection URL from individual components.
    
    Args:
        host: Database host address
        port: Database port number
        database_name: Name of the database
        username: Database username
        password: Database password
        driver: Database driver (default: "postgresql")
        dialect: Optional dialect (e.g., "psycopg2", "asyncpg")
    
    Returns:
        A formatted database URL string
        
    Examples:
        >>> build_database_url("127.0.0.1", 5432, "dummy", "postgres", "123456")
        'postgresql://postgres:123456@127.0.0.1:5432/dummy'
        
        >>> build_database_url("localhost", 3306, "mydb", "user", "p@ss", "mysql")
        'mysql://user:p%40ss@localhost:3306/mydb'
        
        >>> build_database_url("localhost", 5432, "db", "user", "pass", "postgresql", "asyncpg")
        'postgresql+asyncpg://user:pass@localhost:5432/db'
    """
    # URL-encode the password to handle special characters
    encoded_password = quote_plus(password)
    
    # Build the driver string with optional dialect
    driver_string = f"{driver}+{dialect}" if dialect else driver
    
    # Build and return the complete URL
    return f"{driver_string}://{username}:{encoded_password}@{host}:{port}/{database_name}"


def get_database_url_from_rdb(rdb_instance, driver: str = "postgresql", dialect: Optional[str] = None) -> str:
    """
    Get a database URL from a DatasourceRdb instance.
    
    Args:
        rdb_instance: A DatasourceRdb instance or similar object with connection fields
        driver: Database driver (default: "postgresql")
        dialect: Optional dialect (e.g., "psycopg2", "asyncpg")
    
    Returns:
        A formatted database URL string
        
    Example:
        >>> rdb = DatasourceRdb(host="127.0.0.1", port=5432, ...)
        >>> get_database_url_from_rdb(rdb)
        'postgresql://postgres:123456@127.0.0.1:5432/dummy'
    """
    return build_database_url(
        host=rdb_instance.host,
        port=rdb_instance.port,
        database_name=rdb_instance.database_name,
        username=rdb_instance.username,
        password=rdb_instance.password,
        driver=driver,
        dialect=dialect,
    )


def build_database_url_from_type(
    datasource_type: DatasourceRDB | str,
    host: str,
    port: int,
    database_name: str,
    username: str,
    password: str,
    dialect: Optional[str] = None,
) -> str:
    """
    Build a database connection URL using the datasource type to auto-detect the driver.
    
    Args:
        datasource_type: DatasourceRDB enum value or string (e.g., "PostgreSQL", "MySQL")
        host: Database host address
        port: Database port number
        database_name: Name of the database
        username: Database username
        password: Database password
        dialect: Optional dialect (e.g., "psycopg2", "asyncpg", "pymysql")
    
    Returns:
        A formatted database URL string
        
    Examples:
        >>> build_database_url_from_type(DatasourceRDB.POSTGRESQL, "127.0.0.1", 5432, "dummy", "postgres", "123456")
        'postgresql://postgres:123456@127.0.0.1:5432/dummy'
        
        >>> build_database_url_from_type("MySQL", "localhost", 3306, "mydb", "user", "pass")
        'mysql://user:pass@localhost:3306/mydb'
        
        >>> build_database_url_from_type(DatasourceRDB.POSTGRESQL, "localhost", 5432, "db", "user", "pass", "asyncpg")
        'postgresql+asyncpg://user:pass@localhost:5432/db'
    """
    # Convert string to enum if needed
    if isinstance(datasource_type, str):
        try:
            datasource_type = DatasourceRDB(datasource_type)
        except ValueError:
            raise ValueError(
                f"Unsupported datasource type: {datasource_type}. "
                f"Supported types: {[e.value for e in DatasourceRDB]}"
            )
    
    # Get the driver for this datasource type
    driver = RDB_DRIVER_MAPPING.get(datasource_type)
    if not driver:
        raise ValueError(
            f"No driver mapping found for datasource type: {datasource_type.value}. "
            f"Supported types: {[e.value for e in RDB_DRIVER_MAPPING.keys()]}"
        )
    
    return build_database_url(
        host=host,
        port=port,
        database_name=database_name,
        username=username,
        password=password,
        driver=driver,
        dialect=dialect,
    )
