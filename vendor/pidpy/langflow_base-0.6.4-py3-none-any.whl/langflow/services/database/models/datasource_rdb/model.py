from uuid import uuid4
from typing import Optional, TYPE_CHECKING, Any

from sqlmodel import Field, SQLModel, Relationship, Column
from sqlalchemy import JSON

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.datasource.model import Datasource

class DatasourceRdb(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    datasource_id: UUIDstr = Field(foreign_key="datasource.id", nullable=False, unique=True)
    host: str = Field(nullable=False)
    port: int = Field(nullable=False)
    database_name: str = Field(nullable=False)
    username: str = Field(nullable=False)
    password: str = Field(nullable=False)
    schema_stored_value: Optional[dict[str, Any]] = Field(default=None, sa_column=Column(JSON, nullable=True))
    
    # Relationship to Datasource
    datasource: Optional["Datasource"] = Relationship(back_populates="rdb_config")


class DatasourceRdbCreate(SQLModel):
    datasource_id: UUIDstr = Field()
    host: str = Field()
    port: int = Field()
    database_name: str = Field()
    username: str = Field()
    password: str = Field()
    schema_stored_value: Optional[dict[str, Any]] = Field(default=None, nullable=True)


class DatasourceRdbRead(SQLModel):
    id: UUIDstr = Field()
    datasource_id: UUIDstr = Field()
    host: str = Field()
    port: int = Field()
    database_name: str = Field()
    username: str = Field()
    password: str = Field()
    schema_stored_value: Optional[dict[str, Any]] = Field(default=None, nullable=True)


class DatasourceRdbUpdate(SQLModel):
    datasource_id: Optional[UUIDstr] | None = None
    host: Optional[str] | None = None
    port: Optional[int] | None = None
    database_name: Optional[str] | None = None
    username: Optional[str] | None = None
    password: Optional[str] | None = None
    schema_stored_value: Optional[dict[str, Any]] | None = None
