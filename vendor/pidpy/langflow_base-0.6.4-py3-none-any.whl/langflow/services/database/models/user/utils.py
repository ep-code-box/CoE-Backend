from langflow.services.database.models.user_role.crud import get_user_role_by_id, get_user_role_by_name
from langflow.services.database.models.user_role.constants import DEFAULT_MEMBER_ROLE_NAME, DEFAULT_ADMIN_ROLE_NAME

async def get_user_role_and_admin_permission(session, request_role_id):
    if not request_role_id:
        default_member_role = await get_user_role_by_name(session, DEFAULT_MEMBER_ROLE_NAME)
        role_id = default_member_role.id
        is_superuser = False
    else:
        role_id = request_role_id
        role_obj = await get_user_role_by_id(session, request_role_id)
        is_superuser = (role_obj.name == DEFAULT_ADMIN_ROLE_NAME)

        return role_id, is_superuser


def prepare_user_dict_response(user):
    user_dict = user.model_dump()
    user_group = user.user_groups[0] if (user.user_groups and len(user.user_groups) > 0) else None
    user_dict["group_name"] = user_group.group.name if user_group else None
    user_dict["group_id"] = user_group.group_id if user_group else None
    user_dict["join_group_at"] = user_group.joined_at if user_group else None
    user_dict["role_name"] = user.role.name if user.role else None
    return user_dict