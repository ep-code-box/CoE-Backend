import re
from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException, status
from lfx.log.logger import logger
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.user.model import User, UserUpdate
from langflow.services.database.models.user_group.model import UserGroup
from langflow.services.database.models.group.utils import get_default_group


async def get_user_by_username(db: AsyncSession, username: str) -> User | None:
    stmt = select(User).where(User.username == username)
    return (await db.exec(stmt)).first()


async def get_user_by_email(db: AsyncSession, email: str) -> User | None:
    stmt = select(User).where(User.email == email)
    return (await db.exec(stmt)).first()


async def get_user_by_id(db: AsyncSession, user_id: UUID) -> User | None:
    if isinstance(user_id, str):
        user_id = UUID(user_id)
    stmt = select(User).where(User.id == user_id).options(
        selectinload(User.user_groups).selectinload(UserGroup.group),
        selectinload(User.role)
    )
    return (await db.exec(stmt)).first()


async def update_user(user_db: User | None, user: UserUpdate, db: AsyncSession, group_updated=None) -> User:
    if not user_db:
        raise HTTPException(status_code=404, detail="User not found")

    # user_db_by_username = get_user_by_username(db, user.username)
    # if user_db_by_username and user_db_by_username.id != user_id:
    #     raise HTTPException(status_code=409, detail="Username already exists")

    user_data = user.model_dump(exclude_unset=True)
    changed = False
    for attr, value in user_data.items():
        if hasattr(user_db, attr) and value is not None:
            current_value = getattr(user_db, attr)
            if current_value != value:
                setattr(user_db, attr, value)
                changed = True

    if not changed and not group_updated:
        raise HTTPException(status_code=304, detail="Nothing to update")

    user_db.updated_at = datetime.now(timezone.utc)
    user_db.update_search_field()
    flag_modified(user_db, "updated_at")

    try:
        await db.commit()
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return user_db


async def update_user_last_login_at(user_id: UUID, db: AsyncSession) -> User | None:
    try:
        user = await get_user_by_id(db, user_id)
        if not user:
            await logger.aerror(f"User with id {user_id} not found")
            return None
        user_data = UserUpdate(last_login_at=datetime.now(timezone.utc))
        return await update_user(user, user_data, db)
    except HTTPException:
        raise
    except Exception as e:  # noqa: BLE001
        await logger.aerror(f"Error updating user last login at: {e!s}")
        return None


async def get_all_superusers(db: AsyncSession) -> list[User]:
    """Get all superuser accounts from the database."""
    stmt = select(User).where(User.is_superuser == True)  # noqa: E712
    result = await db.exec(stmt)
    return list(result.all())


async def user_add_default_group(session, current_user):
    default_group = await get_default_group(session)
    
    # Create user-group relationship
    user_group = UserGroup(
        user_id=current_user.id,
        group_id=default_group.id,
        is_group_admin=False,
        create_by=current_user.id
    )
    
    return user_group


def validate_user_info(request):
    if request.username:
        if " " in request.username or "\t" in request.username:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username cannot have spaces.",
            )

        if not 1 <= len(request.username) <= 50:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username must be between 1 and 50 characters long.",
            )

        if not re.match(r"^[a-zA-Z0-9]+$", request.username):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Username은 영문(a-z, A-Z)과 숫자(0-9)만 사용할 수 있습니다.",
            )
    
    if request.password:
        if " " in request.password or "\t" in request.password:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Password cannot have spaces.",
            )
        
        import re as _re
        if (
            len(request.password) < 8
            or not _re.search(r"[a-zA-Z]", request.password)
            or not _re.search(r"[0-9]", request.password)
            or not _re.search(r"[^a-zA-Z0-9]", request.password)
        ):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="비밀번호는 8자리 이상이며, 영문, 숫자, 특수문자를 조합하여 설정해 주세요.",
            )

    if request.email:
        email_regex = r"^[\w\.-]+@[\w\.-]+\.\w+$"
        if not re.match(email_regex, request.email):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid email format.",
            )
