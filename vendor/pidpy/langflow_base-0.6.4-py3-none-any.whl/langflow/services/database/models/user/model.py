from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel
from sqlalchemy import JSON, Boolean, Column, text
from sqlmodel import Field, Relationship, SQLModel

from langflow.schema.serialize import UUIDstr

from langflow.services.database.models.group.model import Group
if TYPE_CHECKING:
    from langflow.services.database.models.api_key.model import ApiKey
    from langflow.services.database.models.file.model import File
    from langflow.services.database.models.flow.model import Flow
    from langflow.services.database.models.folder.model import Folder
    from langflow.services.database.models.mcp.models import MCPServer
    from langflow.services.database.models.mcp_tools.models import MCPTool
    from langflow.services.database.models.variable.model import Variable
    from langflow.services.database.models.datasource.model import Datasource
    from langflow.services.database.models.user_group.model import UserGroup
    from langflow.services.database.models.user_role.model import UserRole
    from langflow.services.database.models.masterdata.model import MasterData
    from langflow.services.database.models.recent_activity.model import RecentActivity
from sqlalchemy.sql import false

class UserOptin(BaseModel):
    github_starred: bool = Field(default=False)
    dialog_dismissed: bool = Field(default=False)
    discord_clicked: bool = Field(default=False)
    # Add more opt-in actions as needed


class User(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    username: str = Field(index=True, unique=True)
    password: str = Field()
    profile_image: str | None = Field(default=None, nullable=True)
    email: Optional[str] = Field(default=None, nullable=True)
    is_active: bool = Field(default=False)
    is_superuser: bool = Field(default=False)
    homepage_config: Optional[str] = Field(default=None, nullable=True)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    last_login_at: datetime | None = Field(default=None, nullable=True)
    search_field: str = Field(default="", index=True, nullable=False)
    role_id: Optional[UUIDstr] = Field(default=None, foreign_key="userrole.id", nullable=True)
    role: Optional["UserRole"] = Relationship(back_populates="users")
    phone_number: Optional[str] = Field(default=None, nullable=True)
    is_pending: bool = Field(default=False, sa_column=Column(Boolean(), server_default=false()))

    api_keys: list["ApiKey"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    files: list["File"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    store_api_key: str | None = Field(default=None, nullable=True)
    flows: list["Flow"] = Relationship(back_populates="user")
    variables: list["Variable"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    folders: list["Folder"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    mcp_servers: list["MCPServer"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "delete", "foreign_keys": "[MCPServer.user_id]"},
    )
    mcp_tools: list["MCPTool"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    datasources: list["Datasource"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={
            "cascade": "delete",
            "foreign_keys": "[Datasource.create_by]"
        },
    )
    approved_datasources: list["Datasource"] = Relationship(
        back_populates="approver",
        sa_relationship_kwargs={
            "cascade": "delete",
            "foreign_keys": "[Datasource.approved_by]"
        },
    )
    user_groups: list["UserGroup"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    master_data: list["MasterData"] = Relationship(
        back_populates="creator",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    recent_activities: list["RecentActivity"] = Relationship(
        back_populates="user",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    optins: dict[str, Any] | None = Field(
        sa_column=Column(JSON, default=lambda: UserOptin().model_dump(), nullable=True)
    )

    def update_search_field(self) -> None:
        """Update the search_field based on username and email."""
        if self.email:
            self.search_field = f"{self.username}_{self.email}"
        else:
            self.search_field = self.username


class UserCreate(SQLModel):
    username: str = Field()
    password: str = Field()
    email: Optional[str] = Field(default=None)
    phone_number: Optional[str] = Field(default=None)
    profile_image: str | None = Field(default=None)
    is_active: bool | None = Field(default=False)
    is_superuser: bool | None = Field(default=False)
    homepage_config: Optional[str] = Field(default=None)
    role_id: Optional[UUID] = Field(default=None)
    group_id: Optional[UUID] = Field(default=None)
    optins: dict[str, Any] | None = Field(
        default={"github_starred": False, "dialog_dismissed": False, "discord_clicked": False}
    )


class UserRead(SQLModel):
    id: UUID = Field(default_factory=uuid4)
    username: str = Field()
    email: Optional[str] = Field(default=None)
    profile_image: str | None = Field(default=None)
    store_api_key: str | None = Field(default=None, nullable=True)
    is_active: bool = Field()
    is_superuser: bool = Field()
    homepage_config: Optional[str] = Field(default=None)
    role_id: Optional[UUID] = Field(default=None)
    role_name: Optional[str] = Field(default=None)
    create_at: datetime = Field()
    updated_at: datetime = Field()
    last_login_at: datetime | None = Field(default=None, nullable=True)
    search_field: str = Field(default="")
    optins: dict[str, Any] | None = Field(default=None)
    group_id: Optional[UUID] = Field(default=None)
    group_name: Optional[str] = Field(default=None)
    join_group_at: Optional[datetime] = Field(default=None)
    is_pending: bool = Field()


class UserUpdate(SQLModel):
    username: str | None = Field(default=None)
    password: str | None = Field(default=None)
    email: str | None = Field(default=None)
    profile_image: str | None = Field(default=None)
    store_api_key: str | None = Field(default=None)
    is_active: bool | None = Field(default=None)
    is_superuser: bool | None = Field(default=None)
    homepage_config: str | None = Field(default=None)
    role_id: Optional[UUID] = Field(default=None)
    last_login_at: datetime | None = Field(default=None)
    optins: dict[str, Any] | None = Field(default=None)
    group_id: Optional[UUID] = Field(default=None)
    join_group_at: datetime | None = Field(default=None)
    phone_number: str | None = Field(default=None)
    is_pending: bool | None = Field(default=None)
