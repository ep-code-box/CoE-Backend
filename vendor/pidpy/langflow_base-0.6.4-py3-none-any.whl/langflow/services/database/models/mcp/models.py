from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

from sqlalchemy import Text, UniqueConstraint
from sqlmodel import JSON, Column, DateTime, Field, Relationship, SQLModel, func

if TYPE_CHECKING:
    from langflow.services.database.models.mcp_tools.models import MCPTool
    from langflow.services.database.models.user.model import User, UserRead
    from langflow.services.database.models.group.model import Group, GroupReadMini
else:
    # Import at runtime for proper serialization
    from langflow.services.database.models.user.model import UserRead
    from langflow.services.database.models.group.model import GroupReadMini


def utc_now():
    return datetime.now(timezone.utc)



class MCPServerStatusEnum(str, Enum):
    PENDING = "PENDING"
    REJECTED = "REJECTED"
    ACTIVE = "ACTIVE"


class MCPServerTypeEnum(str, Enum):
    EXTERNAL_STDIO = "EXTERNAL_STDIO"
    EXTERNAL_SSE = "EXTERNAL_SSE"
    SELF_HOSTED = "SELF_HOSTED"


class MCPServerBase(SQLModel):
    name: str = Field(description="Name of the MCP server", sa_column=Column(Text))
    description: str | None = Field(default=None, description="Description of the MCP server", sa_column=Column(Text, nullable=True))
    tags: list[str] | None = Field(default=None, sa_column=Column(JSON), description="Tags for categorization")
    status: MCPServerStatusEnum = Field(default=MCPServerStatusEnum.PENDING, description="Status of the MCP server")
    type: MCPServerTypeEnum = Field(description="Type of the MCP server")
    config: dict | None = Field(default=None, sa_column=Column(JSON), description="Configuration for the MCP server")
    is_from_template: bool = Field(default=False, description="Whether this MCP server was created from a template")
    reviewed_by: UUID | None = Field(default=None, description="User ID who reviewed this MCP server", foreign_key="user.id", nullable=True)
    reviewed_at: datetime | None = Field(default=None, description="Timestamp when the MCP server was reviewed", sa_column=Column(DateTime(timezone=True), nullable=True))
    review_comment: str | None = Field(default=None, description="Review comment for this MCP server", sa_column=Column(Text, nullable=True))


class MCPServer(MCPServerBase, table=True):  # type: ignore[call-arg]
    __tablename__ = "mcp_server"
    __table_args__ = (UniqueConstraint("name", "group_id", name="uq_mcp_server_name_group"),)

    id: UUID | None = Field(default_factory=uuid4, primary_key=True, unique=True)
    is_online: bool = Field(default=False, description="Currently useless")
    created_at: datetime | None = Field(
        default=None,
        sa_column=Column(DateTime(timezone=True), server_default=func.now(), nullable=False),
        description="Creation time of the MCP server",
    )
    updated_at: datetime | None = Field(
        default=None,
        sa_column=Column(DateTime(timezone=True), onupdate=func.now(), nullable=True),
        description="Last update time of the MCP server",
    )

    # Foreign key to user table
    user_id: UUID = Field(description="User ID who created this MCP server", foreign_key="user.id")
    user: "User" = Relationship(
        back_populates="mcp_servers",
        sa_relationship_kwargs={"foreign_keys": "MCPServer.user_id"}
    )
    
    # Foreign key to group table
    group_id: UUID | None = Field(default=None, description="Group ID associated with this MCP server", foreign_key="group.id", nullable=True)
    group: "Group" = Relationship(sa_relationship_kwargs={"foreign_keys": "MCPServer.group_id"})

    # Relationship to MCP tools
    mcp_tools: list["MCPTool"] = Relationship(
        back_populates="mcp_server",
        sa_relationship_kwargs={"cascade": "delete"},
    )


class MCPServerCreate(SQLModel):
    name: str = Field(description="Name of the MCP server")
    description: str | None = Field(default=None, description="Description of the MCP server")
    tags: list[str] | None = Field(default=None, description="Tags for categorization")
    type: MCPServerTypeEnum = Field(description="Type of the MCP server")
    config: dict | None = Field(default=None, description="Configuration for the MCP server")
    is_from_template: bool = Field(default=False, description="Whether this MCP server was created from a template")
    group_id: UUID | None = Field(default=None, description="Group ID to associate with the server")


class MCPServerUpdate(SQLModel):
    name: str | None = Field(default=None, description="Name of the MCP server")
    description: str | None = Field(default=None, description="Description of the MCP server")
    tags: list[str] | None = Field(default=None, description="Tags for categorization")
    status: MCPServerStatusEnum | None = Field(default=None, description="Status of the MCP server")
    config: dict | None = Field(default=None, description="Configuration for the MCP server")
    is_from_template: bool | None = Field(default=None, description="Whether this MCP server was created from a template")
    reviewed_by: UUID | None = Field(default=None, description="User ID who reviewed this MCP server")
    reviewed_at: datetime | None = Field(default=None, description="Timestamp when the MCP server was reviewed")
    review_comment: str | None = Field(default=None, description="Review comment for this MCP server")


class MCPServerList(SQLModel):
    """MCP Server model for list endpoints (excludes config for security/performance)."""

    id: UUID
    name: str
    description: str | None = None
    tags: list[str] | None = None
    status: MCPServerStatusEnum
    is_online: bool
    type: MCPServerTypeEnum
    created_at: datetime
    updated_at: datetime | None = None
    user_id: UUID
    group_id: UUID | None = None
    tools_count: int = Field(default=0, description="Number of tools associated with this MCP server")
    config: dict | None = None
    is_from_template: bool = False
    reviewed_by: UUID | None = None
    reviewed_at: datetime | None = None
    review_comment: str | None = None
    user: UserRead | None = Field(default=None, description="User who created this MCP server")
    reviewed_by_user: UserRead | None = Field(default=None, description="User who reviewed this MCP server")
    group_info: "GroupReadMini | None" = Field(default=None, description="Group information associated with this MCP server")


class MCPServerRead(MCPServerList):
    """MCP Server model for detail endpoints (includes config)."""

    config: dict | None = None


