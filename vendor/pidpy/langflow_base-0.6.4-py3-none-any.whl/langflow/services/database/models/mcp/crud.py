from datetime import datetime, timezone
from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy import func
from sqlalchemy.orm import aliased, selectinload
from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.mcp.models import (
    MCPServer,
    MCPServerCreate,
    MCPServerList,
    MCPServerRead,
    MCPServerUpdate,
    MCPServerStatusEnum,
    MCPServerTypeEnum,
)
from langflow.services.database.models.mcp_tools.models import MCPTool
from langflow.services.database.models.user.model import User, UserRead
from langflow.services.database.models.group.model import Group, GroupReadMini
from langflow.services.database.models.user_group.model import UserGroup
from langflow.services.database.models.resource_permission.model import ResourcePermission
from langflow.services.database.models.resource_permission.constants import ResourceTypes

if TYPE_CHECKING:
    from sqlmodel.sql.expression import SelectOfScalar


async def get_mcp_server_list(
    session: AsyncSession,
    user_id: UUID,
    sort_by: str = "created_at",
    sort_direction: str = "desc",
    filter_by: dict | None = None,
    page: int = 1,
    page_size: int = 10,
    filter_by_permission: bool = False,
    get_by_membership: bool = False,
) -> tuple[list[MCPServerList], int]:
    """Get a paginated and filtered list of all MCP servers.
    TODO: Optimize to avoid db hits
    
    Args:
        session: Database session
        sort_by: Field to sort by (name, created_at, updated_at, status)
        sort_direction: Sort direction ('asc' or 'desc')
        filter_by: Dictionary of field names and values to filter by (includes group_id)
        page: Page number (1-indexed)
        page_size: Number of items per page
        user_id: User ID for permission filtering (required if not superuser)
        is_superuser: Whether the user is a superuser
        
    Returns:
        Tuple of (list of MCPServerList objects, total count)
    """
    query: SelectOfScalar = select(MCPServer).options(
            selectinload(MCPServer.user)
    )
    if get_by_membership:
        query = query.join(
            UserGroup,
            (UserGroup.group_id == MCPServer.group_id) & (UserGroup.user_id == user_id),
        )
    if filter_by_permission:
        query = query.outerjoin(
            ResourcePermission,
                (ResourcePermission.resource_id == MCPServer.id) & 
                (ResourcePermission.resource_type == ResourceTypes.MCP) &
                (ResourcePermission.has_read_permission == True) &
                (ResourcePermission.user_id == user_id),
        ).where(
            (MCPServer.user_id == user_id)
            | (
                (MCPServer.status == MCPServerStatusEnum.ACTIVE)
                & (ResourcePermission.resource_id != None)
            )
        )
    
    # Apply filters
    if filter_by:
        for field, value in filter_by.items():
            if value is not None or field == "group_id":
                if field == "status" and isinstance(value, str):
                    # Handle status enum filtering
                    try:
                        status_enum = MCPServerStatusEnum(value)
                        query = query.where(MCPServer.status == status_enum)
                    except ValueError:
                        pass  # Invalid enum value, skip this filter
                elif field == "type":
                    # Handle type enum filtering (supports both single value and list)
                    if isinstance(value, list):
                        # Multiple type values
                        try:
                            type_enums = [MCPServerTypeEnum(v) for v in value]
                            query = query.where(MCPServer.type.in_(type_enums))
                        except ValueError:
                            pass  # Invalid enum value, skip this filter
                    elif isinstance(value, str):
                        # Single type value
                        try:
                            type_enum = MCPServerTypeEnum(value)
                            query = query.where(MCPServer.type == type_enum)
                        except ValueError:
                            pass  # Invalid enum value, skip this filter
                elif field == "name":
                    # Partial match for name
                    query = query.where(MCPServer.name.contains(value))
                elif field == "is_online" and isinstance(value, bool):
                    query = query.where(MCPServer.is_online == value)
                elif field == "is_from_template" and isinstance(value, bool):
                    query = query.where(MCPServer.is_from_template == value)
                elif field == "group_ids" and isinstance(value, list):
                    # Filter by multiple group_ids (for superuser only)
                    query = query.where(MCPServer.group_id.in_(value))
                elif hasattr(MCPServer, field):
                    query = query.where(getattr(MCPServer, field) == value)
    
    # Count total items before pagination (using the filtered query)
    total_count = len((await session.exec(query)).all())
    
    # Apply sorting
    sort_field = getattr(MCPServer, sort_by, MCPServer.created_at)
    if sort_direction.lower() == "asc":
        query = query.order_by(sort_field.asc())
    else:
        query = query.order_by(sort_field.desc())
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    mcp_servers = (await session.exec(query)).all()
    
    # Get tools count for all servers in one query (avoid N+1)
    server_ids = [server.id for server in mcp_servers]
    if server_ids:
        tools_count_query = (
            select(MCPTool.mcp_server_id, func.count(MCPTool.id).label("tools_count"))
            .where(MCPTool.mcp_server_id.in_(server_ids))
            .group_by(MCPTool.mcp_server_id)
        )
        tools_count_results = (await session.exec(tools_count_query)).all()
        # Create a dictionary for quick lookup
        tools_count_map = {server_id: count for server_id, count in tools_count_results}
    else:
        tools_count_map = {}
    
    # Prefetch reviewed_by users (avoid N+1)
    reviewed_by_ids = [server.reviewed_by for server in mcp_servers if server.reviewed_by]
    reviewed_by_map = {}
    if reviewed_by_ids:
        reviewed_by_query = select(User).where(User.id.in_(reviewed_by_ids))
        reviewed_by_users = (await session.exec(reviewed_by_query)).all()
        reviewed_by_map = {user.id: user for user in reviewed_by_users}
    
    # Prefetch groups (avoid N+1)
    group_ids = [server.group_id for server in mcp_servers if server.group_id]
    group_map = {}
    if group_ids:
        group_query = select(Group).where(Group.id.in_(group_ids))
        groups = (await session.exec(group_query)).all()
        group_map = {group.id: group for group in groups}
    
    # Convert to list models (without config for security/performance)
    mcp_server_list = []
    for server in mcp_servers:
        # Get tools count from the map (default to 0 if not found)
        tools_count = tools_count_map.get(server.id, 0)
        
        # Create MCPServerList with tools_count and user data
        server_dict = server.model_dump()
        server_dict["tools_count"] = tools_count
        
        # Add user data
        if server.user:
            server_dict["user"] = UserRead.model_validate(server.user, from_attributes=True)
        
        # Add reviewed_by user data
        if server.reviewed_by and server.reviewed_by in reviewed_by_map:
            server_dict["reviewed_by_user"] = UserRead.model_validate(
                reviewed_by_map[server.reviewed_by], from_attributes=True
            )
        
        # Add group data
        if server.group_id and server.group_id in group_map:
            server_dict["group_info"] = GroupReadMini.model_validate(
                group_map[server.group_id], from_attributes=True
            )
        
        mcp_server_list.append(MCPServerList(**server_dict))
    
    return mcp_server_list, total_count


async def create_mcp_server(
    session: AsyncSession, mcp_server_create: MCPServerCreate, user_id: UUID, group_id: UUID | None = None
) -> MCPServer:
    """Create a new MCP server.
    
    Args:
        session: Database session
        mcp_server_create: MCP server creation data
        user_id: User ID who creates the server
        group_id: Group ID to associate with the server (optional)
        
    Returns:
        Created MCP server as MCPServerRead
    """
    name = mcp_server_create.name.replace(" ", "_").lower()
    mcp_server = MCPServer(
        name=name,
        description=mcp_server_create.description,
        tags=mcp_server_create.tags,
        status=MCPServerStatusEnum.PENDING,  # Always PENDING on creation
        type=mcp_server_create.type,
        config=mcp_server_create.config,
        is_from_template=mcp_server_create.is_from_template,
        user_id=user_id,
        group_id=group_id,
        is_online=False,
        created_at=datetime.now(timezone.utc),
    )
    
    session.add(mcp_server)
    await session.flush()  # Flush to get the .id
    return mcp_server


async def update_mcp_server(
    session: AsyncSession, mcp_server_id: UUID, mcp_server_update: MCPServerUpdate, user_id: UUID
) -> MCPServerRead:
    """Update an existing MCP server.
    
    Args:
        session: Database session
        mcp_server_id: ID of the MCP server to update
        mcp_server_update: Updated MCP server data
        user_id: User ID who owns the server
        
    Returns:
        Updated MCP server as MCPServerRead
        
    Raises:
        ValueError: If MCP server not found or user doesn't own it
    """
    query: SelectOfScalar = (
        select(MCPServer)
        .where(MCPServer.id == mcp_server_id)
        .options(
            selectinload(MCPServer.user),
            selectinload(MCPServer.group)
        )
    )
    mcp_server = (await session.exec(query)).first()
    
    if mcp_server is None:
        msg = "MCP Server not found"
        raise ValueError(msg)
    
    # Update only the fields that are provided
    update_data = mcp_server_update.model_dump(exclude_unset=True)
    changed = False

    for field, value in update_data.items():
        if value is not None and hasattr(mcp_server, field):
            if field == "name":
                value = value.replace(" ", "_").lower()
            setattr(mcp_server, field, value)
            changed = True
    
    if changed:
        mcp_server.updated_at = datetime.now(timezone.utc)
        flag_modified(mcp_server, "updated_at")
        session.add(mcp_server)
        await session.commit()
        await session.refresh(mcp_server)
    
    return MCPServerRead.model_validate(mcp_server, from_attributes=True)


async def delete_mcp_server(session: AsyncSession, mcp_server_id: UUID, user_id: UUID) -> None:
    """Delete an MCP server.
    
    Args:
        session: Database session
        mcp_server_id: ID of the MCP server to delete
        user_id: User ID who owns the server
        
    Raises:
        ValueError: If MCP server not found or user doesn't own it
    """
    mcp_server = await session.get(MCPServer, mcp_server_id)
    
    if mcp_server is None:
        msg = "MCP Server not found"
        raise ValueError(msg)
    
    await session.delete(mcp_server)
    await session.commit()


async def get_mcp_server_by_id(session: AsyncSession, mcp_server_id: UUID) -> MCPServerRead | None:
    """Get an MCP server by ID with user and group info.
    
    Args:
        session: Database session
        mcp_server_id: ID of the MCP server
        
    Returns:
        MCP server with loaded user and group relationships, or None if not found
    """
    query: SelectOfScalar = (
        select(MCPServer)
        .where(MCPServer.id == mcp_server_id)
        .options(
            selectinload(MCPServer.user),
            selectinload(MCPServer.group)
        )
    )
    mcp_server = (await session.exec(query)).first()
    
    if mcp_server is None:
        return None
    
    # Convert to dict and add related data
    server_dict = mcp_server.model_dump()
    
    # Add user data
    if mcp_server.user:
        server_dict["user"] = UserRead.model_validate(mcp_server.user, from_attributes=True)
    
    # Add reviewed_by user data
    if mcp_server.reviewed_by:
        reviewed_by_user = await session.get(User, mcp_server.reviewed_by)
        if reviewed_by_user:
            server_dict["reviewed_by_user"] = UserRead.model_validate(reviewed_by_user, from_attributes=True)
    
    # Add group data
    if mcp_server.group_id and mcp_server.group:
        server_dict["group_info"] = GroupReadMini.model_validate(mcp_server.group, from_attributes=True)
    
    return MCPServerRead(**server_dict)
