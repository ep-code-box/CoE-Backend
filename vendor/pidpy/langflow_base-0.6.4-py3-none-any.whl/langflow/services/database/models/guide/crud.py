from datetime import datetime, timezone
from uuid import UUID
from typing import Optional

from fastapi import HTTPException
from sqlalchemy import and_, delete as sa_delete, func, select as sa_select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.guide.model import (
    Guide,
    GuideUpdate,
    GuideCreate,
    GuideSaved,
    GuideRating,
    GuideReaction,
    ReactionEnum,
    GuideListResponse,
    GuideMiniListResponse,
)


async def list_guides(
    db: AsyncSession,
    filter_by: Optional[dict] = None,
    sort_by: Optional[str] = None,
    sort_dir: str = "asc",
    limit: int = 100,
    offset: int = 0,
    search_term: Optional[str] = None,
    saved_by: Optional[UUID] = None,
    current_user_id: Optional[UUID] = None,
) -> tuple[list[GuideListResponse], int]:
    """
    List guides with advanced filtering, sorting, and search capabilities.
    
    Returns:
        Tuple of (list of GuideListResponse, total count)
    """
    # Build base query with eager loading of relationships
    query = select(Guide).options(
        selectinload(Guide.created_by),
        selectinload(Guide.updated_by)
    )
    count_query = select(func.count()).select_from(Guide)
    
    # Apply filters
    conditions = []
    
    if filter_by:
        for key, value in filter_by.items():
            if hasattr(Guide, key) and value is not None:
                if isinstance(value, list):
                    conditions.append(getattr(Guide, key).in_(value))
                else:
                    conditions.append(getattr(Guide, key) == value)
    
    if search_term:
        search_condition = (
            Guide.title.ilike(f"%{search_term}%") | 
            Guide.description.ilike(f"%{search_term}%")
        )
        conditions.append(search_condition)
    
    if saved_by:
        # Filter by guides saved by a specific user using subquery to avoid large IN clause
        saved_subquery = select(GuideSaved.guide_id).where(GuideSaved.user_id == saved_by).subquery()
        conditions.append(Guide.id.in_(sa_select(saved_subquery)))
    
    if conditions:
        query = query.where(and_(*conditions))
        count_query = count_query.where(and_(*conditions))
    
    # Get total count
    total_count = (await db.exec(count_query)).one()
    
    # Apply sorting
    if sort_by and hasattr(Guide, sort_by):
        order_column = getattr(Guide, sort_by)
        if sort_dir.lower() == "desc":
            query = query.order_by(order_column.desc())
        else:
            query = query.order_by(order_column.asc())
    else:
        # Default sort by created_at descending
        query = query.order_by(Guide.created_at.desc())
    
    # Apply pagination
    query = query.offset(offset).limit(limit)
    
    # Execute query
    result = await db.exec(query)
    guides = list(result.all())
    
    if not guides:
        return [], 0
    
    # Fetch all related data in batch to avoid N+1 problem
    guide_ids = [guide.id for guide in guides]
    
    # Batch fetch: rating statistics (average and count) for all guides
    rating_stats_query = select(
        GuideRating.guide_id,
        func.avg(GuideRating.rating).label('avg_rating'),
        func.count(GuideRating.id).label('rating_count')
    ).where(GuideRating.guide_id.in_(guide_ids)).group_by(GuideRating.guide_id)
    rating_stats_result = await db.exec(rating_stats_query)
    rating_stats = {row.guide_id: (row.avg_rating or 0.0, row.rating_count or 0) for row in rating_stats_result.all()}
    
    # Batch fetch: user's ratings for all guides (if authenticated)
    user_ratings = {}
    if current_user_id:
        user_rating_query = select(GuideRating.guide_id, GuideRating.rating).where(
            and_(
                GuideRating.guide_id.in_(guide_ids),
                GuideRating.user_id == current_user_id
            )
        )
        user_rating_result = await db.exec(user_rating_query)
        user_ratings = {row.guide_id: row.rating for row in user_rating_result.all()}
    
    # Batch fetch: saved status for all guides (if authenticated)
    saved_guide_ids = set()
    if current_user_id:
        saved_query = select(GuideSaved.guide_id).where(
            and_(
                GuideSaved.guide_id.in_(guide_ids),
                GuideSaved.user_id == current_user_id
            )
        )
        saved_result = await db.exec(saved_query)
        saved_guide_ids = {row for row in saved_result.all()}
    
    # Batch fetch: reaction counts (likes and dislikes) for all guides
    like_counts = {}
    dislike_counts = {}
    reaction_counts_query = select(
        GuideReaction.guide_id,
        GuideReaction.reaction,
        func.count(GuideReaction.id).label('count')
    ).where(GuideReaction.guide_id.in_(guide_ids)).group_by(GuideReaction.guide_id, GuideReaction.reaction)
    reaction_counts_result = await db.exec(reaction_counts_query)
    for row in reaction_counts_result.all():
        if row.reaction == ReactionEnum.LIKE:
            like_counts[row.guide_id] = row.count
        elif row.reaction == ReactionEnum.DISLIKE:
            dislike_counts[row.guide_id] = row.count
    
    # Batch fetch: user's reactions for all guides (if authenticated)
    user_reactions = {}
    if current_user_id:
        user_reaction_query = select(GuideReaction.guide_id, GuideReaction.reaction).where(
            and_(
                GuideReaction.guide_id.in_(guide_ids),
                GuideReaction.user_id == current_user_id
            )
        )
        user_reaction_result = await db.exec(user_reaction_query)
        user_reactions = {row.guide_id: row.reaction for row in user_reaction_result.all()}
    
    # Build response with computed fields
    guide_responses = []
    for guide in guides:
        # Get rating statistics from pre-fetched data
        average_rating, rating_count = rating_stats.get(guide.id, (0.0, 0))
        
        # Get user's rating from pre-fetched data
        my_rating = user_ratings.get(guide.id)
        
        # Check if saved from pre-fetched data
        is_saved = guide.id in saved_guide_ids
        
        # Get reaction counts from pre-fetched data
        like_count = like_counts.get(guide.id, 0)
        dislike_count = dislike_counts.get(guide.id, 0)
        
        # Get user's reaction from pre-fetched data
        my_reaction = user_reactions.get(guide.id)
        
        # Get creator and updater names
        created_by_name = guide.created_by.username if guide.created_by else None
        updated_by_name = guide.updated_by.username if guide.updated_by else None
        created_by_info = (
            {
                "id": str(guide.created_by.id),
                "username": guide.created_by.username,
                "email": guide.created_by.email,
                "profile_image": guide.created_by.profile_image,
                "is_active": guide.created_by.is_active,
                "is_superuser": guide.created_by.is_superuser,
            }
            if guide.created_by
            else None
        )
        
        guide_response = GuideListResponse(
            id=guide.id,
            title=guide.title,
            description=guide.description,
            content=guide.content,
            order=guide.order,
            created_at=guide.created_at,
            updated_at=guide.updated_at,
            is_published=guide.is_published,
            guide_type=guide.guide_type,
            created_by_name=created_by_name,
            updated_by_name=updated_by_name,
            is_saved=is_saved,
            like_count=like_count,
            dislike_count=dislike_count,
            my_reaction=my_reaction,
            created_by=created_by_info,
        )
        guide_responses.append(guide_response)
    
    return guide_responses, total_count

async def list_guides_mini_response(
    db: AsyncSession,
    filter_by: Optional[dict] = None,
    sort_by: Optional[str] = None,
    sort_dir: str = "asc",
    limit: int = 100,
    offset: int = 0,
    search_term: Optional[str] = None,
    saved_by: Optional[UUID] = None,
    current_user_id: Optional[UUID] = None,
) -> tuple[list[GuideMiniListResponse], int]:
    """
    list_guides but 2
    """
    # Build base query with eager loading of relationships
    query = select(Guide).options(
        selectinload(Guide.created_by),
        selectinload(Guide.updated_by)
    )
    count_query = select(func.count()).select_from(Guide)
    
    # Apply filters
    conditions = []
    
    if filter_by:
        for key, value in filter_by.items():
            if hasattr(Guide, key) and value is not None:
                if isinstance(value, list):
                    conditions.append(getattr(Guide, key).in_(value))
                else:
                    conditions.append(getattr(Guide, key) == value)
    
    if search_term:
        search_condition = (
            Guide.title.ilike(f"%{search_term}%") | 
            Guide.description.ilike(f"%{search_term}%")
        )
        conditions.append(search_condition)
    
    if conditions:
        query = query.where(and_(*conditions))
        count_query = count_query.where(and_(*conditions))
    
    # Get total count
    total_count = (await db.exec(count_query)).one()
    
    # Apply sorting
    if sort_by and hasattr(Guide, sort_by):
        order_column = getattr(Guide, sort_by)
        if sort_dir.lower() == "desc":
            query = query.order_by(order_column.desc())
        else:
            query = query.order_by(order_column.asc())
    else:
        # Default sort by created_at descending
        query = query.order_by(Guide.created_at.desc())
    
    # Apply pagination
    query = query.offset(offset).limit(limit)
    
    # Execute query
    result = await db.exec(query)
    guides = list(result.all())
    
    if not guides:
        return [], 0
    
    # Build response with computed fields
    guide_responses = []
    for guide in guides:
        
        # Get creator and updater names
        created_by_name = guide.created_by.username if guide.created_by else None
        updated_by_name = guide.updated_by.username if guide.updated_by else None
        
        guide_response = GuideMiniListResponse(
            id=guide.id,
            title=guide.title,
            description=guide.description,
            content=guide.content,
            order=guide.order,
            created_at=guide.created_at,
            updated_at=guide.updated_at,
            is_published=guide.is_published,
            guide_type=guide.guide_type,
            created_by_name=created_by_name,
            updated_by_name=updated_by_name,
        )
        guide_responses.append(guide_response)
    
    return guide_responses, total_count


async def get_guide_by_id(db: AsyncSession, guide_id: UUID) -> Guide | None:
    """Get a single guide by ID."""
    if isinstance(guide_id, str):
        guide_id = UUID(guide_id)
    stmt = select(Guide).where(Guide.id == guide_id)
    return (await db.exec(stmt)).first()


async def create_guide(
    db: AsyncSession,
    guide_create: GuideCreate,
    user_id: UUID,
) -> Guide:
    """Create a new guide."""
    new_guide = Guide(
        **guide_create.model_dump(),
        created_by_id=user_id,
        updated_by_id=user_id,
    )
    
    try:
        db.add(new_guide)
        await db.commit()
        await db.refresh(new_guide)
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e
    
    return new_guide


async def edit_guide(
    db: AsyncSession,
    guide_id: UUID,
    guide_update: GuideUpdate,
    user_id: UUID,
) -> Guide:
    """Update an existing guide."""
    guide_db = await get_guide_by_id(db, guide_id)
    
    if not guide_db:
        raise HTTPException(status_code=404, detail="Guide not found")
    
    guide_data = guide_update.model_dump(exclude_unset=True)
    changed = False
    
    for attr, value in guide_data.items():
        if hasattr(guide_db, attr) and value is not None:
            setattr(guide_db, attr, value)
            changed = True
    
    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")
    
    guide_db.updated_at = datetime.now(timezone.utc)
    guide_db.updated_by_id = user_id
    flag_modified(guide_db, "updated_at")
    flag_modified(guide_db, "updated_by_id")
    
    try:
        await db.commit()
        await db.refresh(guide_db)
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e
    
    return guide_db


async def delete_guide(db: AsyncSession, guide_id: UUID) -> bool:
    """Delete a guide by ID."""
    guide_db = await get_guide_by_id(db, guide_id)
    
    if not guide_db:
        raise HTTPException(status_code=404, detail="Guide not found")
    
    try:
        # Delete all related records to avoid FK constraint violations
        await db.exec(sa_delete(GuideReaction).where(GuideReaction.guide_id == guide_id))
        await db.exec(sa_delete(GuideRating).where(GuideRating.guide_id == guide_id))
        await db.exec(sa_delete(GuideSaved).where(GuideSaved.guide_id == guide_id))

        await db.delete(guide_db)
        await db.commit()
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e
    
    return True


async def rate_guide(
    db: AsyncSession,
    guide_id: UUID,
    user_id: UUID,
    rating: int,
) -> GuideRating:
    """Rate a guide (1-5 stars). Updates existing rating if user already rated."""
    if not 1 <= rating <= 5:
        raise HTTPException(status_code=400, detail="Rating must be between 1 and 5")
    
    # Check if guide exists
    guide = await get_guide_by_id(db, guide_id)
    if not guide:
        raise HTTPException(status_code=404, detail="Guide not found")
    
    # Check if user already rated this guide
    existing_rating_query = select(GuideRating).where(
        and_(
            GuideRating.guide_id == guide_id,
            GuideRating.user_id == user_id
        )
    )
    existing_rating = (await db.exec(existing_rating_query)).first()
    
    if existing_rating:
        # Update existing rating
        existing_rating.rating = rating
        existing_rating.rated_at = datetime.now(timezone.utc)
        flag_modified(existing_rating, "rating")
        flag_modified(existing_rating, "rated_at")
        try:
            await db.commit()
            await db.refresh(existing_rating)
        except IntegrityError as e:
            await db.rollback()
            raise HTTPException(status_code=400, detail=str(e)) from e
        return existing_rating
    else:
        # Create new rating
        new_rating = GuideRating(
            guide_id=guide_id,
            user_id=user_id,
            rating=rating,
        )
        try:
            db.add(new_rating)
            await db.commit()
            await db.refresh(new_rating)
        except IntegrityError as e:
            await db.rollback()
            raise HTTPException(status_code=400, detail=str(e)) from e
        return new_rating


async def save_guide(
    db: AsyncSession,
    guide_id: UUID,
    user_id: UUID,
    save: bool = True,
) -> bool:
    """Save or unsave a guide for a user."""
    # Check if guide exists
    guide = await get_guide_by_id(db, guide_id)
    if not guide:
        raise HTTPException(status_code=404, detail="Guide not found")
    
    # Check if already saved
    existing_save_query = select(GuideSaved).where(
        and_(
            GuideSaved.guide_id == guide_id,
            GuideSaved.user_id == user_id
        )
    )
    existing_save = (await db.exec(existing_save_query)).first()
    
    if save:
        if existing_save:
            # Already saved
            return True
        else:
            # Create new save
            new_save = GuideSaved(
                guide_id=guide_id,
                user_id=user_id,
            )
            try:
                db.add(new_save)
                await db.commit()
            except IntegrityError as e:
                await db.rollback()
                raise HTTPException(status_code=400, detail=str(e)) from e
            return True
    else:
        # Unsave
        if existing_save:
            try:
                await db.delete(existing_save)
                await db.commit()
            except IntegrityError as e:
                await db.rollback()
                raise HTTPException(status_code=400, detail=str(e)) from e
        return False


async def react_to_guide(
    db: AsyncSession,
    guide_id: UUID,
    user_id: UUID,
    reaction: Optional[ReactionEnum] = None,
) -> Optional[GuideReaction]:
    """
    React to a guide (like/dislike) or remove reaction.
    If reaction is None, removes existing reaction.
    If reaction is provided, creates new or updates existing reaction.
    """
    # Check if guide exists
    guide = await get_guide_by_id(db, guide_id)
    if not guide:
        raise HTTPException(status_code=404, detail="Guide not found")
    
    # Check if user already reacted to this guide
    existing_reaction_query = select(GuideReaction).where(
        and_(
            GuideReaction.guide_id == guide_id,
            GuideReaction.user_id == user_id
        )
    )
    existing_reaction = (await db.exec(existing_reaction_query)).first()
    
    if reaction is None:
        # Remove reaction (unlike)
        if existing_reaction:
            try:
                await db.delete(existing_reaction)
                await db.commit()
            except IntegrityError as e:
                await db.rollback()
                raise HTTPException(status_code=400, detail=str(e)) from e
        return None
    else:
        # Add or update reaction
        if existing_reaction:
            # Update existing reaction
            existing_reaction.reaction = reaction
            existing_reaction.reacted_at = datetime.now(timezone.utc)
            flag_modified(existing_reaction, "reaction")
            flag_modified(existing_reaction, "reacted_at")
            try:
                await db.commit()
                await db.refresh(existing_reaction)
            except IntegrityError as e:
                await db.rollback()
                raise HTTPException(status_code=400, detail=str(e)) from e
            return existing_reaction
        else:
            # Create new reaction
            new_reaction = GuideReaction(
                guide_id=guide_id,
                user_id=user_id,
                reaction=reaction,
            )
            try:
                db.add(new_reaction)
                await db.commit()
                await db.refresh(new_reaction)
            except IntegrityError as e:
                await db.rollback()
                raise HTTPException(status_code=400, detail=str(e)) from e
            return new_reaction


async def bulk_update_guide_order(
    db: AsyncSession,
    order_updates: list[dict[str, any]],
    user_id: UUID,
) -> bool:
    """Bulk update guide order fields."""
    try:
        for update_data in order_updates:
            guide_id = update_data.get("id")
            order = update_data.get("order")
            
            if not guide_id or order is None:
                continue
            
            # Convert string to UUID if needed
            if isinstance(guide_id, str):
                guide_id = UUID(guide_id)
            
            # Get guide
            guide = await get_guide_by_id(db, guide_id)
            if not guide:
                raise HTTPException(status_code=404, detail=f"Guide {guide_id} not found")
            
            # Update order and updated_by
            guide.order = order
            guide.updated_at = datetime.now(timezone.utc)
            guide.updated_by_id = user_id
            flag_modified(guide, "order")
            flag_modified(guide, "updated_at")
            flag_modified(guide, "updated_by_id")
        
        await db.commit()
        return True
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e
