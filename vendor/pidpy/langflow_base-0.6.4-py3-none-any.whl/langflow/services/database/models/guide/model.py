from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING, Any, Optional
from uuid import uuid4

from sqlmodel import Field, Relationship, SQLModel

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.user.model import User


class GuideTypeEnum(str, Enum):
    #faq
    FAQ = "FAQ"
    FAQ_GENERAL = "FAQ_GENERAL"
    FAQ_ACCOUNT = "FAQ_ACCOUNT"
    FAQ_AGENT_DESIGNER = "FAQ_AGENT_DESIGNER"
    FAQ_DB = "FAQ_DB"
    FAQ_MCP = "FAQ_MCP"
    FAQ_AX_MONITOR = "FAQ_AX_MONITOR"
    FAQ_PERMISSION_APPROVAL = "FAQ_PERMISSION_APPROVAL"

    # guide
    AI_AGENT = "AI_AGENT"
    TOOL_CATALOG = "TOOL_CATALOG"
    DATA_CATALOG = "DATA_CATALOG"
    AX_STUDIO_FEATURES = "AX_STUDIO_FEATURES"


class ReactionEnum(str, Enum):
    LIKE = "like"
    DISLIKE = "dislike"


class Guide(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True)
    title: str = Field(nullable=False)
    description: Optional[str] = Field(default=None, nullable=True)
    content: str = Field(nullable=False)
    order: int = Field(default=0)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    created_by_id: UUIDstr = Field(foreign_key="user.id", nullable=False)
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_by_id: UUIDstr = Field(foreign_key="user.id", nullable=False)
    is_published: bool = Field(default=False, nullable=False)
    guide_type: GuideTypeEnum = Field(default=GuideTypeEnum.FAQ, nullable=False)

    # Relationships
    created_by: "User" = Relationship(
        sa_relationship_kwargs={"foreign_keys": "[Guide.created_by_id]"}
    )
    updated_by: "User" = Relationship(
        sa_relationship_kwargs={"foreign_keys": "[Guide.updated_by_id]"}
    )


class GuideSaved(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True)
    user_id: UUIDstr = Field(foreign_key="user.id", nullable=False, index=True)
    guide_id: UUIDstr = Field(foreign_key="guide.id", nullable=False, index=True)
    saved_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class GuideRating(SQLModel, table=True):  # type: ignore[call-arg]
    '''
    Star rating system. to be deprecated in favor of reactions.
    list_guides function will be updated accordingly.
    '''
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True)
    user_id: UUIDstr = Field(foreign_key="user.id", nullable=False, index=True)
    guide_id: UUIDstr = Field(foreign_key="guide.id", nullable=False, index=True)
    rating: int = Field(nullable=False)  # 1 to 5
    rated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class GuideReaction(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True)
    user_id: UUIDstr = Field(foreign_key="user.id", nullable=False, index=True)
    guide_id: UUIDstr = Field(foreign_key="guide.id", nullable=False, index=True)
    reaction: ReactionEnum = Field(nullable=False)
    reacted_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))




class GuideCreate(SQLModel):
    title: str = Field()
    description: Optional[str] = Field(default=None)
    content: str = Field()
    order: int = Field(default=0)
    is_published: bool = Field(default=False)
    guide_type: GuideTypeEnum = Field(default=GuideTypeEnum.FAQ)


class GuideUpdate(SQLModel):
    title: Optional[str] = None
    description: Optional[str] = None
    content: Optional[str] = None
    order: Optional[int] = None
    is_published: Optional[bool] = None
    guide_type: Optional[GuideTypeEnum] = None


class GuideRead(SQLModel):
    id: UUIDstr = Field()
    title: str = Field()
    description: Optional[str] = Field(default=None)
    content: str = Field()
    order: int = Field()
    created_at: datetime = Field()
    updated_at: datetime = Field()
    is_published: bool = Field()
    guide_type: GuideTypeEnum = Field()
    created_by_id: UUIDstr = Field()
    updated_by_id: UUIDstr = Field()


class GuideListResponse(SQLModel):
    id: UUIDstr = Field()
    title: str = Field()
    content: str = Field()
    created_at: datetime = Field()
    updated_at: datetime = Field()
    is_published: bool = Field()
    guide_type: GuideTypeEnum = Field()
    updated_by_name: Optional[str] = Field(default=None)
    created_by_name: Optional[str] = Field(default=None)
    is_saved: bool = Field(default=False)
    like_count: int = Field(default=0)
    dislike_count: int = Field(default=0)
    my_reaction: Optional[ReactionEnum] = Field(default=None)
    created_by: Optional[Any] = Field(default=None)

class GuideMiniListResponse(SQLModel):
    id: UUIDstr = Field()
    title: str = Field()
    description: Optional[str] = Field(default=None)
    content: str = Field()
    order: int = Field()
    created_at: datetime = Field()
    updated_at: datetime = Field()
    is_published: bool = Field()
    guide_type: GuideTypeEnum = Field()
    updated_by_name: Optional[str] = Field(default=None)
    created_by_name: Optional[str] = Field(default=None)