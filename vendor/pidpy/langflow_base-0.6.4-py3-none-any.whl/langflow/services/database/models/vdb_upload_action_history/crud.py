from uuid import UUID

from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.vdb_upload_action_history.model import (
    VdbUploadActionHistory,
    VdbUploadActionHistoryCreate,
)
from langflow.services.database.models.vdb_upload_action_history.constants import VdbUploadActionHistoryAction


async def get_vdb_upload_action_history_by_id(
    db: AsyncSession, history_id: UUID
) -> VdbUploadActionHistory | None:
    if isinstance(history_id, str):
        history_id = UUID(history_id)
    stmt = select(VdbUploadActionHistory).where(VdbUploadActionHistory.id == history_id)
    return (await db.exec(stmt)).first()


async def create_vdb_upload_action_history(session, action, user_id, upload_record, old_values=None):
    upload_name = getattr(upload_record, "name", str(upload_record.id))

    if action == VdbUploadActionHistoryAction.REVIEW_REQUESTED:
        history_data = VdbUploadActionHistoryCreate(
            upload_id=upload_record.id,
            action=VdbUploadActionHistoryAction.REVIEW_REQUESTED,
            description=f"Upload '{upload_name}' was created",
            old_values=None,
            new_values=upload_record.model_dump_json(),
            create_by=user_id,
        )
    elif action == VdbUploadActionHistoryAction.APPROVED:
        history_data = VdbUploadActionHistoryCreate(
            upload_id=upload_record.id,
            action=VdbUploadActionHistoryAction.APPROVED,
            description=f"Upload '{upload_name}' was approved",
            old_values=old_values,
            new_values=upload_record.model_dump_json(),
            create_by=user_id,
        )
    elif action == VdbUploadActionHistoryAction.REJECTED:
        history_data = VdbUploadActionHistoryCreate(
            upload_id=upload_record.id,
            action=VdbUploadActionHistoryAction.REJECTED,
            description=f"Upload '{upload_name}' was rejected",
            old_values=old_values,
            new_values=upload_record.model_dump_json(),
            create_by=user_id,
        )
    elif action == VdbUploadActionHistoryAction.DELETED:
        history_data = VdbUploadActionHistoryCreate(
            upload_id=upload_record.id,
            action=VdbUploadActionHistoryAction.DELETED,
            description=f"Upload '{upload_name}' was deleted",
            old_values=old_values,
            new_values=upload_record.model_dump_json(),
            create_by=user_id,
        )
    else:
        history_data = VdbUploadActionHistoryCreate(
            upload_id=upload_record.id,
            action=VdbUploadActionHistoryAction.UPDATED,
            description=f"Upload '{upload_name}' was updated",
            old_values=old_values,
            new_values=upload_record.model_dump_json(),
            create_by=user_id,
        )

    new_history = VdbUploadActionHistory.model_validate(history_data, from_attributes=True)
    session.add(new_history)
