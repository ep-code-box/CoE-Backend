from datetime import datetime, timezone
from uuid import uuid4
from typing import Optional

from pydantic import field_validator
from sqlmodel import Field, SQLModel

from langflow.schema.serialize import UUIDstr


class VdbUploadActionHistory(SQLModel, table=True):  # type: ignore[call-arg]
    __tablename__ = "vdb_upload_action_history"

    id: UUIDstr = Field(default_factory=uuid4, primary_key=True)
    upload_id: UUIDstr = Field(nullable=False, index=True)
    action: str = Field(nullable=False)
    description: str = Field(nullable=False)
    old_values: Optional[str] = Field(default=None, nullable=True)  # JSON string
    new_values: Optional[str] = Field(default=None, nullable=True)  # JSON string
    create_by: UUIDstr = Field(nullable=False)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class VdbUploadActionHistoryCreate(SQLModel):
    upload_id: UUIDstr = Field()
    action: str = Field()
    description: str = Field()
    old_values: Optional[str] = None
    new_values: Optional[str] = None
    create_by: Optional[UUIDstr] = Field(default=None)


class VdbUploadActionHistoryRead(SQLModel):
    id: UUIDstr = Field()
    upload_id: UUIDstr = Field()
    action: str = Field()
    description: str = Field()
    old_values: Optional[dict] = Field(default=None)
    new_values: Optional[dict] = Field(default=None)
    create_by: UUIDstr = Field()
    create_at: datetime = Field()
    created_by_username: Optional[str] = Field(default=None)

    @field_validator("create_at", mode="before")
    @classmethod
    def ensure_utc(cls, v: datetime) -> datetime:
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v


class VdbUploadActionHistoryResponse(SQLModel):
    total_count: int
    upload_action_histories: list[VdbUploadActionHistoryRead]
