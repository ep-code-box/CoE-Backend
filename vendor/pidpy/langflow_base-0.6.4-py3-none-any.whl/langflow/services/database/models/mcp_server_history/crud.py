from uuid import UUID

from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.mcp_server_history.model import MCPServerHistory, MCPServerHistoryCreate
from langflow.services.database.models.mcp_server_history.constants import MCPServerHistoryAction


async def get_mcp_server_history_by_id(db: AsyncSession, history_id: UUID) -> MCPServerHistory | None:
    if isinstance(history_id, str):
        history_id = UUID(history_id)
    stmt = select(MCPServerHistory).where(MCPServerHistory.id == history_id)
    return (await db.exec(stmt)).first()


async def create_mcp_server_history(session, action, user_id, mcp_server, old_values=None):
    if action == MCPServerHistoryAction.REVIEW_REQUESTED:
        history_data = MCPServerHistoryCreate(
            mcp_server_id=mcp_server.id,
            action=MCPServerHistoryAction.REVIEW_REQUESTED,
            description=f"MCP Server '{mcp_server.name}' was created",
            old_values=None,
            new_values=mcp_server.model_dump_json(),
            create_by=user_id,
        )
    elif action == MCPServerHistoryAction.APPROVED:
        history_data = MCPServerHistoryCreate(
            mcp_server_id=mcp_server.id,
            action=MCPServerHistoryAction.APPROVED,
            description=f"Reason: {getattr(mcp_server, 'review_comment', '') or ''}",
            old_values=old_values,
            new_values=mcp_server.model_dump_json(),
            create_by=user_id,
        )
    elif action == MCPServerHistoryAction.REJECTED:
        history_data = MCPServerHistoryCreate(
            mcp_server_id=mcp_server.id,
            action=MCPServerHistoryAction.REJECTED,
            description=f"Reason: {getattr(mcp_server, 'review_comment', '') or ''}",
            old_values=old_values,
            new_values=mcp_server.model_dump_json(),
            create_by=user_id,
        )
    elif action == MCPServerHistoryAction.DELETED:
        history_data = MCPServerHistoryCreate(
            mcp_server_id=mcp_server.id,
            action=MCPServerHistoryAction.DELETED,
            description=f"MCP Server '{mcp_server.name}' was deleted",
            old_values=old_values,
            new_values=mcp_server.model_dump_json(),
            create_by=user_id,
        )
    else:
        history_data = MCPServerHistoryCreate(
            mcp_server_id=mcp_server.id,
            action=MCPServerHistoryAction.UPDATED,
            description=f"MCP Server '{mcp_server.name}' was updated",
            old_values=old_values,
            new_values=mcp_server.model_dump_json(),
            create_by=user_id,
        )

    new_history = MCPServerHistory.model_validate(history_data, from_attributes=True)
    session.add(new_history)
