from datetime import datetime, timezone
from uuid import uuid4
from typing import Optional

from pydantic import field_validator
from sqlmodel import Field, SQLModel

from langflow.schema.serialize import UUIDstr


class MCPServerHistory(SQLModel, table=True):  # type: ignore[call-arg]
    __tablename__ = "mcpserverhistory"

    id: UUIDstr = Field(default_factory=uuid4, primary_key=True)
    mcp_server_id: UUIDstr = Field(nullable=False, index=True)
    action: str = Field(nullable=False)
    description: str = Field(nullable=False)
    old_values: Optional[str] = Field(default=None, nullable=True)  # JSON string of previous values
    new_values: Optional[str] = Field(default=None, nullable=True)  # JSON string of new values
    create_by: UUIDstr = Field(nullable=False)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class MCPServerHistoryCreate(SQLModel):
    mcp_server_id: UUIDstr = Field()
    action: str = Field()
    description: str = Field()
    old_values: Optional[str] = None
    new_values: Optional[str] = None
    create_by: Optional[UUIDstr] = Field(default=None)


class MCPServerHistoryRead(SQLModel):
    id: UUIDstr = Field()
    mcp_server_id: UUIDstr = Field()
    action: str = Field()
    description: str = Field()
    old_values: Optional[dict] = Field(default=None)
    new_values: Optional[dict] = Field(default=None)
    create_by: UUIDstr = Field()
    create_at: datetime = Field()
    created_by_username: Optional[str] = Field(default=None)

    @field_validator("create_at", mode="before")
    @classmethod
    def ensure_utc(cls, v: datetime) -> datetime:
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v


class MCPServerHistoryResponse(SQLModel):
    total_count: int
    mcp_server_histories: list[MCPServerHistoryRead]
