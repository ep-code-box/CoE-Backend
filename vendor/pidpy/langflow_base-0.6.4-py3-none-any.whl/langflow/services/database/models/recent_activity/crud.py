import asyncio
from datetime import datetime
from typing import Optional
from uuid import UUID

from sqlalchemy import and_, asc, desc, func, or_
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.recent_activity.model import (
    RecentActivity,
    RecentActivityCreate,
    ActivityItemTypeEnum,
    ActivityTypeEnum,
)
from langflow.services.database.models.mcp.models import MCPServerTypeEnum


def get_mcp_extra_info(mcp_server) -> str:
    """Get the extra_info value for an MCP recent activity based on server properties."""
    if mcp_server.tags is not None:
        return f"TEMPLATE_{mcp_server.tags[1]}"
    elif mcp_server.type in (MCPServerTypeEnum.EXTERNAL_STDIO, MCPServerTypeEnum.EXTERNAL_SSE):
        return f"EXTERNAL_{mcp_server.id}"
    elif mcp_server.type == MCPServerTypeEnum.SELF_HOSTED:
        return f"TOOL_{mcp_server.id}"
    return ""



async def add_recent_activity(
    session: AsyncSession,
    user_id: UUID,
    activity_type: ActivityTypeEnum,
    item_id: UUID,
    item_type: ActivityItemTypeEnum,
    title: str,
    description: str,
    extra_info: str | None = None,
) -> RecentActivity:
    """
    TODO: look in to this function. potential performance issue
    Manually add a recent activity record.
    
    Args:
        session: Database session
        user_id: ID of the user performing the activity
        activity_type: Type of activity (created, updated, deleted, viewed)
        item_id: ID of the item (flow, mcp, data_asset)
        item_type: Type of item
        title: Title of the activity
        description: Description of the activity
        extra_info: Optional extra info (e.g. MCP type prefix + id)
        
    Returns:
        The created RecentActivity object
    """
    activity_data = RecentActivityCreate(
        user_id=user_id,
        activity_type=activity_type,
        item_id=item_id,
        item_type=item_type,
        title=title,
        description=description,
        extra_info=extra_info,
    )
    
    new_activity = RecentActivity.model_validate(activity_data, from_attributes=True)
    session.add(new_activity)
    await session.commit()
    await session.refresh(new_activity)
    
    return new_activity


def add_recent_activity_fire_and_forget(
    session: AsyncSession,
    user_id: UUID,
    activity_type: ActivityTypeEnum,
    item_id: UUID,
    item_type: ActivityItemTypeEnum,
    title: str,
    description: str,
) -> None:
    """
    NOT WORKING.
    Fire-and-forget wrapper for add_recent_activity.
    Adds a recent activity record in the background without blocking.
    """
    asyncio.create_task(
        add_recent_activity(
            session=session,
            user_id=user_id,
            activity_type=activity_type,
            item_id=item_id,
            item_type=item_type,
            title=title,
            description=description,
        )
    )


async def list_recent_activities(
    session: AsyncSession,
    user_id: Optional[UUID] = None,
    filter_by: Optional[dict] = None,
    sort_by: str = "timestamp",
    sort_dir: str = "desc",
    limit: int = 50,
    offset: int = 0,
    search_term: Optional[str] = None,
    time_range: Optional[tuple[Optional[datetime], Optional[datetime]]] = None,
    distinct_by_item_id: bool = False,
) -> tuple[list[RecentActivity], int]:
    """
    List recent activities with filtering, sorting, and pagination.
    
    Args:
        session: Database session
        user_id: Filter by user ID
        filter_by: Dictionary of additional filters (e.g., {"activity_type": "created", "item_type": "flow"})
        sort_by: Field to sort by (default: "timestamp")
        sort_dir: Sort direction - "asc" or "desc" (default: "desc")
        limit: Maximum number of records to return (default: 50)
        offset: Number of records to skip (default: 0)
        search_term: Search in title and description
        time_range: Tuple of (start_time, end_time) to filter activities
        distinct_by_item_id: If True, return only the latest activity per item_id
        
    Returns:
        Tuple of (list of activities, total count)
    """
    # Collect all filter conditions once so they can be reused in subqueries
    conditions = []

    if user_id:
        conditions.append(RecentActivity.user_id == user_id)

    if filter_by:
        for field, value in filter_by.items():
            if hasattr(RecentActivity, field):
                conditions.append(getattr(RecentActivity, field) == value)

    if search_term:
        conditions.append(
            or_(
                RecentActivity.title.ilike(f"%{search_term}%"),
                RecentActivity.description.ilike(f"%{search_term}%"),
            )
        )

    if time_range:
        start_time, end_time = time_range
        if start_time:
            conditions.append(RecentActivity.timestamp >= start_time)
        if end_time:
            conditions.append(RecentActivity.timestamp <= end_time)

    # Build base query
    query = select(RecentActivity)
    if conditions:
        query = query.where(*conditions)

    if distinct_by_item_id:
        # Single JOIN against a (item_id, MAX(timestamp)) subquery — one DB round-trip per query
        max_ts_subq = (
            select(
                RecentActivity.item_id,
                func.max(RecentActivity.timestamp).label("max_ts"),
            )
            .where(*conditions)
            .group_by(RecentActivity.item_id)
            .subquery()
        )
        query = query.join(
            max_ts_subq,
            and_(
                RecentActivity.item_id == max_ts_subq.c.item_id,
                RecentActivity.timestamp == max_ts_subq.c.max_ts,
            ),
        )
        count_query = select(func.count(func.distinct(RecentActivity.item_id))).select_from(RecentActivity)
        if conditions:
            count_query = count_query.where(*conditions)
    else:
        count_query = select(func.count()).select_from(RecentActivity)
        if conditions:
            count_query = count_query.where(*conditions)

    # Apply sorting
    if hasattr(RecentActivity, sort_by):
        sort_column = getattr(RecentActivity, sort_by)
        if sort_dir.lower() == "asc":
            query = query.order_by(asc(sort_column))
        else:
            query = query.order_by(desc(sort_column))
    else:
        query = query.order_by(desc(RecentActivity.timestamp))

    # Apply pagination
    query = query.offset(offset).limit(limit)

    # Execute queries
    activities = (await session.exec(query)).all()
    total_count = (await session.exec(count_query)).first()

    return list(activities), total_count or 0
