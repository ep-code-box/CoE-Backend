from datetime import datetime
from enum import Enum
from typing import TYPE_CHECKING, Optional
from uuid import UUID, uuid4

from sqlmodel import Field, Relationship, SQLModel

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.user.model import User


class ActivityTypeEnum(str, Enum):
    CREATED = "created"
    UPDATED = "updated"
    DELETED = "deleted"
    VIEWED = "viewed"


class ActivityItemTypeEnum(str, Enum):
    FLOW = "flow"
    MCP = "mcp"
    DATA_ASSET = "data_asset"
    PROJECT_FOLDER = "project_folder"


class RecentActivity(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True)
    user_id: UUIDstr = Field(foreign_key="user.id", nullable=False)
    activity_type: ActivityTypeEnum = Field(nullable=False)
    item_id: UUIDstr = Field(nullable=False)
    item_type: ActivityItemTypeEnum = Field(nullable=False)
    title: str = Field(nullable=False)
    description: str = Field(nullable=False)
    extra_info: str | None = Field(default=None, nullable=True)
    timestamp: datetime = Field(default_factory=lambda: datetime.now().astimezone(), nullable=False)

    user: "User" = Relationship(back_populates="recent_activities")


class RecentActivityCreate(SQLModel):
    user_id: UUIDstr = Field()
    activity_type: ActivityTypeEnum = Field()
    item_id: UUIDstr = Field()
    item_type: ActivityItemTypeEnum = Field()
    title: str = Field()
    description: str = Field()
    extra_info: str | None = Field(default=None)


class RecentActivityRead(SQLModel):
    id: UUIDstr = Field()
    user_id: UUIDstr = Field()
    activity_type: ActivityTypeEnum = Field()
    item_id: UUIDstr = Field()
    item_type: ActivityItemTypeEnum = Field()
    title: str = Field()
    description: str = Field()
    extra_info: str | None = Field(default=None)
    timestamp: datetime = Field()
