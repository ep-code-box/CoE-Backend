from datetime import datetime, timezone
from uuid import UUID
from typing import TYPE_CHECKING

from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import select
from sqlalchemy import func, and_
from sqlmodel.ext.asyncio.session import AsyncSession
from langflow.services.database.models.datasource.model import (
    Datasource,
    DatasourceCreate,
    DatasourceUpdate
)
from langflow.services.database.models.datasource.constants import (
    DatasourceStatus, 
    DatasourceGroup, 
    DataAssetType, 
    DatasourceRDB, 
    DatasourceVectorDB
)
from langflow.services.database.models.datasource_rdb import DatasourceRdb
from langflow.services.database.models.datasource_s3 import DatasourceS3
from langflow.services.database.models.resource_permission.model import ResourcePermission
from langflow.services.database.models.resource_permission.constants import ResourceTypes
from langflow.services.database.models.resource_permission.crud import create_resource_permission
from langflow.services.database.models.user_group.model import UserGroup


if TYPE_CHECKING:
    from sqlmodel.sql.expression import SelectOfScalar

async def get_data_asset_list(
    session: AsyncSession,
    sort_by: str = "created_at",
    sort_direction: str = "desc",
    filter_by: dict | None = None,
    page: int = 1,
    page_size: int = 10,
    user_id: UUID | None = None,
    filter_by_permission: bool = False,
) -> tuple[list[Datasource], int]:
    '''get_all_data_asset but better'''

    # Base query with eager loading of user relationships
    query: SelectOfScalar = select(Datasource).options(
        selectinload(Datasource.user),
        selectinload(Datasource.group),
        selectinload(Datasource.approver)
    )

    if filter_by_permission:
        # Use JOIN to filter by permissions
        query = query.outerjoin(
            ResourcePermission,
            (ResourcePermission.resource_id == Datasource.id) &
            (ResourcePermission.resource_type == ResourceTypes.DATABASE) &
            (ResourcePermission.has_read_permission == True) &
            (ResourcePermission.user_id == user_id),
        ).where(
            (Datasource.create_by == user_id)
            | (
                (Datasource.status == DatasourceStatus.APPROVED)
                & (ResourcePermission.resource_id != None)
            )
        )

    # Apply filters
    default_filter_by = {"is_active": True}
    if filter_by:
        filter_by = {**default_filter_by, **filter_by}
    else:
        filter_by = default_filter_by
        
    conditions = []
    if filter_by:
        for key, value in filter_by.items():
            if value is not None and hasattr(Datasource, key):
                attr = getattr(Datasource, key)
                if isinstance(value, list):
                    conditions.append(attr.in_(value))
                else:
                    conditions.append(attr == value)
    
    if conditions:
        query = query.where(*conditions)

    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = (await session.exec(count_query)).one()

    # Apply sorting
    if hasattr(Datasource, sort_by):
        sort_attr = getattr(Datasource, sort_by)
        if sort_direction.lower() == "asc":
            query = query.order_by(sort_attr.asc())
        else:
            query = query.order_by(sort_attr.desc())

    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)

    # Execute query
    result = await session.exec(query)
    datasources = result.all()

    return datasources, total


async def get_unique_data_asset_name(db: AsyncSession, base_name: str, group_id: UUID) -> str:
    """
    Generate a unique datasource name by appending a number if duplicates exist.
    
    Args:
        db: Database session
        base_name: The original datasource name
        group_id: The group ID to check for duplicates within
        
    Returns:
        A unique datasource name (e.g., "MyDatasource (1)" if "MyDatasource" exists)
    """
    # Check if the base name already exists
    stmt = select(Datasource).where(
        Datasource.name == base_name,
        Datasource.group_id == group_id
    )
    result = await db.exec(stmt)
    existing = result.first()
    
    if not existing:
        # Base name is available
        return base_name
    
    # Find the next available number
    counter = 1
    while True:
        new_name = f"{base_name} ({counter})"
        stmt = select(Datasource).where(
            Datasource.name == new_name,
            Datasource.group_id == group_id
        )
        result = await db.exec(stmt)
        if not result.first():
            return new_name
        counter += 1


async def create_data_asset(session, user, request, datasource_type=None):
    try:
        # Generate unique name if duplicate exists
        group_id = user.user_groups[0].group_id
        unique_name = await get_unique_data_asset_name(session, request.name, group_id)

        # Create the main datasource
        datasource_data = DatasourceCreate(
            name=unique_name,
            description=request.description,
            datasource_type=request.datasource_type,
            create_by=user.id,
            group_id=group_id,
        )

        new_datasource = Datasource.model_validate(datasource_data, from_attributes=True)

        session.add(new_datasource)
        await session.flush()
        await session.refresh(new_datasource)
        new_datasource.update_search_field()
        
        config = None
        if datasource_type == "RDB":
            rdb_config = DatasourceRdb(
                datasource_id=new_datasource.id,
                host=request.host,
                port=request.port,
                database_name=request.database_name,
                username=request.username,
                password=request.password,
                schema_stored_value=request.metadata_obj
            )
            session.add(rdb_config)
            config = rdb_config
        elif datasource_type == "S3":
            s3_config = DatasourceS3(
                datasource_id=new_datasource.id,
                aws_s3_region=request.aws_s3_region,
                aws_s3_public_key=request.aws_s3_public_key,
                aws_s3_secret_key=request.aws_s3_secret_key,
                schema_stored_value=request.metadata_obj
            )
            session.add(s3_config)
            config = s3_config
        
        await session.commit()
        if config:
            await session.refresh(config)

        await session.refresh(new_datasource)

        response_data = new_datasource.model_dump()
        response_data["config"] = None
        if config:
            response_data["config"] = config.model_dump()
        
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail=f"IntegrityError: {str(e)}") from e
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail=f"Exception: {str(e)}") from e
    
    return response_data


async def get_data_asset_by_id(db: AsyncSession, datasource_id: UUID) -> Datasource | None:
    if isinstance(datasource_id, str):
        datasource_id = UUID(datasource_id)
        
    stmt = select(Datasource).where(Datasource.id == datasource_id).options(
        selectinload(Datasource.user),
        selectinload(Datasource.group),
        selectinload(Datasource.approver)
    )
    datasource = (await db.exec(stmt)).first()

    if datasource is None:
        raise HTTPException(status_code=404, detail="Datasource not found")
    
    return datasource


async def get_all_data_asset(
        db: AsyncSession, 
        datasource_type: str | None = None,
        datasource_group: str | None = None,
        group_ids: list[UUID] | None = None,
        skip: int = 0,
        limit: int = 100,
        search_str: str | None = None,
        status: str | None = None,
        user = None,
        filter_by_permission: bool = False,
        sort_by: str = "created_at",
        sort_direction: str = "desc",
        get_by_membership: bool = False,
        user_id: UUID | None = None,
    ) -> list[Datasource]:
    """Get all datasources with optional filtering and permission checks."""
    # Base queries
    query = select(Datasource).options(
        selectinload(Datasource.user),
        selectinload(Datasource.group),
        selectinload(Datasource.approver)
    )

    permission_join_condition = None
    permission_where_condition = None
    if filter_by_permission:
        permission_join_condition = (
            (ResourcePermission.resource_id == Datasource.id) &
            (ResourcePermission.resource_type == ResourceTypes.DATABASE) &
            (ResourcePermission.has_read_permission == True) &
            (ResourcePermission.user_id == user.id)
        )
        permission_where_condition = (
            (Datasource.create_by == user.id)
            | (
                (Datasource.status == DatasourceStatus.APPROVED)
                & (ResourcePermission.resource_id != None)
            )
        )
        query = query.outerjoin(ResourcePermission, permission_join_condition).where(permission_where_condition)

    if get_by_membership and user_id:
        query = query.join(
            UserGroup,
            (UserGroup.group_id == Datasource.group_id) & (UserGroup.user_id == user_id),
        )

    # Apply where conditions
    get_data_conditions = __build_datasource_where_query(
        datasource_type=datasource_type,
        datasource_group=datasource_group,
        status=status,
        group_ids=group_ids,
        search_str=search_str
    )
    if get_data_conditions is not None:
        query = query.where(get_data_conditions)

    # Get total count (derived from query to include permission filters)
    count_query = select(func.count()).select_from(query.subquery())
    total_count = (await db.exec(count_query)).one()

    # Apply sorting
    if hasattr(Datasource, sort_by):
        sort_attr = getattr(Datasource, sort_by)
        if sort_direction.lower() == "asc":
            query = query.order_by(sort_attr.asc())
        else:
            query = query.order_by(sort_attr.desc())

    # Paginated query with eager loading
    if limit:
        query = query.offset(skip).limit(limit)

    datasources = (await db.exec(query)).fetchall()

    # Calculate status counts using a single GROUP BY query
    status_count_query = select(Datasource.status, func.count(Datasource.id)).group_by(Datasource.status)
    if filter_by_permission:
        status_count_query = status_count_query.outerjoin(ResourcePermission, permission_join_condition).where(permission_where_condition)
    status_base_conditions = __build_datasource_where_query(
        datasource_type=datasource_type,
        datasource_group=datasource_group,
        status=None,
        group_ids=group_ids,
        search_str=search_str
    )
    if status_base_conditions is not None:
        status_count_query = status_count_query.where(status_base_conditions)
    status_count_result = (await db.exec(status_count_query)).all()
    status_count = {
        **{s.value: 0 for s in DatasourceStatus},
        **dict(status_count_result)
    }
    status_count["total"] = sum(status_count.values())

    return datasources, total_count, status_count


def __build_datasource_where_query(
        datasource_type=None,
        datasource_group=None, 
        status=None, 
        group_ids=None, 
        search_str=None
    ):
    conditions = [Datasource.is_active == True]
    
    if datasource_type:
        conditions.append(Datasource.datasource_type == datasource_type)
    if datasource_group:
        group_value = datasource_group.value if isinstance(datasource_group, DatasourceGroup) else datasource_group
        if group_value == DatasourceGroup.RDB.value:
            conditions.append(Datasource.datasource_type.in_([rdb.value.upper() for rdb in DatasourceRDB]))
        elif group_value == DatasourceGroup.VECTOR_DB.value:
            conditions.append(Datasource.datasource_type.in_([vdb.value.upper() for vdb in DatasourceVectorDB]))
        else:
            conditions.append(Datasource.datasource_type == DataAssetType.S3.value)

    if status:
        status_value = status.value if isinstance(status, DatasourceStatus) else status
        conditions.append(Datasource.status == status_value)

    if group_ids:
        conditions.append(Datasource.group_id.in_(group_ids))

    if search_str:
        conditions.append(Datasource.search_field.ilike(f"%{search_str}%"))

    if conditions:
        return and_(*conditions)
    else:
        return None


async def update_data_asset(datasource_db: Datasource | None, datasource: DatasourceUpdate,
                            db: AsyncSession, user=None) -> Datasource:
    if not datasource_db:
        raise HTTPException(status_code=404, detail="Datasource not found")

    datasource_data = datasource.model_dump(exclude_unset=True)
    changed = False
    for attr, value in datasource_data.items():
        if hasattr(datasource_db, attr) and value is not None:
            setattr(datasource_db, attr, value)
            changed = True

    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")
    
    if datasource.status in [DatasourceStatus.APPROVED.value, DatasourceStatus.REJECTED.value]:
        datasource_db.approved_by = user.id
    else:
        datasource_db.status = DatasourceStatus.PENDING
        datasource_db.reject_approve_reason = ""

    datasource_db.updated_at = datetime.now(timezone.utc)
    datasource_db.update_search_field()
    flag_modified(datasource_db, "updated_at")

    return datasource_db
