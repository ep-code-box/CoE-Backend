from datetime import datetime, timezone
from uuid import uuid4
from .constants import DatasourceStatus, DataAssetType
from typing import Optional, TYPE_CHECKING

from sqlmodel import Field, SQLModel, Relationship

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.user.model import User
    from langflow.services.database.models.datasource_rdb.model import DatasourceRdb
    from langflow.services.database.models.datasource_s3.model import DatasourceS3
    from langflow.services.database.models.data_asset_vdb.model import DataAssetConnectionVdb
    from langflow.services.database.models.group.model import Group

class Datasource(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    name: str = Field(index=True, nullable=False)
    status: DatasourceStatus = Field(default=DatasourceStatus.PENDING, nullable=False)
    description: str = Field(default=None, nullable=True)
    datasource_type: DataAssetType = Field(nullable=False)
    is_active: bool = Field(default=True, nullable=False)
    group_id: UUIDstr = Field(default=None, foreign_key="group.id")
    reject_approve_reason: Optional[str] = Field(default=None, nullable=True)
    search_field: str = Field(default="", index=True, nullable=False)
    create_by: UUIDstr = Field(default=None, foreign_key="user.id")
    approved_by: Optional[UUIDstr] = Field(default=None, foreign_key="user.id", nullable=True)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # Relationship to User
    user: Optional["User"] = Relationship(
        back_populates="datasources",
        sa_relationship_kwargs={
            "foreign_keys": "[Datasource.create_by]"
        }
    )
    
    # Relationship to User (approver)
    approver: Optional["User"] = Relationship(
        back_populates="approved_datasources",
        sa_relationship_kwargs={
            "foreign_keys": "[Datasource.approved_by]"
        }
    )
    
    # Relationship to Group
    group: Optional["Group"] = Relationship(back_populates="datasources")
    
    # Relationship to DatasourceRdb
    rdb_config: Optional["DatasourceRdb"] = Relationship(back_populates="datasource")
    
    # Relationship to DataAssetConnectionVdb
    vdb_config: Optional["DataAssetConnectionVdb"] = Relationship(back_populates="data_source")

    # Relationship to DatasourceS3
    s3_config: Optional["DatasourceS3"] = Relationship(back_populates="datasource")

    def update_search_field(self) -> None:
        """Update the search_field based on name, description, and user name."""
        search_parts = [self.name, self.description, self.user.username]
        self.search_field = "_".join(part for part in search_parts if part)


class DatasourceCreate(SQLModel):
    name: str = Field()
    status: Optional[str] = Field(default=DatasourceStatus.PENDING)
    description: Optional[str] = None
    datasource_type: str = Field()
    is_active: Optional[bool] = Field(default=True)
    reject_approve_reason: Optional[str] = Field(default=None)
    group_id: UUIDstr = Field()
    create_by: UUIDstr = Field()
    approved_by: Optional[UUIDstr] = Field(default=None)


class DatasourceRead(SQLModel):
    id: UUIDstr = Field()
    name: str = Field()
    status: str = Field()
    description: Optional[str] = Field()
    datasource_type: str = Field()
    is_active: bool = Field()
    group_id: UUIDstr = Field()
    reject_approve_reason: Optional[str] = Field()
    search_field: str = Field()
    create_by: UUIDstr = Field()
    approved_by: Optional[UUIDstr] = Field(default=None)
    create_at: datetime = Field()
    updated_at: datetime = Field()
    creator_name: Optional[str] = Field(default=None)
    group_name: Optional[str] = Field(default=None)
    approver_name: Optional[str] = Field(default=None)


class DatasourceUpdate(SQLModel):
    name: Optional[str] | None = None
    status: Optional[str] | None = None
    description: Optional[str] | None = None
    is_active: Optional[bool] | None = None
    reject_approve_reason: Optional[str] | None = None
    approved_by: Optional[UUIDstr] | None = None
    updated_at: Optional[datetime] = Field(default_factory=lambda: datetime.now(timezone.utc))
