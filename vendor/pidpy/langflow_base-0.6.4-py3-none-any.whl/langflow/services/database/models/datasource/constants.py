from enum import Enum


class DatasourceStatus(Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class DatasourceGroup(Enum):
    RDB = "RDB"
    VECTOR_DB = "VECTOR_DB"
    STORAGE_SERVICE = "STORAGE_SERVICE"


class DataAssetType(Enum):
    POSTGRESQL = "POSTGRESQL"
    ORACLE = "ORACLE"
    MYSQL = "MYSQL"
    MARIA_DB = "MARIA_DB"
    CHROMADB = "CHROMADB"
    MILVUS = "MILVUS"
    QDRANT = "QDRANT"
    S3 = "S3"


class DatasourceRDB(Enum):
    POSTGRESQL = "POSTGRESQL"
    ORACLE = "ORACLE"
    MYSQL = "MYSQL"
    MARIA_DB = "MARIA_DB"


class DatasourceStorageService(Enum):
    S3 = "S3"


class DatasourceVectorDB(Enum):
    CHROMADB = "CHROMADB"
    MILVUS = "MILVUS"
    QDRANT = "QDRANT"