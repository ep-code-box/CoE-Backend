from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException, status
from lfx.log.logger import logger
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.user_role.model import UserRole, UserRoleUpdate
from langflow.services.database.models.user_role.constants import DEFAULT_ROLES


async def get_user_role_by_name(db: AsyncSession, role_name: str) -> UserRole | None:
    """Get a user role by name."""
    stmt = select(UserRole).where(UserRole.name == role_name)
    return (await db.exec(stmt)).first()


async def create_default_roles(db: AsyncSession, system_user_id: UUID | str) -> list[UserRole]:
    """Create default user roles if they don't exist.
    
    Args:
        db: The database session
        system_user_id: The ID of the system user who creates the roles (UUID or string)
        
    Returns:
        List of created or existing default roles
    """
    # Ensure system_user_id is a UUID object
    if isinstance(system_user_id, str):
        system_user_id = UUID(system_user_id)
    
    created_roles = []
    
    for role_data in DEFAULT_ROLES:
        role_name = role_data["name"]
        
        # Check if role already exists
        existing_role = await get_user_role_by_name(db, role_name)
        
        if existing_role:
            await logger.adebug(f"Role '{role_name}' already exists, skipping creation")
            created_roles.append(existing_role)
            continue
        
        # Create new role
        try:
            new_role = UserRole(
                name=role_name,
                create_by=system_user_id
            )
            db.add(new_role)
            await db.commit()
            await db.refresh(new_role)
            await logger.adebug(f"Created default role: {role_name}")
            created_roles.append(new_role)
        except IntegrityError as e:
            await db.rollback()
            await logger.aerror(f"Error creating role '{role_name}': {e}")
            # Try to fetch the role again in case of race condition
            existing_role = await get_user_role_by_name(db, role_name)
            if existing_role:
                created_roles.append(existing_role)
    
    return created_roles


async def get_user_role_by_id(db: AsyncSession, user_role_id: UUID) -> UserRole | None:
    if isinstance(user_role_id, str):
        user_role_id = UUID(user_role_id)
    stmt = select(UserRole).where(UserRole.id == user_role_id)
    return (await db.exec(stmt)).first()


async def update_user_role(user_role_db: UserRole | None, user_role: UserRoleUpdate,
                            db: AsyncSession) -> UserRole:
    if not user_role_db:
        raise HTTPException(status_code=404, detail="UserRole not found")

    user_role_data = user_role.model_dump(exclude_unset=True)
    changed = False
    for attr, value in user_role_data.items():
        if hasattr(user_role_db, attr) and value is not None:
            setattr(user_role_db, attr, value)
            changed = True

    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")

    user_role_db.updated_at = datetime.now(timezone.utc)
    flag_modified(user_role_db, "updated_at")

    try:
        await db.commit()
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return user_role_db
