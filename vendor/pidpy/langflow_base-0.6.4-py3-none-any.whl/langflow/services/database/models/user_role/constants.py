# Default roles
DEFAULT_MEMBER_ROLE_NAME = "Member"
DEFAULT_ADMIN_ROLE_NAME = "Administrator"

DEFAULT_ROLES = [
    {"name": DEFAULT_MEMBER_ROLE_NAME, "description": "Default role for members."},
    {"name": DEFAULT_ADMIN_ROLE_NAME, "description": "Default role for administrators."},
]
