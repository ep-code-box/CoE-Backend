from datetime import datetime, timezone
from uuid import UUID, uuid4
from typing import TYPE_CHECKING, Optional

from sqlmodel import Field, Relationship, SQLModel

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.user.model import User

class UserRole(SQLModel, table=True):  # type: ignore[call-arg]
    """
    TODO: Remove the table. This should be removed in the 
    future when we have a better way to manage user roles and permissions.
    """
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    name: str = Field(index=True, nullable=False)
    create_by: UUIDstr = Field(default=None, nullable=False)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    users: list["User"] = Relationship(back_populates="role")


class UserRoleCreate(SQLModel):
    name: str = Field()
    create_by: Optional[UUIDstr] = Field(default=None)


class UserRoleRead(SQLModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = Field()
    create_by: UUIDstr = Field()
    create_at: datetime = Field()
    updated_at: datetime = Field()


class UserRoleUpdate(SQLModel):
    name: Optional[str] | None = None
    updated_at: datetime = None
