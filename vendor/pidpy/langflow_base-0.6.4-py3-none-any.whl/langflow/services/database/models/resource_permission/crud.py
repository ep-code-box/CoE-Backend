from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlalchemy.orm.attributes import flag_modified
from sqlalchemy import and_, delete
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.resource_permission.model import (
    ResourcePermission, 
    ResourcePermissionCreate, 
    ResourcePermissionUpdate
)

from langflow.services.database.models.mcp.models import MCPServer
from langflow.services.database.models.datasource.model import Datasource
from langflow.services.database.models.vdb_upload_history.model import VdbUploadHistory
from langflow.services.database.models.resource_permission.constants import ResourceTypes

async def get_resource_permission_by_id(db: AsyncSession, resource_permission_id: UUID) -> ResourcePermission | None:
    if isinstance(resource_permission_id, str):
        resource_permission_id = UUID(resource_permission_id)
    stmt = (
        select(ResourcePermission)
        .where(ResourcePermission.id == resource_permission_id)
        .options(selectinload(ResourcePermission.user), selectinload(ResourcePermission.creator))
    )
    return (await db.exec(stmt)).first()


async def get_resource_permission_by_user_id(db: AsyncSession, user_id: UUID, resource_type: str | None = None) -> list[ResourcePermission]:
    if isinstance(user_id, str):
        user_id = UUID(user_id)
    stmt = (
        select(ResourcePermission)
        .where(ResourcePermission.user_id == user_id)
        .options(selectinload(ResourcePermission.user), selectinload(ResourcePermission.creator))
    )
    if resource_type is not None:
        stmt = stmt.where(ResourcePermission.resource_type == resource_type)
        
    return (await db.exec(stmt)).all()


async def create_resource_permission(session, input_obj, user):
    result_permissions = []

    # Check for existing permissions to avoid duplicates
    query = select(ResourcePermission).where(
        and_(
            ResourcePermission.user_id.in_(input_obj["user_id"]),
            ResourcePermission.resource_id.in_(input_obj["resource_id"]),
            ResourcePermission.resource_type == input_obj["resource_type"]
        )
    )
    existing_permissions = (await session.exec(query)).all()
    
    # Create a dict of existing permissions for quick lookup
    existing_permissions_dict = {
        (perm.user_id, perm.resource_id): perm 
        for perm in existing_permissions
    }
    
    # Create or update permission for each combination of user_id and resource_id
    for user_id in input_obj["user_id"]:
        for resource_id in input_obj["resource_id"]:
            # Check if this combination already exists
            if (user_id, resource_id) in existing_permissions_dict:
                # Update existing permission
                existing_perm = existing_permissions_dict[(user_id, resource_id)]
                existing_perm.has_read_permission = input_obj["has_read_permission"]
                existing_perm.resource_type = input_obj["resource_type"]
                session.add(existing_perm)
                result_permissions.append(existing_perm)
            else:
                # Create new permission
                resource_permission_create = ResourcePermissionCreate(
                    user_id=user_id,
                    resource_id=resource_id,
                    resource_type=input_obj["resource_type"],
                    has_read_permission=input_obj["has_read_permission"],
                    create_by=user.id
                )
                new_resource_permission = ResourcePermission.model_validate(resource_permission_create, from_attributes=True)
                session.add(new_resource_permission)
                result_permissions.append(new_resource_permission)
    
    return result_permissions


async def update_resource_permission(resource_permission_db: ResourcePermission | None, 
                                     resource_permission_update: ResourcePermissionUpdate,
                            db: AsyncSession) -> ResourcePermission:
    if not resource_permission_db:
        raise HTTPException(status_code=404, detail="Resource permission not found")

    resource_permission_data = resource_permission_update.model_dump(exclude_unset=True)
    changed = False
    for attr, value in resource_permission_data.items():
        if hasattr(resource_permission_db, attr) and value is not None:
            setattr(resource_permission_db, attr, value)
            changed = True

    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")

    resource_permission_db.updated_at = datetime.now(timezone.utc)
    resource_permission_db.update_search_field()
    flag_modified(resource_permission_db, "updated_at")

    try:
        await db.commit()
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return resource_permission_db


async def create_permissions_for_all_resources_by_creator_in_group(
    session: AsyncSession,
    creator_id: UUID,
    user_id: UUID,
    group_id: UUID,
    created_by: UUID,
) -> list[ResourcePermission]:
    """Create ResourcePermissions for a user over all MCP, DATABASE, and SELF_HOSTED_VDB
    resources that were created by creator_id within the given group."""

    resource_type_queries = [
        (MCPServer, ResourceTypes.MCP, MCPServer.user_id),
        (Datasource, ResourceTypes.DATABASE, Datasource.create_by),
        (VdbUploadHistory, ResourceTypes.SELF_HOSTED_VDB, VdbUploadHistory.created_by),
    ]

    result_permissions = []

    for model, resource_type, creator_field in resource_type_queries:
        resource_ids = (
            await session.exec(
                select(model.id).where(
                    and_(creator_field == creator_id, model.group_id == group_id)
                )
            )
        ).all()

        if not resource_ids:
            continue

        existing = (
            await session.exec(
                select(ResourcePermission).where(
                    and_(
                        ResourcePermission.user_id == user_id,
                        ResourcePermission.resource_id.in_(resource_ids),
                        ResourcePermission.resource_type == resource_type.value,
                    )
                )
            )
        ).all()
        existing_resource_ids = {perm.resource_id for perm in existing}

        for resource_id in resource_ids:
            if resource_id in existing_resource_ids:
                continue
            perm = ResourcePermission.model_validate(
                ResourcePermissionCreate(
                    user_id=user_id,
                    resource_id=resource_id,
                    resource_type=resource_type.value,
                    has_read_permission=True,
                    create_by=created_by,
                ),
                from_attributes=True,
            )
            session.add(perm)
            result_permissions.append(perm)

    return result_permissions


async def delete_resource_permissions_by_resource_id(db: AsyncSession, resource_id: UUID) -> int:
    if isinstance(resource_id, str):
        resource_id = UUID(resource_id)

    stmt = delete(ResourcePermission).where(ResourcePermission.resource_id == resource_id)
    result = await db.exec(stmt)
    return result.rowcount


async def delete_resource_permissions_by_user_ids(db: AsyncSession, user_ids: list[UUID]) -> int:
    if not user_ids:
        return 0

    user_ids = [UUID(uid) if isinstance(uid, str) else uid for uid in user_ids]

    stmt = delete(ResourcePermission).where(ResourcePermission.user_id.in_(user_ids))
    result = await db.exec(stmt)
    return result.rowcount
