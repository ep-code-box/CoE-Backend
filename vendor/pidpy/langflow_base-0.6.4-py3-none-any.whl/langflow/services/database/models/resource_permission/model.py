from datetime import datetime, timezone
from uuid import uuid4
from typing import TYPE_CHECKING, Optional

from sqlmodel import Field, Relationship, SQLModel

from langflow.schema.serialize import UUIDstr

from .constants import ResourceTypes

if TYPE_CHECKING:
    from langflow.services.database.models.user.model import User

class ResourcePermission(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    user_id: UUIDstr = Field(foreign_key="user.id", nullable=False, index=True)
    resource_id: UUIDstr = Field(nullable=False, index=True)
    resource_type: ResourceTypes = Field(nullable=False)
    has_read_permission: bool = Field(default=False)
    create_by: UUIDstr = Field(foreign_key="user.id", nullable=False)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    # Relationships
    user: Optional["User"] = Relationship(
        sa_relationship_kwargs={"foreign_keys": "ResourcePermission.user_id"}
    )
    creator: Optional["User"] = Relationship(
        sa_relationship_kwargs={"foreign_keys": "ResourcePermission.create_by"}
    )

    
class ResourcePermissionCreate(SQLModel):
    user_id: UUIDstr = Field()
    resource_id: UUIDstr = Field()
    resource_type: str = Field()
    has_read_permission: bool = Field(default=False)
    create_by: UUIDstr = Field()


class ResourcePermissionRead(SQLModel):
    id: UUIDstr = Field()
    user_id: UUIDstr = Field()
    resource_id: UUIDstr = Field()
    resource_type: str = Field()
    has_read_permission: bool = Field()
    create_by: UUIDstr = Field()
    create_at: datetime = Field()
    updated_at: datetime = Field()


class ResourcePermissionUpdate(SQLModel):
    user_id: Optional[UUIDstr] = Field(default=None)
    resource_id: Optional[UUIDstr] = Field(default=None)
    resource_type: Optional[str] = Field(default=None)
    has_read_permission: Optional[bool] = Field(default=None)
    updated_at: Optional[datetime] = Field(default=None)
