from enum import Enum

class ResourceTypes(Enum):
    AGENT_FLOW = "AGENT_FLOW"
    MCP = "MCP" # model.MCPServer
    DATABASE = "DATABASE" # model.Datasource
    ML_MODEL = "ML_MODEL"
    SELF_HOSTED_VDB = "SELF_HOSTED_VDB" # model.VdbUploadHistory
    PROJECT_FOLDER = "PROJECT_FOLDER" # model.Folder