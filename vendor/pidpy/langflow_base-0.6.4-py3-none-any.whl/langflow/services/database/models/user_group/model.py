from datetime import datetime, timezone
from uuid import UUID, uuid4
from typing import TYPE_CHECKING, Optional

from sqlmodel import Field, SQLModel, Relationship

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.user.model import User
    from langflow.services.database.models.group.model import Group

class UserGroup(SQLModel, table=True):  # type: ignore[call-arg]
    '''
    Membership.
    Many to many between users and groups.
    '''
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    user_id: UUIDstr = Field(foreign_key="user.id", nullable=False)
    group_id: UUIDstr = Field(foreign_key="group.id", nullable=False)
    joined_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    is_group_admin: bool = Field(default=False)
    create_by: UUIDstr = Field(default=None, nullable=False)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # Relationships
    user: "User" = Relationship(back_populates="user_groups")
    group: "Group" = Relationship(back_populates="user_groups")


class MembershipCreate(SQLModel):
    user_id: UUIDstr = Field()
    group_id: UUIDstr = Field()
    is_group_admin: bool = Field(default=False)
    create_by: UUIDstr = Field()


class MembershipRead(SQLModel):
    id: UUIDstr = Field()
    user_id: UUIDstr = Field()
    group_id: UUIDstr = Field()
    joined_at: datetime = Field()
    is_group_admin: bool = Field()
    create_by: UUIDstr = Field()
    create_at: datetime = Field()
    updated_at: datetime = Field()


class MembershipUpdate(SQLModel):
    group_id: Optional[UUIDstr] = None
    is_group_admin: Optional[bool] = None
    updated_at: Optional[datetime] = Field(default_factory=lambda: datetime.now(timezone.utc))
