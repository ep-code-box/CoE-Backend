from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.attributes import flag_modified
from sqlalchemy.orm import selectinload
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.user_group.model import UserGroup, MembershipUpdate, MembershipCreate
from langflow.services.database.models.resource_permission.crud import (
    delete_resource_permissions_by_user_ids,
)


async def get_membership_by_id(db: AsyncSession, membership_id: UUID) -> UserGroup | None:
    if isinstance(membership_id, str):
        membership_id = UUID(membership_id)
    stmt = select(UserGroup).where(UserGroup.id == membership_id)
    return (await db.exec(stmt)).first()


async def get_one_membership_by_user_id(db: AsyncSession, user_id: UUID) -> UserGroup | None:
    if isinstance(user_id, str):
        user_id = UUID(user_id)
    stmt = select(UserGroup).where(UserGroup.user_id == user_id)
    return (await db.exec(stmt)).first()


async def get_one_admin_membership_by_group_id(db: AsyncSession, group_id: UUID) -> UserGroup | None:
    """Get the first group admin of a group."""
    if isinstance(group_id, str):
        group_id = UUID(group_id)
    stmt = select(UserGroup).where(
        UserGroup.group_id == group_id,
        UserGroup.is_group_admin == True
    ).options(selectinload(UserGroup.user))
    return (await db.exec(stmt)).first()


async def update_membership(membership_old: UserGroup | None, membership: MembershipUpdate,
                            db: AsyncSession) -> UserGroup:
    '''Need to optimize this function, currently it will trigger too many queries when updating group membership'''
    if not membership_old:
        raise HTTPException(status_code=404, detail="Membership not found")

    user_group_data = membership.model_dump(exclude_unset=True)

    # If the group is changing, delete all resource permissions for this user, and create new permissions for the new group
    new_group_id = user_group_data.get("group_id")
    if new_group_id is not None and new_group_id != membership_old.group_id:
        await delete_resource_permissions_by_user_ids(db, [membership_old.user_id])

    # Check if trying to set is_group_admin to True
    if user_group_data.get("is_group_admin") is True:
        # Check if another user in the same group is already admin
        admin_membership = await get_one_admin_membership_by_group_id(db, membership_old.group_id)
        if admin_membership and admin_membership.user_id != membership_old.user_id:
            # Override: remove admin from existing admin user
            admin_membership.is_group_admin = False
            admin_membership.updated_at = datetime.now(timezone.utc)
            flag_modified(admin_membership, "is_group_admin")
            flag_modified(admin_membership, "updated_at")
            db.add(admin_membership)
    
    changed = False
    for attr, value in user_group_data.items():
        if hasattr(membership_old, attr) and value is not None:
            setattr(membership_old, attr, value)
            changed = True

    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")

    membership_old.updated_at = datetime.now(timezone.utc)
    flag_modified(membership_old, "updated_at")

    try:
        await db.commit()
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return membership_old


async def update_membership_by_id(membership_id: UUID, membership: MembershipUpdate, db: AsyncSession) -> UserGroup:
    membership_old = await get_membership_by_id(db, membership_id)
    return await update_membership(membership_old, membership, db)


async def create_membership(db: AsyncSession, membership: MembershipCreate) -> UserGroup:
    new_membership = UserGroup(**membership.model_dump())
    db.add(new_membership)

    try:
        await db.commit()
        await db.refresh(new_membership)
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)) from e

    return new_membership


async def create_many_memberships(db: AsyncSession, memberships: list[MembershipCreate]) -> list[UserGroup]:
    new_memberships = [UserGroup(**m.model_dump()) for m in memberships]
    db.add_all(new_memberships)

    try:
        await db.commit()
        for m in new_memberships:
            await db.refresh(m)
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e)) from e

    return new_memberships


async def delete_many_memberships(db: AsyncSession, user_ids: list[UUID]) -> None:
    user_ids = [UUID(uid) if isinstance(uid, str) else uid for uid in user_ids]
    stmt = select(UserGroup).where(UserGroup.user_id.in_(user_ids))
    memberships = (await db.exec(stmt)).all()
    for membership in memberships:
        await db.delete(membership)
    await db.commit()


async def delete_one_membership(db: AsyncSession, membership_id: UUID) -> None:
    if isinstance(membership_id, str):
        membership_id = UUID(membership_id)
    membership = await get_membership_by_id(db, membership_id)
    if not membership:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Membership not found")
    await db.delete(membership)
    await db.commit()

async def get_membership_by_user_id_and_group_id(db: AsyncSession, user_id: UUID, group_id: UUID) -> UserGroup | None:
    stmt = select(UserGroup).where(
        UserGroup.user_id == user_id,
        UserGroup.group_id == group_id
    )
    return (await db.exec(stmt)).first()

