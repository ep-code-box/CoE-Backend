import asyncio
from uuid import UUID
import boto3
from botocore.exceptions import ClientError, BotoCoreError
from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from .model import DatasourceS3, DatasourceS3Update


async def get_datasource_s3_by_datasource_id(db: AsyncSession, datasource_id: UUID) -> DatasourceS3 | None:
    if isinstance(datasource_id, str):
        datasource_id = UUID(datasource_id)
    stmt = select(DatasourceS3).where(DatasourceS3.datasource_id == datasource_id)
    return (await db.exec(stmt)).first()


async def update_datasource_s3(s3_db: DatasourceS3 | None, s3_data: DatasourceS3Update,
                                db: AsyncSession) -> DatasourceS3:
    if not s3_db:
        raise HTTPException(status_code=404, detail="DatasourceS3 not found")

    s3_update_data = s3_data.model_dump(exclude_unset=True)
    changed = False
    for attr, value in s3_update_data.items():
        if hasattr(s3_db, attr) and value is not None:
            setattr(s3_db, attr, value)
            changed = True

    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")

    try:
        await db.commit()
        await db.refresh(s3_db)
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return s3_db


async def s3_perform_connect(session, datasource_id: UUID = None, connection_config: dict = None):
    """Create and return an S3 client based on datasource ID or connection config."""
    if not connection_config:
        raise HTTPException(
            status_code=400, 
            detail="Connection config is required"
        )

    region, public_key, secret_key = await get_connection_config(
        session,
        datasource_id,
        connection_config.get('aws_s3_region'),
        connection_config.get('aws_s3_public_key'),
        connection_config.get('aws_s3_secret_key')
    )
    
    return await asyncio.to_thread(_sync_s3_connect, public_key, secret_key, region)


def _sync_s3_connect(public_key, secret_key, region):
    """
    Synchronous blocking S3 client creation — intended to be run via asyncio.to_thread.
    """
    try:
        s3_client = boto3.client(
            's3',
            aws_access_key_id=public_key,
            aws_secret_access_key=secret_key
        )
    except ClientError as e:
        raise HTTPException(
            status_code=400,
            detail=f"ClientError: {str(e)}"
        ) from e
    except BotoCoreError as e:
        raise HTTPException(
            status_code=400,
            detail=f"BotoCore error: {str(e)}"
        ) from e
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Exception: {str(e)}"
        ) from e

    return s3_client, region


async def get_connection_config(
    session,
    datasource_id,
    aws_s3_region,
    aws_s3_public_key,
    aws_s3_secret_key
):
    """Get S3 connection configuration from database or parameters."""
    if datasource_id:
        config = await get_datasource_s3_by_datasource_id(session, datasource_id)
        if not config:
            raise HTTPException(status_code=404, detail="S3 configuration not found")
        
        region = config.aws_s3_region
        public_key = config.aws_s3_public_key
        secret_key = config.aws_s3_secret_key
    else:
        if not all([aws_s3_region, aws_s3_public_key, aws_s3_secret_key]):
            raise HTTPException(
                status_code=400,
                detail="Connection requires aws_s3_region, aws_s3_public_key, and aws_s3_secret_key"
            )
        
        region = aws_s3_region
        public_key = aws_s3_public_key
        secret_key = aws_s3_secret_key
    
    return region, public_key, secret_key