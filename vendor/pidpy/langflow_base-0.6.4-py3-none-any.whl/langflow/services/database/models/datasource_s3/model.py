from uuid import uuid4
from typing import Optional, TYPE_CHECKING, Any

from sqlmodel import Field, SQLModel, Relationship, Column
from sqlalchemy import JSON

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.datasource.model import Datasource

class DatasourceS3(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    datasource_id: UUIDstr = Field(foreign_key="datasource.id", nullable=False, unique=True)
    aws_s3_region: str = Field(nullable=False)
    aws_s3_public_key: str = Field(nullable=False)
    aws_s3_secret_key: str = Field(nullable=False)
    schema_stored_value: Optional[dict[str, Any]] = Field(default=None, sa_column=Column(JSON, nullable=True))
    
    # Relationship to Datasource
    datasource: Optional["Datasource"] = Relationship(back_populates="s3_config")


class DatasourceS3Create(SQLModel):
    datasource_id: UUIDstr = Field()
    aws_s3_region: str = Field()
    aws_s3_public_key: str = Field()
    aws_s3_secret_key: str = Field()
    schema_stored_value: Optional[dict[str, Any]] = Field(default=None, nullable=True)


class DatasourceS3Read(SQLModel):
    id: UUIDstr = Field()
    datasource_id: UUIDstr = Field()
    aws_s3_region: str = Field()
    aws_s3_public_key: str = Field()
    aws_s3_secret_key: str = Field()
    schema_stored_value: Optional[dict[str, Any]] = Field(default=None, nullable=True)


class DatasourceS3Update(SQLModel):
    datasource_id: Optional[UUIDstr] | None = None
    aws_s3_region: Optional[str] | None = None
    aws_s3_public_key: Optional[str] | None = None
    aws_s3_secret_key: Optional[str] | None = None
    schema_stored_value: Optional[dict[str, Any]] | None = None
