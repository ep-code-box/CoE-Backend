from datetime import datetime, timezone
from enum import Enum
from typing import TYPE_CHECKING
from uuid import UUID, uuid4

from sqlalchemy import Text
from sqlmodel import JSON, Column, DateTime, Field, Relationship, SQLModel, func

if TYPE_CHECKING:
    from langflow.services.database.models.mcp.models import MCPServer
    from langflow.services.database.models.user.model import User


def utc_now():
    return datetime.now(timezone.utc)


class HTTPMethod(str, Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"



class MCPToolStatusEnum(str, Enum):
    PENDING = "PENDING"
    REJECTED = "REJECTED"
    ACTIVE = "ACTIVE"


class MCPToolConfig(SQLModel):
    http_method: HTTPMethod = Field(description="HTTP method for the API call")
    path_template: str = Field(description="URL path template with placeholders")
    input_schema: dict = Field(sa_column=Column(JSON), description="JSON schema for input validation")
    path_mapping: dict = Field(sa_column=Column(JSON), description="Mapping of input fields to path parameters")
    query_mapping: dict = Field(sa_column=Column(JSON), description="Mapping of input fields to query parameters")
    headers_mapping: dict = Field(sa_column=Column(JSON), description="Mapping of input fields to headers")
    body_mapping: dict = Field(sa_column=Column(JSON), description="Mapping of input fields to request body")
    raw_body_key: str | None = Field(default=None, description="Key for raw body content")
    response_mapping: str | None = Field(default=None, sa_column=Column(Text, nullable=True), description="JSONPath for response extraction")


class MCPTool(MCPToolConfig, table=True):  # type: ignore[call-arg]
    __tablename__ = "mcp_tool"

    id: UUID | None = Field(default_factory=uuid4, primary_key=True, unique=True)
    name: str = Field(description="Name of the MCP tool")
    description: str | None = Field(default=None, description="Description of the MCP tool", sa_column=Column(Text, nullable=True))
    status: MCPToolStatusEnum = Field(default=MCPToolStatusEnum.ACTIVE, description="Status of the MCP tool")
    created_at: datetime | None = Field(
        default=None,
        sa_column=Column(DateTime(timezone=True), server_default=func.now(), nullable=False),
        description="Creation time of the MCP tool",
    )
    updated_at: datetime | None = Field(
        default=None,
        sa_column=Column(DateTime(timezone=True), onupdate=func.now(), nullable=True),
        description="Last update time of the MCP tool",
    )

    # Foreign key to user table
    user_id: UUID = Field(description="User ID who created this MCP tool", foreign_key="user.id")
    user: "User" = Relationship(back_populates="mcp_tools")

    # Foreign key to MCP Server table
    mcp_server_id: UUID = Field(description="MCP Server ID this tool belongs to", foreign_key="mcp_server.id")
    mcp_server: "MCPServer" = Relationship(back_populates="mcp_tools")


class MCPToolCreate(SQLModel):
    name: str = Field(description="Name of the MCP tool")
    description: str | None = Field(default=None, description="Description of the MCP tool")
    http_method: HTTPMethod = Field(description="HTTP method for the API call")
    path_template: str = Field(description="URL path template with placeholders")
    input_schema: dict = Field(description="JSON schema for input validation")
    path_mapping: dict = Field(default_factory=dict, description="Mapping of input fields to path parameters")
    query_mapping: dict = Field(default_factory=dict, description="Mapping of input fields to query parameters")
    headers_mapping: dict = Field(default_factory=dict, description="Mapping of input fields to headers")
    body_mapping: dict = Field(default_factory=dict, description="Mapping of input fields to request body")
    raw_body_key: str | None = Field(default=None, description="Key for raw body content")
    response_mapping: str | None = Field(default=None, description="JSONPath for response extraction")
    mcp_server_id: UUID = Field(description="MCP Server ID this tool belongs to")


class MCPToolUpdate(SQLModel):
    name: str | None = Field(default=None, description="Name of the MCP tool")
    description: str | None = Field(default=None, description="Description of the MCP tool")
    status: MCPToolStatusEnum | None = Field(default=None, description="Status of the MCP tool")
    http_method: HTTPMethod | None = Field(default=None, description="HTTP method for the API call")
    path_template: str | None = Field(default=None, description="URL path template with placeholders")
    input_schema: dict | None = Field(default=None, description="JSON schema for input validation")
    path_mapping: dict | None = Field(default=None, description="Mapping of input fields to path parameters")
    query_mapping: dict | None = Field(default=None, description="Mapping of input fields to query parameters")
    headers_mapping: dict | None = Field(default=None, description="Mapping of input fields to headers")
    body_mapping: dict | None = Field(default=None, description="Mapping of input fields to request body")
    raw_body_key: str | None = Field(default=None, description="Key for raw body content")
    response_mapping: str | None = Field(default=None, description="JSONPath for response extraction")


class MCPToolList(SQLModel):
    """MCP Tool model for list endpoints (excludes detailed mappings for performance)."""

    id: UUID
    name: str
    description: str | None = None
    status: MCPToolStatusEnum
    http_method: HTTPMethod
    path_template: str
    created_at: datetime
    updated_at: datetime | None = None
    user_id: UUID
    mcp_server_id: UUID


class MCPToolRead(MCPToolList):
    """MCP Tool model for detail endpoints (includes all configuration)."""

    input_schema: dict
    path_mapping: dict
    query_mapping: dict
    headers_mapping: dict
    body_mapping: dict
    raw_body_key: str | None = None
    response_mapping: str | None = None
