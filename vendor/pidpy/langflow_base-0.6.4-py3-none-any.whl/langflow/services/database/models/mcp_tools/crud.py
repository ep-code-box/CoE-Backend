from datetime import datetime, timezone
from typing import TYPE_CHECKING
from uuid import UUID

from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.mcp_tools.models import (
    HTTPMethod,
    MCPTool,
    MCPToolCreate,
    MCPToolList,
    MCPToolRead,
    MCPToolUpdate,
    MCPToolStatusEnum,
)

if TYPE_CHECKING:
    from sqlmodel.sql.expression import SelectOfScalar


async def get_mcp_tool_list(
    session: AsyncSession,
    sort_by: str = "created_at",
    sort_direction: str = "desc",
    filter_by: dict | None = None,
    page: int = 1,
    page_size: int = 10,
) -> tuple[list[MCPToolList], int]:
    """Get a paginated and filtered list of all MCP tools.
    
    Args:
        session: Database session
        sort_by: Field to sort by (name, created_at, updated_at, status)
        sort_direction: Sort direction ('asc' or 'desc')
        filter_by: Dictionary of field names and values to filter by
        page: Page number (1-indexed)
        page_size: Number of items per page
        
    Returns:
        Tuple of (list of MCPToolList objects, total count)
    """
    # Base query
    query: SelectOfScalar = select(MCPTool)
    
    # Apply filters
    if filter_by:
        for field, value in filter_by.items():
            if value is not None:
                if field == "status" and isinstance(value, str):
                    # Handle status enum filtering
                    try:
                        status_enum = MCPToolStatusEnum(value)
                        query = query.where(MCPTool.status == status_enum)
                    except ValueError:
                        pass  # Invalid enum value, skip this filter
                elif field == "http_method" and isinstance(value, str):
                    # Handle HTTP method enum filtering
                    try:
                        method_enum = HTTPMethod(value)
                        query = query.where(MCPTool.http_method == method_enum)
                    except ValueError:
                        pass  # Invalid enum value, skip this filter
                elif field == "name":
                    # Partial match for name
                    query = query.where(MCPTool.name.contains(value))
                elif field == "mcp_server_id" and isinstance(value, (str, UUID)):
                    query = query.where(MCPTool.mcp_server_id == value)
                elif hasattr(MCPTool, field):
                    query = query.where(getattr(MCPTool, field) == value)
    
    # Count total items before pagination (using the filtered query)
    total_count = len((await session.exec(query)).all())
    
    # Apply sorting
    sort_field = getattr(MCPTool, sort_by, MCPTool.created_at)
    if sort_direction.lower() == "asc":
        query = query.order_by(sort_field.asc())
    else:
        query = query.order_by(sort_field.desc())
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    mcp_tools = (await session.exec(query)).all()
    
    # Convert to list models (without detailed config for performance)
    mcp_tool_list = [MCPToolList.model_validate(tool, from_attributes=True) for tool in mcp_tools]
    
    return mcp_tool_list, total_count


async def create_mcp_tool(
    session: AsyncSession, mcp_tool_create: MCPToolCreate, user_id: UUID
) -> MCPToolRead:
    """Create a new MCP tool.
    
    Args:
        session: Database session
        mcp_tool_create: MCP tool creation data
        user_id: User ID who creates the tool
        
    Returns:
        Created MCP tool as MCPToolRead
    """
    mcp_tool = MCPTool(
        name=mcp_tool_create.name,
        description=mcp_tool_create.description,
        http_method=mcp_tool_create.http_method,
        path_template=mcp_tool_create.path_template,
        input_schema=mcp_tool_create.input_schema,
        path_mapping=mcp_tool_create.path_mapping,
        query_mapping=mcp_tool_create.query_mapping,
        headers_mapping=mcp_tool_create.headers_mapping,
        body_mapping=mcp_tool_create.body_mapping,
        raw_body_key=mcp_tool_create.raw_body_key,
        response_mapping=mcp_tool_create.response_mapping,
        user_id=user_id,
        mcp_server_id=mcp_tool_create.mcp_server_id,
        created_at=datetime.now(timezone.utc),
    )
    
    session.add(mcp_tool)
    await session.commit()
    await session.refresh(mcp_tool)
    
    return MCPToolRead.model_validate(mcp_tool, from_attributes=True)


async def update_mcp_tool(
    session: AsyncSession, mcp_tool_id: UUID, mcp_tool_update: MCPToolUpdate, user_id: UUID
) -> MCPToolRead:
    """Update an existing MCP tool.
    
    Args:
        session: Database session
        mcp_tool_id: ID of the MCP tool to update
        mcp_tool_update: Updated MCP tool data
        user_id: User ID who owns the tool
        
    Returns:
        Updated MCP tool as MCPToolRead
        
    Raises:
        ValueError: If MCP tool not found or user doesn't own it
    """
    mcp_tool = await session.get(MCPTool, mcp_tool_id)
    
    if mcp_tool is None:
        msg = "MCP Tool not found"
        raise ValueError(msg)
    
    # Update only the fields that are provided
    update_data = mcp_tool_update.model_dump(exclude_unset=True)
    changed = False
    
    for field, value in update_data.items():
        if value is not None and hasattr(mcp_tool, field):
            setattr(mcp_tool, field, value)
            changed = True
    
    if changed:
        mcp_tool.updated_at = datetime.now(timezone.utc)
        flag_modified(mcp_tool, "updated_at")
        session.add(mcp_tool)
        await session.commit()
        await session.refresh(mcp_tool)
    
    return MCPToolRead.model_validate(mcp_tool, from_attributes=True)


async def delete_mcp_tool(session: AsyncSession, mcp_tool_id: UUID, user_id: UUID) -> None:
    """Delete an MCP tool.
    
    Args:
        session: Database session
        mcp_tool_id: ID of the MCP tool to delete
        user_id: User ID who owns the tool
        
    Raises:
        ValueError: If MCP tool not found or user doesn't own it
    """
    mcp_tool = await session.get(MCPTool, mcp_tool_id)
    
    if mcp_tool is None:
        msg = "MCP Tool not found"
        raise ValueError(msg)
    
    await session.delete(mcp_tool)
    await session.commit()


async def get_mcp_tool_by_id(session: AsyncSession, mcp_tool_id: UUID) -> MCPTool | None:
    """Get an MCP tool by ID.
    
    Args:
        session: Database session
        mcp_tool_id: ID of the MCP tool
        
    Returns:
        MCP tool or None if not found
    """
    query: SelectOfScalar = select(MCPTool).where(MCPTool.id == mcp_tool_id)
    return (await session.exec(query)).first()
