from datetime import datetime, timezone
from uuid import UUID, uuid4
from typing import TYPE_CHECKING, Any, Optional

from sqlalchemy import Column, JSON
from sqlmodel import Field, Relationship, SQLModel

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.agent_flow.model import AgentFlow
    from langflow.services.database.models.user.model import User

class MasterData(SQLModel, table=True):  # type: ignore[call-arg]
    '''
    Miscellaneous configuration data.
    '''
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    name: str = Field(index=True, nullable=False)
    type: Optional[str] = Field(default=None, nullable=True)
    value: Optional[dict] = Field(default=None, sa_column=Column(JSON, nullable=True))
    search_field: str = Field(default="", index=True, nullable=True)
    create_by: UUIDstr = Field(default=None, foreign_key="user.id", nullable=False)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    creator: Optional["User"] = Relationship(back_populates="master_data")
    agent_flows: list["AgentFlow"] = Relationship(back_populates="masterdata")

    def update_search_field(self) -> None:
        """Update the search_field"""
        conditions = [self.name, self.type, str(self.value) if self.value is not None else None]
        self.search_field = "_".join(condition for condition in conditions if condition is not None)


class MasterDataCreate(SQLModel):
    name: str = Field()
    type: Optional[str] = Field(default=None)
    value: Optional[dict[str, Any]] = Field(default=None)
    create_by: Optional[UUIDstr] = Field(default=None)


class MasterDataRead(SQLModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = Field()
    type: Optional[str] = Field(default=None)
    value: Optional[dict[str, Any]] = Field(default=None)
    create_by: UUIDstr = Field()
    create_at: datetime = Field()
    updated_at: datetime = Field()


class MasterDataUpdate(SQLModel):
    name: Optional[str] | None = None
    type: Optional[str] | None = None
    value: Optional[dict[str, Any]] | None = None
    updated_at: datetime = None
