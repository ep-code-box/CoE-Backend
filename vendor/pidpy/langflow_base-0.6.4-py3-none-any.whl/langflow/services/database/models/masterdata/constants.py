from enum import Enum

class MasterDataTypes(Enum):
    SYSTEM_CONFIG = "SYSTEM_CONFIG"
    HOMEPAGE_OPTIONS = "HOMEPAGE_OPTIONS"
    LANGGRAPH_GROUP = "LANGGRAPH_GROUP"
    AGENT_FLOW_CONTEXT = "AGENT_FLOW_CONTEXT"


SYSTEM_CONFIG_OPTIONS = [
    {
        "type": MasterDataTypes.SYSTEM_CONFIG.value,
        "name": "Group Cost Limit",
        "value": {"value": 100.0, "description": "Default group cost limit"}
    }
]


DEFAULT_HOMEPAGE_OPTIONS = [
    {
        "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
        "name": "데이터 소스",
        "value": {"icon": "Database", "description": "VectorDB, RDB, S3 연결 및 관리"}
    },
    {
        "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
        "name": "MCP 서버",
        "value": {"icon": "Plug", "description": "MCP 연결 및 Tool 관리"}
    },
    # {
    #     "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
    #     "name": "AI 모델",
    #     "value": {"icon": "Bot", "description": "AI 모델 카탈로그 및 연결"}
    # },
    {
        "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
        "name": "MCP 생성",
        "value": {"icon": "GitMerge", "description": "새로운 MCP 서버 생성"}
    },
    {
        "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
        "name": "Vector DB 생성",
        "value": {"icon": "HardDrive", "description": "Vector Database 생성 및 관리"}
    },
    # {
    #     "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
    #     "name": "ML Studio",
    #     "value": {"icon": "Brain", "description": "MLflow 실험 및 모델 관리"}
    # },
    {
        "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
        "name": "My Agents",
        "value": {"icon": "Users", "description": "생성한 Agent Flow 목록"}
    },
    # {
    #     "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
    #     "name": "사용 가이드",
    #     "value": {"icon": "BookOpen", "description": "AX Studio 사용법 안내"}
    # },
    {
        "type": MasterDataTypes.HOMEPAGE_OPTIONS.value,
        "name": "자주 묻는 질문",
        "value": {"icon": "CircleQuestionMark", "description": "FAQ 및 문제 해결"}
    }
]


DEFAULT_LANGGRAPH_GROUP = [
    {
        "type": MasterDataTypes.LANGGRAPH_GROUP.value, 
        "name": "그룹 A"
    },
    {
        "type": MasterDataTypes.LANGGRAPH_GROUP.value, 
        "name": "그룹 B"
    },
    {
        "type": MasterDataTypes.LANGGRAPH_GROUP.value,
        "name": "그룹 C"
    },
    {
        "type": MasterDataTypes.LANGGRAPH_GROUP.value, 
        "name": "개인 그룹"
    }
]


DEFAULT_AGENT_FLOW_CONTEXT = [
    {
        "type": MasterDataTypes.AGENT_FLOW_CONTEXT.value, 
        "name": "Aider"
    },
    {
        "type": MasterDataTypes.AGENT_FLOW_CONTEXT.value, 
        "name": "continue.dev"
    },
    {
        "type": MasterDataTypes.AGENT_FLOW_CONTEXT.value, 
        "name": "Chat box"
    },
    {
        "type": MasterDataTypes.AGENT_FLOW_CONTEXT.value,
        "name": "Operation System"
    },
    {
        "type": MasterDataTypes.AGENT_FLOW_CONTEXT.value, 
        "name": "BSS System"
    }
]
