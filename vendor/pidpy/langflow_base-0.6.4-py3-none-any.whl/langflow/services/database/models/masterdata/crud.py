from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException
from lfx.log.logger import logger
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.masterdata.model import MasterData, MasterDataUpdate
from langflow.services.database.models.masterdata.constants import (
    MasterDataTypes,
    SYSTEM_CONFIG_OPTIONS,
    DEFAULT_HOMEPAGE_OPTIONS,
    DEFAULT_LANGGRAPH_GROUP,
    DEFAULT_AGENT_FLOW_CONTEXT,
)


async def get_masterdata_by_id(db: AsyncSession, masterdata_id: UUID) -> MasterData | None:
    if isinstance(masterdata_id, str):
        masterdata_id = UUID(masterdata_id)
    stmt = select(MasterData).where(MasterData.id == masterdata_id)
    return (await db.exec(stmt)).first()


async def get_masterdata_by_name(db: AsyncSession, name: str, masterdata_type=None) -> MasterData | None:
    stmt = select(MasterData).where(MasterData.name == name)
    if masterdata_type:
        stmt = stmt.where(MasterData.type == masterdata_type)
    return (await db.exec(stmt)).first()


async def get_first_three_homepage_config(db: AsyncSession) -> list[MasterData]:
    stmt = select(MasterData).where(MasterData.type == MasterDataTypes.HOMEPAGE_OPTIONS.value).limit(3)
    result = await db.exec(stmt)
    return list(result.all())


def get_all_default_masterdata():
    """Get all default masterdata entries."""
    return SYSTEM_CONFIG_OPTIONS + DEFAULT_HOMEPAGE_OPTIONS + DEFAULT_LANGGRAPH_GROUP + DEFAULT_AGENT_FLOW_CONTEXT


async def create_default_masterdatas(db: AsyncSession, system_user_id: UUID | str) -> list[MasterData]:
    """Create default user masterdatas if they don't exist.
    
    Args:
        db: The database session
        system_user_id: The ID of the system user who creates the masterdatas (UUID or string)
        
    Returns:
        List of created or existing default masterdatas
    """
    # Ensure system_user_id is a UUID object
    if isinstance(system_user_id, str):
        system_user_id = UUID(system_user_id)
    
    created_masterdatas = []
    default_masterdatas = get_all_default_masterdata()
    
    for masterdata_data in default_masterdatas:
        masterdata_name = masterdata_data["name"]
        masterdata_type = masterdata_data["type"]
        masterdata_value = masterdata_data.get("value")
        
        # Check if masterdata already exists
        existing_masterdata = await get_masterdata_by_name(db, masterdata_name, masterdata_type=masterdata_type)
        
        if existing_masterdata:
            await logger.adebug(f"MasterData '{masterdata_name}' already exists, skipping creation")
            created_masterdatas.append(existing_masterdata)
            continue
        
        # Create new masterdata
        try:
            new_masterdata = MasterData(
                name=masterdata_name,
                type=masterdata_type,
                value=masterdata_value,
                create_by=system_user_id
            )
            db.add(new_masterdata)
            new_masterdata.update_search_field()
            await db.commit()
            await db.refresh(new_masterdata)
            await logger.adebug(f"Created default masterdata: {masterdata_name}")
            created_masterdatas.append(new_masterdata)
        except IntegrityError as e:
            await db.rollback()
            await logger.aerror(f"Error creating masterdata '{masterdata_name}': {e}")
            # Try to fetch the masterdata again in case of race condition
            existing_masterdata = await get_masterdata_by_name(db, masterdata_name)
            if existing_masterdata:
                created_masterdatas.append(existing_masterdata)
    
    return created_masterdatas


async def update_masterdata(masterdata_db: MasterData | None, masterdata_update: MasterDataUpdate,
                            db: AsyncSession) -> MasterData:
    if not masterdata_db:
        raise HTTPException(status_code=404, detail="MasterData not found")

    masterdata_data = masterdata_update.model_dump(exclude_unset=True)
    changed = False
    for attr, value in masterdata_data.items():
        if hasattr(masterdata_db, attr) and value is not None:
            setattr(masterdata_db, attr, value)
            changed = True

    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")

    masterdata_db.updated_at = datetime.now(timezone.utc)
    masterdata_db.update_search_field()
    flag_modified(masterdata_db, "updated_at")

    try:
        await db.commit()
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return masterdata_db


def validate_masterdata_info(request):
    if not 1 <= len(request.name) <= 50:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="MasterData name must be between 1 and 50 characters long.",
        )
