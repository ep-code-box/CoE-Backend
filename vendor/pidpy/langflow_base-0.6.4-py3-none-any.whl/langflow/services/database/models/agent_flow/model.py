from datetime import datetime, timezone
from uuid import uuid4
from .constants import AgentFlowStatus
from typing import TYPE_CHECKING, Optional

from sqlmodel import Field, Relationship, SQLModel

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.user.model import User
    from langflow.services.database.models.masterdata.model import MasterData
    from langflow.services.database.models.group.model import Group

class AgentFlow(SQLModel, table=True):  # type: ignore[call-arg]
    '''
    Exported Flows.
    may need revision.
    '''
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    lf_flow_id: UUIDstr = Field(default=None, nullable=False)
    name: str = Field(index=True, nullable=False)
    status: str = Field(default=AgentFlowStatus.PENDING.value, nullable=False)
    description: Optional[str] = Field(default=None, nullable=True)
    endpoint: Optional[str] = Field(default=None, nullable=True)
    context: Optional[str] = Field(default=None, nullable=True)
    flow_operation: Optional[bool] = Field(default=False)
    save_with_api_key: Optional[bool] = Field(default=False)
    last_used: Optional[datetime] = Field(default=None, nullable=True)
    json_setting: Optional[str] = Field(default=None, nullable=True)
    reject_approve_reason: Optional[str] = Field(default=None, nullable=True)
    search_field: str = Field(default="", index=True, nullable=False)
    langgraph_group_id: Optional[UUIDstr] = Field(default=None, foreign_key="masterdata.id", nullable=True)
    group_id: UUIDstr = Field(default=None, foreign_key="group.id", nullable=False)
    create_by: UUIDstr = Field(default=None, foreign_key="user.id", nullable=False)
    approved_by: Optional[UUIDstr] = Field(default=None, foreign_key="user.id", nullable=True)
    creator: Optional["User"] = Relationship(sa_relationship_kwargs={"foreign_keys": "[AgentFlow.create_by]"})
    approver: Optional["User"] = Relationship(sa_relationship_kwargs={"foreign_keys": "[AgentFlow.approved_by]"})
    masterdata: Optional["MasterData"] = Relationship(back_populates="agent_flows")
    group: Optional["Group"] = Relationship()
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    def update_search_field(self) -> None:
        """Update the search_field based on name, description, context, masterdata name"""
        masterdata_name = self.masterdata.name if self.masterdata else None
        search_parts = [self.name, self.description, self.context, masterdata_name]
        self.search_field = "_".join(part for part in search_parts if part)


class ExportedFlowCreate(SQLModel):
    lf_flow_id: UUIDstr = Field()
    name: str = Field()
    status: Optional[str] = Field(default=AgentFlowStatus.PENDING.value)
    description: Optional[str] = None
    endpoint: Optional[str] = None
    context: Optional[str] = None
    flow_operation: Optional[bool] = Field(default=False)
    langgraph_group_id: Optional[UUIDstr] = Field(default=None)
    save_with_api_key: Optional[bool] = Field(default=False)
    json_setting: Optional[str] = None
    reject_approve_reason: Optional[str] = Field(default=None)
    create_by: Optional[UUIDstr] = Field(default=None)
    approved_by: Optional[UUIDstr] = Field(default=None)
    group_id: UUIDstr = Field(default=None)


class ExportedFlowRead(SQLModel):
    id: UUIDstr = Field()
    lf_flow_id: UUIDstr = Field()
    name: str = Field()
    status: str = Field()
    description: Optional[str] = Field()
    endpoint: Optional[str] = Field()
    context: Optional[str] = Field()
    flow_operation: Optional[bool] = Field()
    langgraph_group_id: Optional[UUIDstr] = Field()
    save_with_api_key: Optional[bool] = Field()
    last_used: Optional[datetime] = Field()
    json_setting: Optional[str] = Field()
    reject_approve_reason: Optional[str] = Field()
    search_field: str = Field()
    group_id: UUIDstr = Field()
    group_name: Optional[str] = Field(default=None)
    create_by: UUIDstr = Field()
    create_by_username: Optional[str] = Field(default=None)
    approved_by: Optional[UUIDstr] = Field(default=None)
    approver_name: Optional[str] = Field(default=None)
    create_at: datetime = Field()
    updated_at: datetime = Field()


class ExportedFlowUpdate(SQLModel):
    lf_flow_id: Optional[UUIDstr] | None = None
    name: Optional[str] | None = None
    status: Optional[str] | None = None
    description: Optional[str] | None = None
    endpoint: Optional[str] | None = None
    context: Optional[str] | None = None
    flow_operation: Optional[bool] | None = None
    langgraph_group_id: Optional[UUIDstr] | None = None
    save_with_api_key: Optional[bool] | None = None
    last_used: Optional[datetime] | None = None
    json_setting: Optional[str] | None = None
    reject_approve_reason: Optional[str] | None = None
    search_field: Optional[str] | None = None
    approved_by: Optional[UUIDstr] | None = None
    updated_at: Optional[datetime] = None
