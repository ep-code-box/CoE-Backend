from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.attributes import flag_modified
from sqlalchemy.orm import selectinload
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.agent_flow.model import AgentFlow, ExportedFlowUpdate


async def get_exported_flow_by_id(db: AsyncSession, agent_flow_id: UUID, load_creator: bool = False, load_group: bool = False, load_masterdata: bool = False, load_approver: bool = False) -> AgentFlow | None:
    if isinstance(agent_flow_id, str):
        agent_flow_id = UUID(agent_flow_id)

    stmt = select(AgentFlow).where(AgentFlow.id == agent_flow_id)
    if load_creator:
        stmt = stmt.options(selectinload(AgentFlow.creator))
    if load_group:
        stmt = stmt.options(selectinload(AgentFlow.group))
    if load_masterdata:
        stmt = stmt.options(selectinload(AgentFlow.masterdata))
    if load_approver:
        stmt = stmt.options(selectinload(AgentFlow.approver))

    agent_flow = (await db.exec(stmt)).first()

    if not agent_flow:
        raise HTTPException(status_code=404, detail="Agent flow not found")

    return agent_flow
