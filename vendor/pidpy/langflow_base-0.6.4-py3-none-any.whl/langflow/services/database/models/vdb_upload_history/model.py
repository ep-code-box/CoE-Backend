from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from sqlalchemy import Column, JSON, Text
from sqlmodel import JSON, Column, DateTime, Field, Relationship, SQLModel

from langflow.schema.serialize import UUIDstr
from langflow.services.database.models.vdb_upload_history.constants import VdbUploadStatus, VdbUploadType


class VdbUploadHistory(SQLModel, table=True):  # type: ignore[call-arg]
    """Model for tracking vector database upload history."""
    
    __tablename__ = "vdb_upload_history"
    
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    name: str = Field(index=True, nullable=False)
    description: Optional[str] = Field(default=None, nullable=True)
    collection_name: str = Field(index=True, nullable=False)
    upload_type: VdbUploadType = Field(default=VdbUploadType.DOCUMENT, nullable=False)
    embedding_model_name: Optional[str] = Field(default=None, nullable=True)
    created_by: UUIDstr = Field(default=None, foreign_key="user.id", nullable=False)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    file_metadata: dict = Field(default_factory=dict, sa_column=Column(JSON))
    status: VdbUploadStatus = Field(default=VdbUploadStatus.PENDING, nullable=False)

    task_id: Optional[str] = Field(default=None, nullable=True)
    task_status: dict | None = Field(default=None, sa_column=Column(JSON))

    reviewed_by: UUIDstr | None = Field(default=None, description="User ID who reviewed this", foreign_key="user.id", nullable=True)
    reviewed_at: datetime | None = Field(default=None, description="Timestamp when was reviewed", sa_column=Column(DateTime(timezone=True), nullable=True))
    review_comment: str | None = Field(default=None, description="Review comment for this", sa_column=Column(Text, nullable=True))

    
    # Relationship to User
    creator: Optional["User"] = Relationship(sa_relationship_kwargs={"foreign_keys": "[VdbUploadHistory.created_by]"})  # type: ignore[name-defined]
    
    # Relationship to group
    group_id: UUIDstr = Field(foreign_key="group.id", nullable=False)

    class Config:
        arbitrary_types_allowed = True


class VdbUploadHistoryCreate(SQLModel):
    """Schema for creating a new VDB upload history entry."""
    
    name: str = Field()
    description: Optional[str] = None
    collection_name: str = Field()
    upload_type: VdbUploadType = Field(default=VdbUploadType.DOCUMENT)
    created_by: UUIDstr = Field()
    file_metadata: dict = Field(default_factory=dict)
    status: Optional[VdbUploadStatus] = Field(default=VdbUploadStatus.UPLOADING)
    task_id: Optional[str] = None
    embedding_model_name: Optional[str] = None
    group_id: UUIDstr = Field()


class VdbUploadHistoryRead(SQLModel):
    """Schema for reading VDB upload history."""
    
    id: UUIDstr = Field()
    name: str = Field()
    description: Optional[str] = Field()
    collection_name: str = Field()
    upload_type: VdbUploadType = Field()
    created_by: UUIDstr = Field()
    created_at: datetime = Field()
    file_metadata: dict = Field()
    status: VdbUploadStatus = Field()
    task_id: Optional[str] = Field(default=None)
    task_status: Optional[dict] = Field(default=None)
    embedding_model_name: Optional[str] = Field(default=None)
    created_by_username: Optional[str] = Field(default=None)
    reviewed_by: Optional[UUIDstr] = Field(default=None)
    reviewed_at: Optional[datetime] = Field(default=None)
    review_comment: Optional[str] = Field(default=None)
    group_id: Optional[UUIDstr] = Field(default=None)


class VdbUploadHistoryUpdate(SQLModel):
    """Schema for updating VDB upload history."""
    
    name: Optional[str] = None
    description: Optional[str] = None
    collection_name: Optional[str] = None
    upload_type: Optional[VdbUploadType] = None
    status: Optional[VdbUploadStatus] = None
    file_metadata: Optional[dict] = None
    task_id: Optional[str] = None
    task_status: Optional[dict] = None
    embedding_model_name: Optional[str] = None
    reviewed_by: Optional[UUIDstr] = None
    reviewed_at: Optional[datetime] = None
    review_comment: Optional[str] = None
    group_id: Optional[UUIDstr] = None


class VdbUploadHistoryReview(SQLModel):
    """Schema for reviewing VDB upload history."""
    
    status: VdbUploadStatus = Field()
    review_comment: Optional[str] = Field(default=None)
