from enum import Enum


class VdbUploadStatus(Enum):
    UPLOADING = "UPLOADING"
    UPLOAD_FAILED = "UPLOAD_FAILED"
    PENDING = "PENDING" # upload succeed
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class VdbUploadType(Enum):
    DOCUMENT = "DOCUMENT"
    RAW_VECTOR = "RAW_VECTOR"
    CSV_FILE = "CSV_FILE"
