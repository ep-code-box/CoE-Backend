from uuid import UUID

from fastapi import HTTPException
from sqlalchemy.orm import selectinload
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.vdb_upload_history.model import (
    VdbUploadHistory,
    VdbUploadHistoryCreate,
    VdbUploadHistoryUpdate,
    VdbUploadStatus,
)

from langflow.services.database.models.resource_permission.model import ResourcePermission
from langflow.services.database.models.resource_permission.constants import ResourceTypes

from sqlmodel.sql.expression import SelectOfScalar
from sqlalchemy import func, and_

async def get_vdb_upload_history_list(
    session: AsyncSession,
    sort_by: str = "created_at",
    sort_direction: str = "desc",
    filter_by: dict | None = None,
    page: int = 1,
    page_size: int = 10,
    user_id: UUID | None = None,
    filter_by_permission: bool = False,
) -> tuple[list[VdbUploadHistory], int]:
    ''' get_vdb_upload_history_list '''

    # Base query with eager loading of user relationships
    query: SelectOfScalar = select(VdbUploadHistory).options(
    )

    if filter_by_permission:
        # Regular users can see their own records OR APPROVED records they have permission to access
        query = query.outerjoin(
                ResourcePermission,
                (ResourcePermission.resource_id == VdbUploadHistory.id) &
                (ResourcePermission.resource_type == ResourceTypes.SELF_HOSTED_VDB) &
                (ResourcePermission.has_read_permission == True) &
                (ResourcePermission.user_id == user_id),
            ).where(
                (VdbUploadHistory.created_by == user_id)
                | (
                    (VdbUploadHistory.status == VdbUploadStatus.APPROVED)
                    & (ResourcePermission.resource_id != None)
                )
            )

    # Apply filters
    conditions = []
    if filter_by:
        for key, value in filter_by.items():
            if value is not None and hasattr(VdbUploadHistory, key):
                attr = getattr(VdbUploadHistory, key)
                if isinstance(value, list):
                    conditions.append(attr.in_(value))
                else:
                    conditions.append(attr == value)
    
    if conditions:
        query = query.where(*conditions)

    # Get total count
    count_query = select(func.count()).select_from(query.subquery())
    total = (await session.exec(count_query)).one()

    # Apply sorting
    if hasattr(VdbUploadHistory, sort_by):
        sort_attr = getattr(VdbUploadHistory, sort_by)
        if sort_direction.lower() == "asc":
            query = query.order_by(sort_attr.asc())
        else:
            query = query.order_by(sort_attr.desc())

    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)

    # Execute query
    result = await session.exec(query)
    result = result.all()

    return result, total


async def create_vdb_upload_history(
    db: AsyncSession, upload_data: VdbUploadHistoryCreate
) -> VdbUploadHistory:
    """Create a new VDB upload history entry."""
    upload_history = VdbUploadHistory.model_validate(upload_data, from_attributes=True)
    db.add(upload_history)
    await db.flush()
    await db.refresh(upload_history)
    return upload_history


async def get_vdb_upload_history_by_id(
    db: AsyncSession, upload_id: UUID, load_creator: bool = False
) -> VdbUploadHistory | None:
    """Get a VDB upload history entry by ID."""
    if isinstance(upload_id, str):
        upload_id = UUID(upload_id)

    stmt = select(VdbUploadHistory).options(
        selectinload(VdbUploadHistory.creator)
    ).where(VdbUploadHistory.id == upload_id)
    if load_creator:
        stmt = stmt.options(selectinload(VdbUploadHistory.creator))

    upload_history = (await db.exec(stmt)).first()

    if not upload_history:
        raise HTTPException(status_code=404, detail="Upload history not found")

    return upload_history


async def get_vdb_upload_history_by_collection_name(
    db: AsyncSession,
    collection_name: str,
) -> VdbUploadHistory | None:
    """Get a VDB upload history entry by collection_name."""
    
    query = select(VdbUploadHistory).where(
        (VdbUploadHistory.collection_name == collection_name)
        & (VdbUploadHistory.status != VdbUploadStatus.UPLOAD_FAILED)
    ).order_by(VdbUploadHistory.created_at.asc())
    upload_history = (await db.exec(query)).first()

    if not upload_history:
        return None
    return upload_history



async def update_vdb_upload_history(
    db: AsyncSession, upload_id: UUID, update_data: VdbUploadHistoryUpdate
) -> VdbUploadHistory:
    """Update a VDB upload history entry."""
    upload_history = await get_vdb_upload_history_by_id(db, upload_id)

    for key, value in update_data.model_dump(exclude_unset=True).items():
        setattr(upload_history, key, value)

    await db.flush()
    await db.refresh(upload_history)
    return upload_history


async def delete_vdb_upload_history(db: AsyncSession, upload_id: UUID) -> None:
    """Delete a VDB upload history entry."""
    upload_history = await get_vdb_upload_history_by_id(db, upload_id)
    await db.delete(upload_history)
    await db.flush()
