from datetime import datetime, timezone
from uuid import UUID, uuid4
from typing import TYPE_CHECKING, Optional

from sqlmodel import Field, SQLModel, Relationship

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.user_group.model import UserGroup
    from langflow.services.database.models.datasource.model import Datasource

class Group(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    name: str = Field(index=True, nullable=False, unique=True)
    name_kr: str = Field(default="", nullable=True)
    is_active: bool = Field(default=True, nullable=False)
    description: str = Field(default=None, nullable=True)
    color: str = Field(default=None, nullable=True)
    search_field: str = Field(default="", index=True, nullable=False)
    create_by: UUIDstr = Field(default=None, nullable=False)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    # Relationships
    user_groups: list["UserGroup"] = Relationship(
        back_populates="group",
        sa_relationship_kwargs={"cascade": "delete"},
    )
    datasources: list["Datasource"] = Relationship(
        back_populates="group",
        sa_relationship_kwargs={"cascade": "delete"},
    )

    def update_search_field(self) -> None:
        """Update the search_field"""
        conditions = [self.name, self.name_kr, self.description]
        self.search_field = "_".join(conditions)


class GroupCreate(SQLModel):
    name: str = Field()
    name_kr: Optional[str] = Field(default="")
    is_active: Optional[bool] = Field(default=True)
    description: Optional[str] = None
    color: Optional[str] = None
    create_by: Optional[UUIDstr] = Field(default=None)


class GroupRead(SQLModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = Field()
    name_kr: str = Field()
    is_active: bool = Field()
    description: str = Field()
    color: str = Field()
    total_users: int = Field(default=0)
    total_datasources: int = Field(default=0)
    is_have_group_admin: bool = Field(default=False)
    group_admin_name: Optional[str] = Field(default=None)
    create_by: UUIDstr = Field()
    create_at: datetime = Field()
    updated_at: datetime = Field()


class GroupReadNonAdmin(SQLModel):
    id: UUID = Field(default_factory=uuid4)
    name: str = Field()
    name_kr: str = Field()


class GroupReadMini(SQLModel):
    """Minimal Group model for use in list endpoints."""
    id: UUID = Field()
    name: str = Field()
    name_kr: str = Field()
    color: str = Field()


class GroupUpdate(SQLModel):
    name: Optional[str] | None = None
    name_kr: Optional[str] | None = None
    is_active: Optional[bool] | None = None
    description: Optional[str] | None = None
    color: Optional[str] | None = None
    updated_at: datetime = None
