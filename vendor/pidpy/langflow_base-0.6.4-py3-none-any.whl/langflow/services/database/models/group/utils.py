from uuid import UUID

from lfx.log.logger import logger
from sqlalchemy.exc import IntegrityError
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from .constants import DEFAULT_GROUP_NAME, DEFAULT_GROUPS
from .model import Group


async def get_group_by_name(session: AsyncSession, group_name: str) -> Group | None:
    """Get a group by name."""
    stmt = select(Group).where(Group.name == group_name)
    return (await session.exec(stmt)).first()


async def create_default_groups(session: AsyncSession, create_by: UUID) -> list[Group]:
    """Create default groups if they don't exist.
    
    Args:
        session: The database session
        create_by: The ID of the user who creates the groups
        
    Returns:
        List of created or existing default groups
    """
    created_groups = []
    
    for group_data in DEFAULT_GROUPS:
        group_name = group_data["name"]
        
        # Check if group already exists
        existing_group = await get_group_by_name(session, group_name)
        
        if existing_group:
            await logger.adebug(f"Group '{group_name}' already exists, skipping creation")
            created_groups.append(existing_group)
            continue
        
        # Create new group
        try:
            new_group = Group(
                name=group_data["name"],
                namekr=group_data.get("namekr", ""),
                description=group_data.get("description", ""),
                color=group_data.get("color", "#6366f1"),
                is_active=group_data.get("is_active", True),
                create_by=create_by
            )
            new_group.update_search_field()
            
            session.add(new_group)
            await session.commit()
            await session.refresh(new_group)
            await logger.adebug(f"Created default group: {group_name}")
            created_groups.append(new_group)
        except IntegrityError as e:
            await session.rollback()
            await logger.aerror(f"Error creating group '{group_name}': {e}")
            # Try to fetch the group again in case of race condition
            existing_group = await get_group_by_name(session, group_name)
            if existing_group:
                created_groups.append(existing_group)
    
    return created_groups


async def get_default_group(session: AsyncSession) -> Group | None:
    """Get the default group by name."""
    stmt = select(Group).where(Group.name == DEFAULT_GROUP_NAME)
    return (await session.exec(stmt)).first()
