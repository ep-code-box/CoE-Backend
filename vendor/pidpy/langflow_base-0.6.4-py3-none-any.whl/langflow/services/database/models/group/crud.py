from datetime import datetime, timezone
from uuid import UUID

from fastapi import HTTPException
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.attributes import flag_modified
from sqlalchemy.orm import selectinload
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.group.model import Group, GroupUpdate, GroupCreate
from langflow.services.database.models.group.constants import DEFAULT_GROUP_NAME


async def get_group_by_id(db: AsyncSession, group_id: UUID, load_user_groups: bool = False) -> Group | None:
    if isinstance(group_id, str):
        group_id = UUID(group_id)
    stmt = select(Group).where(Group.id == group_id)
    if load_user_groups:
        stmt = stmt.options(selectinload(Group.user_groups), selectinload(Group.datasources))
    return (await db.exec(stmt)).first()


async def get_all_groups(db: AsyncSession) -> list[Group]:
    """Get all active groups from the database, excluding the default group."""
    stmt = select(Group).where(Group.is_active == True).where(Group.name != DEFAULT_GROUP_NAME)
    result = await db.exec(stmt)
    return result.all()


async def create_group(db: AsyncSession, group_data: GroupCreate) -> Group:
    """Create a new group."""
    group = Group(
        name=group_data.name,
        description=group_data.description,
        color=group_data.color,
        is_active=group_data.is_active if group_data.is_active is not None else True,
        create_by=group_data.create_by
    )
    group.update_search_field()
    
    db.add(group)
    try:
        await db.commit()
        await db.refresh(group)
        return group
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=f"Error creating group: {str(e)}") from e


async def update_group(group_db: Group | None, group: GroupUpdate,
                            db: AsyncSession) -> Group:
    if not group_db:
        raise HTTPException(status_code=404, detail="Group not found")

    group_data = group.model_dump(exclude_unset=True)
    changed = False
    for attr, value in group_data.items():
        if hasattr(group_db, attr) and value is not None:
            setattr(group_db, attr, value)
            changed = True

    if not changed:
        raise HTTPException(status_code=304, detail="Nothing to update")

    group_db.updated_at = datetime.now(timezone.utc)
    group_db.update_search_field()
    flag_modified(group_db, "updated_at")

    try:
        await db.commit()
    except IntegrityError as e:
        await db.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return group_db
