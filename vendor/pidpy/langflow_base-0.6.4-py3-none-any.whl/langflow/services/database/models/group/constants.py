# Default group constants
DEFAULT_GROUP_NAME = "Default"
DEFAULT_GROUP_NAME_KR = "없음"
DEFAULT_GROUP_DESCRIPTION = "Default group for organizing flows"
DEFAULT_GROUP_COLOR = "#6366f1"

# Default groups list
DEFAULT_GROUPS = [
    {
        "name": DEFAULT_GROUP_NAME,
        "namekr": DEFAULT_GROUP_NAME_KR,
        "description": DEFAULT_GROUP_DESCRIPTION,
        "color": DEFAULT_GROUP_COLOR,
        "is_active": True
    }
]
