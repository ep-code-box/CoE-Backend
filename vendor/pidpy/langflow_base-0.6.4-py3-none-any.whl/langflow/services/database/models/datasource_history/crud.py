from uuid import UUID
import json

from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.datasource_history.model import DatasourceHistory, DatasourceHistoryCreate
from langflow.services.database.models.datasource_history.constants import DatasourceHistoryAction


async def get_datasource_history_by_id(db: AsyncSession, history_id: UUID) -> DatasourceHistory | None:
    if isinstance(history_id, str):
        history_id = UUID(history_id)
    stmt = select(DatasourceHistory).where(DatasourceHistory.id == history_id)
    return (await db.exec(stmt)).first()


async def create_datasource_history(session, action, user_id, datasource, old_values=None):
    # Helper function to extract status from JSON string
    def get_status_from_json(json_str):
        if not json_str:
            return None
        try:
            data = json.loads(json_str) if isinstance(json_str, str) else json_str
            return data.get("status")
        except (json.JSONDecodeError, AttributeError, TypeError):
            return None
    
    # If action is UPDATED, detect if status actually changed and use the actual status as action
    resolved_action = action
    if action == DatasourceHistoryAction.UPDATED:
        old_status = get_status_from_json(old_values)
        new_status = get_status_from_json(datasource.model_dump_json())
        
        # Map status to action
        if new_status == "APPROVED":
            resolved_action = DatasourceHistoryAction.APPROVED
        elif new_status == "REJECTED":
            resolved_action = DatasourceHistoryAction.REJECTED
        # else: keep as UPDATED
    
    if resolved_action == DatasourceHistoryAction.REVIEW_REQUESTED:
        history_data = DatasourceHistoryCreate(
            datasource_id=datasource.id,
            action=DatasourceHistoryAction.REVIEW_REQUESTED,
            description=f"Datasource '{datasource.name}' was created",
            old_values=None,
            new_values=datasource.model_dump_json(),
            create_by=user_id,
        )
    elif resolved_action == DatasourceHistoryAction.APPROVED:
        history_data = DatasourceHistoryCreate(
            datasource_id=datasource.id,
            action=DatasourceHistoryAction.APPROVED,
            description=f"Reason: {datasource.reject_approve_reason or ''}",
            old_values=old_values,
            new_values=datasource.model_dump_json(),
            create_by=user_id,
        )
    elif resolved_action == DatasourceHistoryAction.REJECTED:
        history_data = DatasourceHistoryCreate(
            datasource_id=datasource.id,
            action=DatasourceHistoryAction.REJECTED,
            description=f"Reason: {datasource.reject_approve_reason or ''}",
            old_values=old_values,
            new_values=datasource.model_dump_json(),
            create_by=user_id,
        )
    elif resolved_action == DatasourceHistoryAction.DELETED:
        history_data = DatasourceHistoryCreate(
            datasource_id=datasource.id,
            action=DatasourceHistoryAction.DELETED,
            description=f"Datasource '{datasource.name}' was deleted",
            old_values=old_values,
            new_values=datasource.model_dump_json(),
            create_by=user_id,
        )
    else:
        history_data = DatasourceHistoryCreate(
            datasource_id=datasource.id,
            action=DatasourceHistoryAction.UPDATED,
            description=f"Datasource '{datasource.name}' was updated",
            old_values=old_values,
            new_values=datasource.model_dump_json(),
            create_by=user_id,
        )

    new_history = DatasourceHistory.model_validate(history_data, from_attributes=True)
    session.add(new_history)
