class DatasourceHistoryAction:
    REVIEW_REQUESTED = "Review Requested"
    APPROVED = "Approved"
    REJECTED = "Rejected"
    UPDATED = "Updated"
    DELETED = "Deleted"
