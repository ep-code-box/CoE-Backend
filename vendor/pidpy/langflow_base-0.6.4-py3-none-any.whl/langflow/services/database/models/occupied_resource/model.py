from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from sqlmodel import Field, SQLModel

from langflow.schema.serialize import UUIDstr
from langflow.services.database.models.resource_permission.constants import ResourceTypes


class OccupiedResource(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True)
    resource_id: UUIDstr = Field(nullable=False, index=True)
    resource_type: ResourceTypes = Field(nullable=False, index=True)
    flow_id: Optional[UUIDstr] = Field(default=None, foreign_key="flow.id", nullable=True, index=True)
    component_id: Optional[str] = Field(default=None, nullable=True, index=True)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
