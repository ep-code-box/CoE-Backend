import logging
from uuid import UUID

from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.occupied_resource.model import OccupiedResource
from langflow.services.database.models.resource_permission.constants import ResourceTypes

logger = logging.getLogger(__name__)


async def add_new_occupied_resource(
    db: AsyncSession,
    resource_id: str,
    resource_type: ResourceTypes,
    flow_id: str | None,
    component_id: str | None = None,
) -> OccupiedResource:
    """Record that a flow is occupying (using) a resource.

    If a record with the same (resource_id, resource_type, flow_id, component_id) already
    exists it is returned as-is to avoid duplicates.
    """
    if isinstance(resource_id, str):
        resource_id = UUID(resource_id)
    if isinstance(flow_id, str):
        flow_id = UUID(flow_id)

    if flow_id is not None:
        # Replace any existing record for this (resource_type, flow_id, component_id) —
        # a component can only occupy one resource of a given type at a time.
        stmt = select(OccupiedResource).where(
            OccupiedResource.resource_type == resource_type,
            OccupiedResource.flow_id == flow_id,
            OccupiedResource.component_id == component_id,
        )
        existing = (await db.exec(stmt)).first()
        if existing:
            if existing.resource_id == resource_id:
                logger.debug(
                    "add_new_occupied_resource: duplicate skipped resource_id=%s resource_type=%s flow_id=%s component_id=%s",
                    resource_id, resource_type, flow_id, component_id,
                )
                return existing
            logger.debug(
                "add_new_occupied_resource: replacing old resource_id=%s with resource_id=%s resource_type=%s flow_id=%s component_id=%s",
                existing.resource_id, resource_id, resource_type, flow_id, component_id,
            )
            await db.delete(existing)
            await db.flush()

    logger.debug(
        "add_new_occupied_resource: inserting resource_id=%s resource_type=%s flow_id=%s component_id=%s",
        resource_id, resource_type, flow_id, component_id,
    )
    entry = OccupiedResource(
        resource_id=resource_id,
        resource_type=resource_type,
        flow_id=flow_id,
        component_id=component_id,
    )
    db.add(entry)
    await db.commit()
    await db.refresh(entry)
    return entry


async def remove_occupied_resource(
    db: AsyncSession,
    resource_id: str,
    resource_type: ResourceTypes,
    flow_id: str | None,
    component_id: str | None = None,
) -> bool:
    """Remove the occupied resource record for a specific (resource_id, resource_type, flow_id, component_id) tuple."""
    if isinstance(resource_id, str):
        resource_id = UUID(resource_id)
    if isinstance(flow_id, str):
        flow_id = UUID(flow_id)

    stmt = select(OccupiedResource).where(
        OccupiedResource.resource_id == resource_id,
        OccupiedResource.resource_type == resource_type,
        OccupiedResource.flow_id == flow_id,
        OccupiedResource.component_id == component_id,
    )
    existing = (await db.exec(stmt)).first()
    if existing:
        await db.delete(existing)
        await db.commit()
        return True
    return False


async def remove_all_occupied_resources_by_flow(
    db: AsyncSession,
    flow_id: str,
) -> int:
    """Remove all OccupiedResource records for a given flow_id.

    Used when a flow is deleted entirely.
    Returns the number of records deleted.
    """
    from sqlalchemy import delete as sa_delete

    if isinstance(flow_id, str):
        flow_id = UUID(flow_id)
    result = await db.execute(
        sa_delete(OccupiedResource).where(OccupiedResource.flow_id == flow_id)
    )
    await db.flush()
    deleted = result.rowcount  # type: ignore[union-attr]
    logger.debug(
        "remove_all_occupied_resources_by_flow: deleted %d records for flow_id=%s",
        deleted, flow_id,
    )
    return deleted


async def remove_stale_occupied_resources(
    db: AsyncSession,
    flow_id: str,
    active_component_ids: set[str],
) -> int:
    """Remove OccupiedResource records whose component_id is no longer present in the flow.

    Called after a flow is saved/updated to clean up resources for deleted components.
    Returns the number of records deleted.
    """
    from sqlalchemy import delete as sa_delete

    if isinstance(flow_id, str):
        flow_id = UUID(flow_id)

    # Find stale records — component_id not in the current set of node ids
    stmt = select(OccupiedResource).where(
        OccupiedResource.flow_id == flow_id,
    )
    all_records = list((await db.exec(stmt)).all())

    stale = [
        r for r in all_records
        if r.component_id is not None and r.component_id not in active_component_ids
    ]
    for r in stale:
        logger.debug(
            "remove_stale_occupied_resources: removing stale record resource_id=%s component_id=%s flow_id=%s",
            r.resource_id, r.component_id, flow_id,
        )
        await db.delete(r)

    if stale:
        await db.flush()

    logger.debug(
        "remove_stale_occupied_resources: removed %d stale records for flow_id=%s (active_components=%d)",
        len(stale), flow_id, len(active_component_ids),
    )
    return len(stale)


async def list_occupied_flows_by_resource_type_and_id(
    db: AsyncSession,
    resource_type: ResourceTypes,
    resource_id: str,
) -> list[OccupiedResource]:
    """Return all OccupiedResource records for the given resource type and ID."""
    if isinstance(resource_id, str):
        resource_id = UUID(resource_id)
    stmt = select(OccupiedResource).where(
        OccupiedResource.resource_type == resource_type,
        OccupiedResource.resource_id == resource_id,
    )
    return list((await db.exec(stmt)).all())
 