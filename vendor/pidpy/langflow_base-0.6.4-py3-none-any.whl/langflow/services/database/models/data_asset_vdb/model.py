from uuid import uuid4
from typing import Optional, TYPE_CHECKING, Any

from langflow.services.database.models.datasource.constants import DatasourceStatus, DataAssetType
from sqlmodel import Field, SQLModel, Relationship, Column
from sqlalchemy import JSON

from langflow.schema.serialize import UUIDstr

if TYPE_CHECKING:
    from langflow.services.database.models.datasource.model import Datasource


# Connection models for different VDB types
class VDBConnectionConf(SQLModel):
    """Base class for VDB connection configurations."""
    host: str | None = Field(default=None)
    port: int | None = Field(default=None)
    database_name: str | None = Field(default=None)
    api_key: str | None = Field(default=None)
    tenant_id: str | None = Field(default=None)
    uri: str | None = Field(default=None)


class DataAssetConnectionVdb(VDBConnectionConf, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    cached_metadata: Optional[dict[str, Any]] = Field(default=None, sa_column=Column(JSON, nullable=True))
    
    # Relationship to Data Source
    data_source_id: UUIDstr = Field(foreign_key="datasource.id", nullable=False, unique=True)
    data_source: Optional["Datasource"] = Relationship(back_populates="vdb_config")


class DataAssetCreate(SQLModel):
    name: str = Field()
    description: Optional[str] = None
    datasource_type: DataAssetType = Field()
    cached_metadata: Optional[dict[str, Any]] = None


class DataAssetConnectionVdbCreate(DataAssetCreate, VDBConnectionConf):
    # VDB connection fields
    pass


class DataAssetConnectionVdbRead(SQLModel):
    id: UUIDstr = Field()
    host: Optional[str] = None
    port: Optional[int] = None
    uri: Optional[str] = None
    database_name: Optional[str] = None
    api_key: Optional[str] = None
    tenant_id: Optional[str] = None
    cached_metadata: Optional[dict[str, Any]] = None
    data_source_id: UUIDstr = Field()


class DataAssetConnectionVdbUpdate(VDBConnectionConf):
    cached_metadata: Optional[dict[str, Any]] | None = None
