from uuid import UUID
from typing import Optional
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.data_asset_vdb.model import (
    DataAssetConnectionVdb,
    DataAssetConnectionVdbUpdate,
)


async def get_data_asset_config_vdb_by_id(session: AsyncSession, data_asset_id: UUID=None, config_id: UUID=None) -> Optional[DataAssetConnectionVdb]:
    """Get a VDB configuration by data asset ID or config ID."""
    query = select(DataAssetConnectionVdb)
    
    if config_id:
        query = query.where(DataAssetConnectionVdb.id == config_id)
    elif data_asset_id:
        query = query.where(DataAssetConnectionVdb.data_source_id == data_asset_id)
    else:
        return None
    
    result = await session.exec(query)
    return result.first()


async def get_vdb_config_by_data_asset_id(session: AsyncSession, datasource_id: UUID) -> Optional[DataAssetConnectionVdb]:
    """Get a VDB configuration by datasource ID."""
    query = select(DataAssetConnectionVdb).where(DataAssetConnectionVdb.data_source_id == datasource_id)
    result = await session.exec(query)
    return result.first()


async def update_data_asset_vdb(
    vdb_config: DataAssetConnectionVdb,
    vdb_update: DataAssetConnectionVdbUpdate,
    session: AsyncSession,
) -> DataAssetConnectionVdb:
    """Update a VDB configuration."""
    vdb_data = vdb_update.model_dump(exclude_unset=True)
    vdb_config.sqlmodel_update(vdb_data)
    
    session.add(vdb_config)
    await session.commit()
    await session.refresh(vdb_config)
    
    return vdb_config


async def delete_data_asset_vdb(vdb_config: DataAssetConnectionVdb, session: AsyncSession) -> None:
    """Delete a VDB configuration."""
    await session.delete(vdb_config)
    await session.commit()
