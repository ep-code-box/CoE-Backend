from typing import TYPE_CHECKING
from uuid import UUID

from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.mcp_template.models import (
    MCPServerTemplate,
    MCPServerTemplateCreate,
    MCPServerTemplateRead,
    MCPServerTemplateListRead,
)

if TYPE_CHECKING:
    from sqlmodel.sql.expression import SelectOfScalar


async def get_all_mcp_server_templates(
    session: AsyncSession,
) -> list[MCPServerTemplateListRead]:
    """Get all MCP server templates.
    
    Args:
        session: Database session
        
    Returns:
        List of all MCPServerTemplateListRead objects
    """
    query: SelectOfScalar = select(MCPServerTemplate).order_by(MCPServerTemplate.name.asc())
    templates = (await session.exec(query)).all()
    
    return [MCPServerTemplateListRead.model_validate(template, from_attributes=True) for template in templates]


async def get_mcp_server_template_by_id(
    session: AsyncSession, template_id: UUID
) -> MCPServerTemplate | None:
    """Get an MCP server template by ID.
    
    Args:
        session: Database session
        template_id: ID of the template
        
    Returns:
        MCP server template or None if not found
    """
    query: SelectOfScalar = select(MCPServerTemplate).where(
        MCPServerTemplate.id == template_id
    )
    return (await session.exec(query)).first()


async def create_mcp_server_template(
    session: AsyncSession, template_create: MCPServerTemplateCreate
) -> MCPServerTemplateRead:
    """Create a new MCP server template.
    
    Args:
        session: Database session
        template_create: MCP server template creation data
        
    Returns:
        Created MCP server template as MCPServerTemplateRead
    """
    template = MCPServerTemplate(**template_create.model_dump())
    
    session.add(template)
    await session.commit()
    await session.refresh(template)
    
    return MCPServerTemplateRead.model_validate(template, from_attributes=True)


async def upsert_mcp_server_template(
    session: AsyncSession, template_create: MCPServerTemplateCreate
) -> MCPServerTemplateRead:
    """Create or update an MCP server template by name.
    
    Args:
        session: Database session
        template_create: MCP server template creation data
        
    Returns:
        Created or updated MCP server template as MCPServerTemplateRead
    """
    # Check if template exists by name
    query: SelectOfScalar = select(MCPServerTemplate).where(
        MCPServerTemplate.name == template_create.name
    )
    existing_template = (await session.exec(query)).first()
    
    if existing_template:
        # Update existing template
        for field, value in template_create.model_dump(exclude_unset=True).items():
            setattr(existing_template, field, value)
        session.add(existing_template)
        await session.commit()
        await session.refresh(existing_template)
        return MCPServerTemplateRead.model_validate(existing_template, from_attributes=True)
    else:
        # Create new template
        return await create_mcp_server_template(session, template_create)
