from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import Text
from sqlmodel import JSON, Column, DateTime, Field, SQLModel, func

from langflow.services.database.models.mcp.models import MCPServerTypeEnum


class MCPServerTemplateBase(SQLModel):
    name: str = Field(description="Name of the MCP server template", sa_column=Column(Text, unique=True))
    description: str | None = Field(default=None, description="Description of the MCP server template", sa_column=Column(Text, nullable=True))
    version: str | None = Field(default=None, description="Version of the template", sa_column=Column(Text, nullable=True))
    provider: str | None = Field(default=None, description="Provider of the template", sa_column=Column(Text, nullable=True))
    type: MCPServerTypeEnum = Field(description="Type of the MCP server")
    config: dict | None = Field(default=None, sa_column=Column(JSON), description="Configuration template for the MCP server")
    more_info: dict | None = Field(default=None, sa_column=Column(JSON), description="Additional information about the MCP server template")


class MCPServerTemplate(MCPServerTemplateBase, table=True):  # type: ignore[call-arg]
    __tablename__ = "mcp_server_template"

    id: UUID | None = Field(default_factory=uuid4, primary_key=True, unique=True)
    created_at: datetime | None = Field(
        default=None,
        sa_column=Column(DateTime(timezone=True), server_default=func.now(), nullable=False),
        description="Creation time of the template",
    )
    updated_at: datetime | None = Field(
        default=None,
        sa_column=Column(DateTime(timezone=True), onupdate=func.now(), nullable=True),
        description="Last update time of the template",
    )


class MCPServerTemplateCreate(SQLModel):
    name: str = Field(description="Name of the MCP server template")
    description: str | None = Field(default=None, description="Description of the MCP server template")
    version: str | None = Field(default=None, description="Version of the template")
    provider: str | None = Field(default=None, description="Provider of the template")
    type: MCPServerTypeEnum = Field(description="Type of the MCP server")
    config: dict | None = Field(default=None, description="Configuration template for the MCP server")
    more_info: dict | None = Field(default=None, description="Additional information about the MCP server template")


class MCPServerTemplateRead(MCPServerTemplateBase):
    """MCP Server Template model for read endpoints."""

    id: UUID
    created_at: datetime
    updated_at: datetime | None = None

class MCPServerTemplateListRead(SQLModel):
    """MCP Server Template List model for read endpoints."""
    id: UUID
    created_at: datetime
    updated_at: datetime | None = None
    name: str
    description: str | None
    version: str | None
    provider: str | None
    type: MCPServerTypeEnum
    config: dict | None

    
