from uuid import UUID

from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from langflow.services.database.models.agent_flow_history.model import AgentFlowHistory, AgentFlowHistoryCreate
from langflow.services.database.models.agent_flow_history.constants import AgentFlowHistoryAction


async def get_exported_flow_history_by_id(db: AsyncSession, agent_flow_history_id: UUID) -> AgentFlowHistory | None:
    if isinstance(agent_flow_history_id, str):
        agent_flow_history_id = UUID(agent_flow_history_id)
    stmt = select(AgentFlowHistory).where(AgentFlowHistory.id == agent_flow_history_id)
    return (await db.exec(stmt)).first()


async def create_exported_flow_history(session, action, user_id, agent_flow, old_values=None):
    if action == AgentFlowHistoryAction.REVIEW_REQUESTED:
        # Create history record for the new agent flow
        history_data = AgentFlowHistoryCreate(
            agent_flow_id=agent_flow.id,
            action=AgentFlowHistoryAction.REVIEW_REQUESTED,
            description=f"Agent Flow '{agent_flow.name}' was created",
            old_values=None,
            new_values=agent_flow.model_dump_json(),
            create_by=user_id
        )
    elif action == AgentFlowHistoryAction.REJECTED:
        history_data = AgentFlowHistoryCreate(
            agent_flow_id=agent_flow.id,
            action=AgentFlowHistoryAction.REJECTED,
            description=f"Reason: {agent_flow.reject_approve_reason}",
            old_values=old_values,
            new_values=agent_flow.model_dump_json(),
            create_by=user_id
        )
    elif action == AgentFlowHistoryAction.APPROVED:
        history_data = AgentFlowHistoryCreate(
            agent_flow_id=agent_flow.id,
            action=AgentFlowHistoryAction.APPROVED,
            description=f"Reason: {agent_flow.reject_approve_reason}",
            old_values=old_values,
            new_values=agent_flow.model_dump_json(),
            create_by=user_id
        )
    elif action == AgentFlowHistoryAction.DELETED:
        history_data = AgentFlowHistoryCreate(
            agent_flow_id=agent_flow.id,
            action=AgentFlowHistoryAction.DELETED,
            description=f"Agent Flow '{agent_flow.name}' was deleted",
            old_values=old_values,
            new_values=agent_flow.model_dump_json(),
            create_by=user_id
        )
    else:
        history_data = AgentFlowHistoryCreate(
            agent_flow_id=agent_flow.id,
            action=AgentFlowHistoryAction.UPDATED,
            description=f"Agent Flow '{agent_flow.name}' was updated",
            old_values=old_values,
            new_values=agent_flow.model_dump_json(),
            create_by=user_id
        )
        
    new_history = AgentFlowHistory.model_validate(history_data, from_attributes=True)
    session.add(new_history)
