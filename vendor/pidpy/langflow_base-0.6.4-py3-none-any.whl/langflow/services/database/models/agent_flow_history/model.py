from datetime import datetime, timezone
from uuid import uuid4
from typing import Optional

from sqlmodel import Field, SQLModel

from langflow.schema.serialize import UUIDstr


class AgentFlowHistory(SQLModel, table=True):  # type: ignore[call-arg]
    id: UUIDstr = Field(default_factory=uuid4, primary_key=True, unique=True)
    agent_flow_id: UUIDstr = Field(nullable=False)
    action: str = Field(nullable=False)
    description: str = Field(nullable=False)
    old_values: Optional[str] = Field(default=None, nullable=True)  # JSON string of previous values
    new_values: Optional[str] = Field(default=None, nullable=True)  # JSON string of new values
    create_by: UUIDstr = Field(nullable=False)
    create_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class AgentFlowHistoryCreate(SQLModel):
    agent_flow_id: UUIDstr = Field()
    action: str = Field()
    description: str = Field()
    old_values: Optional[str] = None
    new_values: Optional[str] = None
    create_by: Optional[UUIDstr] = Field(default=None)


class AgentFlowHistoryRead(SQLModel):
    id: UUIDstr = Field()
    agent_flow_id: UUIDstr = Field()
    action: str = Field()
    description: str = Field()
    old_values: Optional[dict] = Field()
    new_values: Optional[dict] = Field()
    create_by: UUIDstr = Field()
    create_at: datetime = Field()
    created_by_username: Optional[str] = Field(default=None)
