"""
Define enums for RAG upload service, such as supported file types and processing status.
"""

class BasicMetadtaColumns:
    """Enum for basic metadata columns that can be extracted from files."""
    NAME = "name"
    TYPE = "type"
    UPLOAD_DATE = "upload_date"
    UPLOAD_USER = "upload_user"
    DESCRIPTION = "description"
    SIZE = "size"
    UPLOAD_HISTORY_ID = "upload_history_id"
    ORIGINAL_STORAGE_URL = "original_url"
    PREVIEW_STORAGE_URL = "preview_url"


class ModelEmbeddingMetadata:
    """Enum for model embedding columns that can be used for vectorization."""
    MODEL_NAME = "model_name"
    CHUNK_SIZE = "chunk_size"
    CHUNK_OVERLAP = "chunk_overlap"

class VdbUploadStatusFields:
    """Enum for fields in VDB upload status."""
    STATUS = "status"
    MESSAGE = "message"


class FileMetadataFields:
    """Enum for fields in file metadata."""
    FILES = "files"
    TOTAL_COUNT = "total_count"
