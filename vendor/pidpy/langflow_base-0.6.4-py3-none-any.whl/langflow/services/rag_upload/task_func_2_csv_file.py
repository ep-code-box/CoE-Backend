import io
import os
import time
import sys
import csv
import json
import threading

import logging
from sqlalchemy import create_engine

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Avoid adding duplicate handlers if module is reloaded
if not logger.handlers:
    _handler = logging.StreamHandler(sys.stdout)  # Force output to stdout
    _handler.setLevel(logging.INFO)
    _formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - [%(threadName)s] - %(message)s'
    )
    _handler.setFormatter(_formatter)
    logger.addHandler(_handler)

# Ensure propagation is enabled (so root logger also sees it if configured)
logger.propagate = True


from langflow.api.utils import DbSession
from sqlmodel import Session
from openai import OpenAI


from langflow.services.rag_upload.task_func import (
    get_chromadb_client,
)

from langflow.services.rag_upload.utils import (
    get_indexes_from_content,
    normalize_text,
    preparing_all_metadata_based_on_content,
)

from langflow.services.rag_upload.enums import BasicMetadtaColumns

from langflow.services.database.models.vdb_upload_history import VdbUploadHistory
from langflow.services.database.models.vdb_upload_history.constants import VdbUploadType, VdbUploadStatus
from langflow.services.rag_upload.enums import VdbUploadStatusFields, FileMetadataFields

async def create_record_in_vdb_upload_history(
    db: DbSession,
    file_name: str,
    description: str,
    collection_name: str,
    embedding_model_name: str,
    task_id: str,
    user_id: str,
    group_id: str,
    size: int,
    status: VdbUploadStatus,
    task_status: dict,
    original_storage_url: str,
    preview_storage_url: str,
) -> None:
    """Create a new record in the VDB upload history table with status."""
    logger.info(f"Creating a new record in VDB upload history with status {status} ...")
    vecDB_record = VdbUploadHistory(
        name=collection_name,
        description=description,
        collection_name=collection_name,
        upload_type=VdbUploadType.CSV_FILE.value,
        created_by=user_id,
        file_metadata={
            FileMetadataFields.TOTAL_COUNT: 1,
            FileMetadataFields.FILES: [
                {
                    BasicMetadtaColumns.NAME: file_name,
                    BasicMetadtaColumns.TYPE: "csv",
                    BasicMetadtaColumns.SIZE: size,
                    BasicMetadtaColumns.ORIGINAL_STORAGE_URL: original_storage_url,
                    BasicMetadtaColumns.PREVIEW_STORAGE_URL: preview_storage_url,
                }
            ],

        },
        status=status,
        task_id=task_id,
        embedding_model_name=embedding_model_name,
        group_id=group_id,
        task_status=task_status,
    )
    try:
        logger.info("Adding new record to VDB upload history...")
        db.add(vecDB_record)
        await db.commit()
        await db.refresh(vecDB_record)
        logger.info(f"Created VDB upload history record with ID: {vecDB_record.id}")
        return vecDB_record, None
    except Exception as e:
        logger.error(f"Failed to create record in VDB upload history: {str(e)}")
        await db.rollback()
        return None, str(e)


def update_record_status_in_vdb_upload_history_sync(
    record_id: str,
    status: str,
    task_status: str
) -> tuple[bool, str | None]:
    """Synchronous version: Update the status of a record in the VDB upload history table."""
    try:
        db_url = os.getenv("LANGFLOW_DATABASE_URL")
        if not db_url:
            raise ValueError("LANGFLOW_DATABASE_URL environment variable is not set.")
        # Replace async driver with sync driver if needed
        sync_url = db_url.replace("postgresql+asyncpg://", "postgresql://").replace(
            "sqlite+aiosqlite://", "sqlite://"
        )
        sync_engine = create_engine(sync_url)
        with Session(sync_engine) as session:
            record = session.get(VdbUploadHistory, record_id)
            if record:
                record.status = status
                record.task_status = task_status
                session.add(record)
                session.commit()
                logger.info(f"Updated record {record_id} status to '{status}'.")
                return True, None
            else:
                msg = f"Record {record_id} not found."
                logger.error(msg)
                return False, msg
    except Exception as e:
        logger.error(f"Failed to update record status: {str(e)}")
        return False, str(e)


def process_batch(
    batch: list[str],
    ids: list[str],
    batch_metadata: list[dict],
    collection_name: str,
    model_name: str,
    chunk_success: dict,
    task_id: str,
    uploaded_ids: list[str],
    chunk_success_lock: threading.Lock,
    semaphore: threading.Semaphore,
    uploaded_ids_lock: threading.Lock,
    task_status_lock: threading.Lock,
    task_status: dict,
) -> None:
    """Process a batch of data: generate embeddings and upload to ChromaDB."""
    try:
        # Create per-thread OpenAI client
        logger.info(f"[Batch] Creating OpenAI client ...")
        openai_client = OpenAI(
            api_key=os.getenv("OPENAI_EMB_API_KEY"),
            base_url=os.getenv("OPENAI_EMB_URL"),
        )
        logger.info(f"[Batch] OpenAI client created.")

        # Create per-thread ChromaDB connection
        logger.info(f"[Batch] Creating ChromaDB connection ...")
        chromadb_client = get_chromadb_client()
        collection = chromadb_client.get_or_create_collection(name=collection_name)
        logger.info(f"[Batch] ChromaDB collection '{collection_name}' is ready.")

        # Generate embeddings with retry
        logger.info(f"[Batch] Generating embeddings for {len(batch)} chunks (task: {task_id}) ...")
        MAX_RETRIES = 10
        DEFAULT_SLEEP = 30
        embeddings = []

        for attempt in range(MAX_RETRIES):
            try:
                response = openai_client.embeddings.create(
                    model=model_name,
                    input=batch,
                )
                embeddings = [item.embedding for item in response.data]
                break
            except Exception as e:
                message = f"[Batch] Embedding attempt {attempt + 1}/{MAX_RETRIES} failed: {e}"
                logger.warning(message)
                if attempt == MAX_RETRIES - 1:
                    raise RuntimeError(f"Failed to generate embeddings after {MAX_RETRIES} retries: {e}")
                time.sleep(DEFAULT_SLEEP)
                if attempt == 0:
                    message = f"[Batch] {MAX_RETRIES} retries of failed, exiting embedding generation."
                    logger.info(message)
                    with task_status_lock and chunk_success_lock:
                        task_status[VdbUploadStatusFields.STATUS] = VdbUploadStatus.UPLOAD_FAILED.value
                        task_status[VdbUploadStatusFields.MESSAGE] = message
                        chunk_success[task_id] = False
                    return

        if not embeddings:
            message = f"[Batch] No embeddings generated for task ID: {task_id}."
            logger.error(message)
            with chunk_success_lock and task_status_lock:
                chunk_success[task_id] = False
                task_status[VdbUploadStatusFields.STATUS] = VdbUploadStatus.UPLOAD_FAILED.value
                task_status[VdbUploadStatusFields.MESSAGE] = message
            return

        # Upload to ChromaDB
        try:
            collection.add(
                embeddings=embeddings,
                ids=ids,
                documents=batch,
                metadatas=batch_metadata,
            )
            logger.info(f"[Batch] Uploaded {len(batch)} chunks to ChromaDB (task: {task_id}).")

            with uploaded_ids_lock:
                uploaded_ids.extend(ids)

        except Exception as e:
            message = f"[Batch] Failed to upload to ChromaDB (task: {task_id}): {e}"
            logger.error(message, exc_info=True)
            # Try to clean up partially uploaded data
            try:
                collection.delete(ids=ids)
            except Exception:
                pass
            with chunk_success_lock and task_status_lock:
                chunk_success[task_id] = False
                task_status[VdbUploadStatusFields.STATUS] = VdbUploadStatus.UPLOAD_FAILED.value
                task_status[VdbUploadStatusFields.MESSAGE] = message

    except Exception as e:
        message = f"Unexpected error in process_batch (task: {task_id}): {e}"
        logger.error(message, exc_info=True)
        with chunk_success_lock and task_status_lock:
            chunk_success[task_id] = False
            task_status[VdbUploadStatusFields.STATUS] = VdbUploadStatus.UPLOAD_FAILED.value
            task_status[VdbUploadStatusFields.MESSAGE] = message

    finally:
        semaphore.release()
        logger.info(f"[Batch] Semaphore released (task: {task_id}).")


def _dispatch_batch(
    batch: list[str],
    ids: list[str],
    batch_metadata: list[dict],
    collection_name: str,
    embedding_model_name: str,
    chunk_success: dict,
    task_id: str,
    uploaded_ids: list[str],
    chunk_success_lock: threading.Lock,
    semaphore: threading.Semaphore,
    uploaded_ids_lock: threading.Lock,
    task_status_lock: threading.Lock,
    task_status: dict,
    threads: list[threading.Thread],
) -> None:
    """Helper: copy buffers, spawn a thread for process_batch, clear buffers."""
    thread = threading.Thread(
        target=process_batch,
        kwargs=dict(
            batch=batch.copy(),
            ids=ids.copy(),
            batch_metadata=batch_metadata.copy(),
            collection_name=collection_name,
            model_name=embedding_model_name,
            chunk_success=chunk_success,
            task_id=task_id,
            uploaded_ids=uploaded_ids,
            chunk_success_lock=chunk_success_lock,
            semaphore=semaphore,
            uploaded_ids_lock=uploaded_ids_lock,
            task_status_lock=task_status_lock,
            task_status=task_status,
        ),
    )
    thread.start()
    threads.append(thread)

    batch.clear()
    batch_metadata.clear()
    ids.clear()


def process_and_upload_csv_file(
    file_content: bytes,
    content_column: str,
    overlap: int,
    chunk_size: int,
    embedding_model_name: str,
    collection_name: str,
    metadata_columns: list[str],
    task_id: str,
    record_id: str,
    custom_metadata: dict = None,
) -> dict:
    """Process and upload CSV files to ChromaDB with OpenAI embeddings.

    Steps:
        1. Parse CSV rows → build batch (content), metadata, and ids.
        2. When batch reaches BATCH_SIZE, dispatch a thread (max MAX_THREADS concurrent).
        3. After all rows, dispatch remaining batch.
        4. Wait for all threads, determine final status, rollback on failure.
        5. Update record status in PostgresDB.

    Returns:
        dict: Processing results with status and metadata.
    """
    logger.info(f"=== process_and_upload_csv_file START (task: {task_id}, record: {record_id}) ===")

    # ── Constants ────────────────────────────────────────────────────────
    MAX_THREADS = 3
    BATCH_SIZE = 100

    # ── Shared state ─────────────────────────────────────────────────────
    batch: list[str] = []
    batch_metadata: list[dict] = []
    ids: list[str] = []
    row_numbers = 0
    stop_processing = False

    chunk_success = {task_id: True}
    chunk_success_lock = threading.Lock()
    uploaded_ids: list[str] = []
    uploaded_ids_lock = threading.Lock()
    task_status_lock = threading.Lock()
    task_status = {
        VdbUploadStatusFields.STATUS: VdbUploadStatus.UPLOADING.value,
        VdbUploadStatusFields.MESSAGE: None,
    }
    
    semaphore = threading.Semaphore(MAX_THREADS)
    threads: list[threading.Thread] = []

    try:
        # ── Resolve column indexes ───────────────────────────────────────
        column_indexes = get_indexes_from_content(file_content)
        logger.info(f"Column indexes extracted from CSV: {column_indexes}")

        content_index = column_indexes.get(content_column)
        if content_index is None:
            raise ValueError(f"Content column '{content_column}' not found in CSV header. Available: {list(column_indexes.keys())}")

        # ── 1. Parse CSV and build batches ───────────────────────────────
        logger.info("Start processing CSV content ...")
        text_content = file_content.decode("utf-8")
        csv_reader = csv.reader(io.StringIO(text_content))

        header = next(csv_reader, None)
        if header is None:
            raise ValueError("CSV file is empty — no header row found.")

        for parts in csv_reader:
            if stop_processing:
                logger.warning("Stop flag detected — aborting CSV processing loop.")
                break

            if not parts or all(p.strip() == "" for p in parts):
                continue

            # logger.info(f"Processing row {row_numbers}: {[p[:50] for p in parts[:3]]} ...")

            # -- metadata --
            sub_metadata = preparing_all_metadata_based_on_content(
                data=parts,
                metadata_columns=metadata_columns,
                custom_metadata=custom_metadata,
                column_indexes=column_indexes,
            )

            # -- content chunks --
            if content_index >= len(parts):
                logger.warning(f"Row {row_numbers}: content_index {content_index} out of range (row has {len(parts)} fields) — skipping.")
                row_numbers += 1
                continue

            content = normalize_text(parts[content_index])
            if not content:
                logger.warning(f"Row {row_numbers}: empty content after normalization — skipping.")
                row_numbers += 1
                continue

            step = max(chunk_size - overlap, 1)
            chunks = [content[i:i + chunk_size] for i in range(0, len(content), step)]

            for chunk_index, chunk in enumerate(chunks):
                batch.append(chunk)
                batch_metadata.append({**sub_metadata, "chunk_index": chunk_index})
                ids.append("{}_{}_{}_{}".format(
                    record_id,
                    custom_metadata.get(BasicMetadtaColumns.NAME, "unknown") if custom_metadata else "unknown",
                    row_numbers,
                    chunk_index,
                ))

            # logger.info(f"Row {row_numbers}: added {len(chunks)} chunk(s). Batch size now: {len(batch)}")
            row_numbers += 1

            # ── 2. Dispatch thread when batch is full ────────────────────
            if len(batch) >= BATCH_SIZE:
                # Check failure flag before acquiring semaphore
                with chunk_success_lock:
                    if not chunk_success.get(task_id, True):
                        logger.error("A previous batch failed — stopping processing.")
                        stop_processing = True
                        break

                logger.info(f"Batch reached {BATCH_SIZE}. Acquiring semaphore (max {MAX_THREADS} threads) ...")
                semaphore.acquire()

                # Re-check after potentially blocking on semaphore
                with chunk_success_lock:
                    if not chunk_success.get(task_id, True):
                        semaphore.release()
                        stop_processing = True
                        break

                logger.info(f"Dispatching thread for batch of {len(batch)} chunks ...")
                _dispatch_batch(
                    batch=batch,
                    ids=ids,
                    batch_metadata=batch_metadata,
                    collection_name=collection_name,
                    embedding_model_name=embedding_model_name,
                    chunk_success=chunk_success,
                    task_id=task_id,
                    uploaded_ids=uploaded_ids,
                    chunk_success_lock=chunk_success_lock,
                    semaphore=semaphore,
                    uploaded_ids_lock=uploaded_ids_lock,
                    threads=threads,
                    task_status_lock=task_status_lock,
                    task_status=task_status,
                )

        # ── 3. Dispatch remaining batch ──────────────────────────────────
        if batch and not stop_processing:
            with chunk_success_lock:
                should_continue = chunk_success.get(task_id, True)

            if should_continue:
                logger.info(f"Dispatching final batch of {len(batch)} chunks ...")
                semaphore.acquire()

                _dispatch_batch(
                    batch=batch,
                    ids=ids,
                    batch_metadata=batch_metadata,
                    collection_name=collection_name,
                    embedding_model_name=embedding_model_name,
                    chunk_success=chunk_success,
                    task_id=task_id,
                    uploaded_ids=uploaded_ids,
                    chunk_success_lock=chunk_success_lock,
                    semaphore=semaphore,
                    uploaded_ids_lock=uploaded_ids_lock,
                    threads=threads,
                    task_status_lock=task_status_lock,
                    task_status=task_status,
                )

        # ── 4. Wait for all threads ──────────────────────────────────────
        logger.info(f"Waiting for {len(threads)} thread(s) to finish ...")
        for thread in threads:
            thread.join()
        logger.info("All threads finished.")

        # ── 5. Determine final status ────────────────────────────────────
        with chunk_success_lock:
            all_success = chunk_success.get(task_id, True)

        final_status = VdbUploadStatus.PENDING.value if all_success else VdbUploadStatus.UPLOAD_FAILED.value

        # ── 6. Rollback on failure ───────────────────────────────────────
        if final_status == VdbUploadStatus.UPLOAD_FAILED.value:
            logger.info("Rolling back inserted vectors in ChromaDB due to failure...")
            try:
                with uploaded_ids_lock:
                    ids_to_rollback = uploaded_ids.copy()
                if ids_to_rollback:
                    client = get_chromadb_client()
                    collection = client.get_or_create_collection(name=collection_name)
                    collection.delete(ids=ids_to_rollback)
                    logger.info(f"Rollback completed. Removed {len(ids_to_rollback)} vectors.")
                else:
                    logger.info("No vectors to rollback.")
            except Exception as rollback_error:
                logger.error(f"Failed to rollback vectors: {rollback_error}")

        # ── 7. Update record status in PostgresDB ────────────────────────
        logger.info(f"Updating record status to '{final_status}' ...")
        result, msg = update_record_status_in_vdb_upload_history_sync(
            record_id=record_id,
            status=final_status,
            task_status=task_status,
        )
        if not result:
            logger.error(f"Failed to update record status for record ID {record_id}: {msg}")

        logger.info(f"=== process_and_upload_csv_file DONE (task: {task_id}, rows: {row_numbers}, status: {final_status}) ===")

    except Exception as e:
        logger.error(f"FATAL error in process_and_upload_csv_file: {e}", exc_info=True)
        # Wait for any already-dispatched threads
        for thread in threads:
            thread.join()
        # Try to update record as failed
        try:
            update_record_status_in_vdb_upload_history_sync(
                record_id, VdbUploadStatus.UPLOAD_FAILED.value
            )
        except Exception:
            logger.error("Also failed to update record status after fatal error.")
