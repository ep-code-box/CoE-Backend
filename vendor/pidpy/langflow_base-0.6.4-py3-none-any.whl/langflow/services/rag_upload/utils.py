"""
Define all helper functions for rag upload.
"""

import re
import json
import io
import csv
import os
import shutil
import tempfile
import subprocess
from datetime import datetime

from fpdf import FPDF
from langflow.services.rag_upload.enums import BasicMetadtaColumns

def space_normailization(text: str) -> str:
    """Normalize and return cleaned text."""
    return re.sub(r"\s+", " ", text).strip()


def remove_html_tags(text: str) -> str:
    """Remove HTML tags from text."""
    return re.sub(r"<.*?>", "", text)


def remove_special_characters(text: str) -> str:
    """Remove special characters from text, keeping English and Korean characters."""
    return re.sub(r"[^a-zA-Z0-9\s\uac00-\ud7af]", "", text)

def normalize_text(text: str) -> str:
    """Normalize text by applying all cleaning functions."""
    funcs = [
        space_normailization,
        remove_html_tags, 
        remove_special_characters,
    ]
    for func in funcs:
        text = func(text)
    return text

def convert_string_to_dict(string: str) -> dict:
    """Convert a string representation of a dictionary to an actual dictionary."""
    if not string:
        return {}, None
    try:
        return json.loads(string), None
    except json.JSONDecodeError:
        return False, "Invalid string format. Expected a JSON string representing a dictionary."


def get_indexes_from_content(content: bytes) -> list:
    """Get indexes from content based on provided indexes."""
    csv_reader = csv.reader(io.StringIO(content.decode("utf-8-sig")))
    names = next(csv_reader) 
    return {name: idx for idx, name in enumerate(names)}
    

def preparing_all_metadata_based_on_content(
    data: list[str], 
    metadata_columns: list,
    custom_metadata: dict,
    column_indexes: dict,
) -> list:
    """Prepare all metadata based on content and provided metadata columns."""
    metadata = {}
    # preparing data based on provided metadata columns
    for name in metadata_columns:
        metadata[name] = data[column_indexes.get(name)]
    
    # adding custom metadata
    metadata.update(custom_metadata)
    return metadata


def preparing_task_status(task_status: bool, message: str) -> str:
    """Prepare task status based on provided status."""
    return json.dumps({
        "status": "success" if task_status else "failure", 
        "message": message
    })


def preparing_original_path_for_pdf_file(group_id: str, file_name: str) -> str:
    """Prepare original store path for the uploaded file."""
    date_component = datetime.now().strftime("%Y/%m/%d")
    return f"original/{date_component}/{group_id}/pdf/{file_name}"


def preparing_original_path_for_csv_file(group_id: str, file_name: str) -> str:
    """Prepare original store path for the uploaded file."""
    date_component = datetime.now().strftime("%Y/%m/%d")
    return f"original/{date_component}/{group_id}/csv/{file_name}"


def preparing_original_path_for_doc_file(group_id: str, file_name: str) -> str:
    """Prepare original store path for the uploaded file."""
    date_component = datetime.now().strftime("%Y/%m/%d")
    return f"original/{date_component}/{group_id}/doc/{file_name}"


def preparing_original_path_for_text_file(group_id: str, file_name: str) -> str:
    """Prepare original store path for the uploaded file."""
    date_component = datetime.now().strftime("%Y/%m/%d")
    return f"original/{date_component}/{group_id}/text/{file_name}"


def convert_file_name_to_pdf_file_name(file_name: str) -> str:
    """Convert file name to PDF file name."""
    base_name = re.sub(r"\.[^.]+$", "", file_name)
    return f"{base_name}.pdf"


def preparing_preview_path_for_csv_file(group_id: str, file_name: str) -> str:
    """Prepare preview store path for the uploaded file."""
    date_component = datetime.now().strftime("%Y/%m/%d")
    converted_name = convert_file_name_to_pdf_file_name(file_name)
    return f"preview/{date_component}/{group_id}/{converted_name}"


def preparing_preview_path_for_doc_file(group_id: str, file_name: str) -> str:
    """Prepare preview store path for the uploaded file."""
    date_component = datetime.now().strftime("%Y/%m/%d")
    converted_name =convert_file_name_to_pdf_file_name(file_name)
    return f"preview/{date_component}/{group_id}/{converted_name}"


def preparing_preview_path_for_text_file(group_id: str, file_name: str) -> str:
    """Prepare preview store path for the uploaded file."""
    date_component = datetime.now().strftime("%Y/%m/%d")
    converted_name =convert_file_name_to_pdf_file_name(file_name)
    return f"preview/{date_component}/{group_id}/{converted_name}"


def convert_text_content_to_pdf_object(content: bytes) -> FPDF:
    """Convert raw PDF bytes into a parsed FPDF PDF object."""

    try:
        text_data = content.decode("utf-8")
        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        # Note: FPDF does not support reading existing PDF content, 
        # so this is just a placeholder to show where you would process the PDF.
        pdf.multi_cell(0, 10, text_data)
        pdf_bytes = pdf.output(dest="S").encode("latin1")
        return pdf_bytes
    except Exception as exc:
        raise ValueError("Invalid PDF content") from exc


def convert_doc_content_to_pdf_object(content: bytes) -> bytes:
    """Convert DOC/DOCX bytes to PDF bytes using LibreOffice headless, preserving format.
    
    Pipeline:
    1. Write input bytes to temp .docx file
    2. Convert temp .docx → temp .pdf using soffice --headless
    3. Read temp .pdf into bytes
    4. Cleanup both temp files
    5. Return PDF bytes
    """
    if not isinstance(content, (bytes, bytearray)):
        raise TypeError("content must be bytes or bytearray")
    if not content:
        raise ValueError("content is empty")

    # Resolve LibreOffice binary in a runtime-safe way.
    soffice_path = (
        os.getenv("SOFFICE_BIN")
        or shutil.which("soffice")
        or ("/usr/bin/soffice" if os.path.exists("/usr/bin/soffice") else None)
        or (
            "/usr/lib/libreoffice/program/soffice"
            if os.path.exists("/usr/lib/libreoffice/program/soffice")
            else None
        )
    )
    if not soffice_path:
        raise RuntimeError(
            "LibreOffice (soffice) is required for DOC/DOCX to PDF conversion. "
            "Install it with: sudo apt-get install libreoffice"
        )

    env = os.environ.copy()
    libreoffice_program_dir = "/usr/lib/libreoffice/program"
    if os.path.isdir(libreoffice_program_dir):
        current_ld = env.get("LD_LIBRARY_PATH", "")
        env["LD_LIBRARY_PATH"] = (
            f"{libreoffice_program_dir}:{current_ld}"
            if current_ld
            else libreoffice_program_dir
        )

    with tempfile.TemporaryDirectory() as temp_dir:
        try:
            # Step 1: Write input bytes to temp .docx file
            input_docx_path = os.path.join(temp_dir, "input.docx")
            with open(input_docx_path, "wb") as f:
                f.write(bytes(content))

            # Step 2: Convert temp .docx → temp .pdf using soffice
            output_pdf_path = os.path.join(temp_dir, "input.pdf")
            subprocess.run(
                [
                    soffice_path,
                    "--headless",
                    "--convert-to",
                    "pdf",
                    "--outdir",
                    temp_dir,
                    input_docx_path,
                ],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=120,
                env=env,
            )

            if not os.path.exists(output_pdf_path):
                raise FileNotFoundError(
                    f"LibreOffice did not create expected output PDF: {output_pdf_path}"
                )

            # Step 3: Read temp .pdf into bytes
            with open(output_pdf_path, "rb") as f:
                pdf_bytes = f.read()

            # Step 4: Cleanup - explicitly delete both temp files
            if os.path.exists(input_docx_path):
                os.remove(input_docx_path)
            if os.path.exists(output_pdf_path):
                os.remove(output_pdf_path)

            # Step 5: Return PDF bytes
            return pdf_bytes

        except FileNotFoundError as exc:
            raise RuntimeError(
                "LibreOffice (soffice) was not executable in the current runtime. "
                "Ensure 'soffice' is installed and LD_LIBRARY_PATH includes "
                "'/usr/lib/libreoffice/program'."
            ) from exc
        except subprocess.CalledProcessError as exc:
            raise ValueError(
                f"LibreOffice conversion failed: {exc.stderr.decode(errors='replace') if exc.stderr else 'unknown error'}"
            )
        except Exception as exc:
            raise ValueError(
                f"Failed to convert DOC/DOCX to PDF: {exc}"
            ) from exc


def detech_file_type(file_name: str) -> str:
    """Detect file type based on file name."""
    if file_name.lower().endswith(".pdf"):
        return "pdf"
    elif file_name.lower().endswith(".doc") or file_name.lower().endswith(".docx"):
        return "doc"
    elif file_name.lower().endswith(".txt") or file_name.lower().endswith(".md"):
        return "text"
    else:
        raise ValueError("Unsupported file type. Only PDF, DOC, DOCX, TXT, and MD are supported.")

