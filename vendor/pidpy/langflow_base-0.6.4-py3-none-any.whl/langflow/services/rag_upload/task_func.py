import os
import csv
import json
import time
from io import BytesIO, StringIO
from uuid import UUID
import logging
import sys

import chromadb
from openai import OpenAI
import pdfplumber
from docx import Document

# from chromadb_utils import OpenAIEmbeddingFunction


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Avoid adding duplicate handlers if module is reloaded
if not logger.handlers:
    _handler = logging.StreamHandler(sys.stdout)  # Force output to stdout
    _handler.setLevel(logging.INFO)
    _formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - [%(threadName)s] - %(message)s'
    )
    _handler.setFormatter(_formatter)
    logger.addHandler(_handler)

# Ensure propagation is enabled (so root logger also sees it if configured)
logger.propagate = True

def get_chromadb_client() -> chromadb.Client:
    host = os.getenv("SELFHOST_CHROMA_HOST", None)
    if host:
        client = chromadb.HttpClient(
            host=host,
            port=int(os.getenv("SELFHOST_CHROMA_PORT", "8000")),
            settings=chromadb.config.Settings(
                chroma_client_auth_provider="chromadb.auth.token_authn.TokenAuthClientProvider",
                chroma_client_auth_credentials=os.getenv("SELFHOST_CHROMA_API_KEY") or "_",
                chroma_auth_token_transport_header="Authorization",
            ),
        )
    else:
        client = chromadb.CloudClient(
            api_key=os.getenv("SELFHOST_CHROMA_API_KEY"),
            tenant=os.getenv("SELFHOST_CHROMA_TENANT_ID"),
            database=os.getenv("SELFHOST_CHROMA_DATABASE_NAME"),
        )
    return client


def delete_vectors_from_collection(collection_name: str, upload_history_id: UUID) -> dict:
    """Delete vectors from ChromaDB collection by upload_history_id.
    
    Args:
        collection_name: Name of the ChromaDB collection
        upload_history_id: ID of the upload history record
        
    Returns:
        dict: Deletion results with status
    """
    try:
        client = get_chromadb_client()
        
        # Get collection
        collection = client.get_collection(name=collection_name)
        
        # Query for all vectors with this upload_history_id
        results = collection.get(
            where={"upload_history_id": str(upload_history_id)}
        )
        
        if results and results["ids"]:
            # Delete all matching vectors
            collection.delete(ids=results["ids"])
            deleted_count = len(results["ids"])
        else:
            deleted_count = 0
        
        return {
            "status": "success",
            "upload_history_id": str(upload_history_id),
            "collection_name": collection_name,
            "deleted_count": deleted_count
        }
        
    except Exception as e:
        return {
            "status": "error",
            "upload_history_id": str(upload_history_id),
            "error": str(e)
        }


def convert_file_to_text(content_bytes: bytes, filename: str) -> str:
    """Convert PDF, DOCX, or text files to plain text.
    
    Args:
        content_bytes: File content as bytes
        filename: Original filename to determine file type
        
    Returns:
        str: Extracted text content
        
    Raises:
        Exception: If file type is unsupported or conversion fails
    """
    file_extension = os.path.splitext(filename)[1].lower()
    
    if file_extension == ".pdf":
        # Extract text from PDF
        pdf_file = BytesIO(content_bytes)
        text_parts = []
        with pdfplumber.open(pdf_file) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    text_parts.append(text)
        return "\n".join(text_parts)
        
    elif file_extension in [".docx", ".doc"]:
        # Extract text from DOCX
        docx_file = BytesIO(content_bytes)
        doc = Document(docx_file)
        text_parts = [paragraph.text for paragraph in doc.paragraphs]
        return "\n".join(text_parts)
        
    elif file_extension in [".txt", ".md", ".json", ".csv", ".log"]:
        # Handle text files
        return content_bytes.decode("utf-8")
        
    else:
        # Try to decode as UTF-8 text by default
        try:
            return content_bytes.decode("utf-8")
        except UnicodeDecodeError:
            raise ValueError(
                f"Unsupported file type: {file_extension}. Supported types: .pdf, .docx, .txt, .md, .json, .csv, .log"
            )


def iter_chunks_from_file(content_bytes: bytes, filename: str, chunk_size: int, overlap: int):
    """Generator that yields (chunk_text, start_index, end_index) in a memory-efficient streaming manner.

    For PDF files, text is extracted page-by-page and chunked on-the-fly so the
    full document text is never held in RAM all at once.  For other file types the
    full text is loaded once (they are typically much smaller).

    Args:
        content_bytes: Raw file bytes.
        filename: Original filename (used to detect file type).
        chunk_size: Maximum number of characters per chunk.
        overlap: Number of characters to overlap between consecutive chunks.

    Yields:
        tuple[str, int, int]: (chunk_text, start_index, end_index)
    """
    file_extension = os.path.splitext(filename)[1].lower()
    step = max(1, chunk_size - overlap)

    if file_extension == ".pdf":
        # Stream page-by-page; keep only a rolling buffer in memory.
        pdf_file = BytesIO(content_bytes)
        del content_bytes  # BytesIO made its own internal copy; free the original bytes now
        buffer = ""
        global_offset = 0

        with pdfplumber.open(pdf_file) as pdf:
            n_pages = len(pdf.pages)
            for i in range(n_pages):
                page = pdf.pages[i]
                page_text = page.extract_text() or ""

                # pdfplumber caches page.layout / page.objects / page.chars etc. as
                # cached_property values stored in page.__dict__.  For a 900-page PDF
                # this can accumulate hundreds of MB.  Clearing __dict__ after every
                # page drops the pdfminer LTPage tree (chars, lines, curves…) while
                # the lightweight Page wrapper in pdf.pages stays intact.
                page.__dict__.clear()
                del page

                if page_text:
                    buffer += "\n" + page_text
                del page_text  # release before next iteration

                # Emit complete chunks as soon as the buffer is large enough.
                while len(buffer) >= chunk_size:
                    chunk_text = buffer[:chunk_size]
                    if chunk_text.strip():
                        yield chunk_text, global_offset, global_offset + len(chunk_text)
                    global_offset += step
                    buffer = buffer[step:]

        # Emit the tail that didn't fill a full chunk.
        if buffer.strip():
            yield buffer, global_offset, global_offset + len(buffer)

    else:
        # Non-PDF files: load once and chunk normally.
        content = convert_file_to_text(content_bytes, filename)
        del content_bytes  # full text is now in `content`; free the raw bytes
        start = 0
        while start < len(content):
            end = start + chunk_size
            chunk_text = content[start:end]
            if chunk_text.strip():
                yield chunk_text, start, end
            start += step


def process_and_upload_documents(
    file_data: list[dict], 
    collection_name: str, 
    upload_history_id: UUID, 
    chunk_size: int, 
    overlap: int,
    model: str,
) -> dict:
    """Process and upload documents to ChromaDB with OpenAI embeddings.
    
    Args:
        file_data: List of dicts with 'filename' and 'content' keys (content is bytes)
        collection_name: Name of the ChromaDB collection
        upload_history_id: ID of the upload history record
        chunk_size: Size of text chunks
        overlap: Overlap size between chunks
        model: Name of the embedding model to use
    Returns:
        dict: Processing results with status and metadata
    """
    try:
        logger.info("Create connect to OpenAI")
        openai_client = OpenAI(
            api_key=os.getenv("OPENAI_EMB_API_KEY"),
            base_url=os.getenv("OPENAI_EMB_URL"),
        )

        logger.info("Creaet connection to chromadb")
        client = get_chromadb_client()
        
        # Get or create collection
        collection = client.get_or_create_collection(name=collection_name)
        
        
        total_chunks = 0
        processed_files = []
        
        # Process each file
        for file_info in file_data:
            content_bytes = file_info["content"]
            file_name = file_info["filename"]
            
            # Stream and process chunks from file
            MAX_TOKENS_PER_REQUEST = 290000  # Conservative limit
            CHARS_PER_TOKEN = 1  # 1 char for Korean
            MAX_CHARS_PER_BATCH = MAX_TOKENS_PER_REQUEST * CHARS_PER_TOKEN
            MAX_RETRIES, DELAY_TIME_DEFAULT = 10, 10
            UPLOAD_BATCH_SIZE = 300  # ChromaDB batch limit

            file_chunk_count = 0
            pending: list[dict] = []  # {"text", "start_index", "end_index"}
            pending_char_count = 0

            def _flush_batch(batch_chunks: list[dict], chunk_offset: int) -> int:
                if not batch_chunks:
                    return 0

                batch_texts = [c["text"] for c in batch_chunks]

                # --- Embedding with retry ---
                retry_count = 0
                logger.info("Start embedding generation ...")
                while retry_count < MAX_RETRIES:
                    try:
                        response = openai_client.embeddings.create(
                            # model="text-embedding-3-small",
                            model=model,
                            input=batch_texts
                        )
                        batch_embeddings = [item.embedding for item in response.data]
                        break
                    except Exception as e:
                        retry_count += 1
                        logger.info(
                            f"Embedding error (attempt {retry_count}/{MAX_RETRIES}): {e}"
                        )
                        if retry_count >= MAX_RETRIES:
                            raise Exception(
                                f"Failed to generate embeddings after {MAX_RETRIES} retries for file {file_name}: {e}"
                            )
                        time.sleep(DELAY_TIME_DEFAULT)
                        logger.info(f"Retrying in {DELAY_TIME_DEFAULT} seconds...")

                # Prepare ChromaDB payloads
                logger.info(f"Prepare data for ChromaDB upload for file: {file_name}")
                ids = [f"{upload_history_id}_{file_name}_{chunk_offset + i}" for i in range(len(batch_chunks))]
                documents = batch_texts
                metadatas = [
                    {
                        "upload_history_id": str(upload_history_id),
                        "file_name": file_name,
                        "chunk_index": chunk_offset + i,
                        "start_index": c["start_index"],
                        "end_index": c["end_index"],
                        "chunk_size": chunk_size,
                        "overlap": overlap,
                    }
                    for i, c in enumerate(batch_chunks)
                ]

                logger.info(f"Start uploading to ChromaDB for file: {file_name}")
                UPLOAD_BATCH_SIZE = 300
                for i in range(0, len(ids), UPLOAD_BATCH_SIZE):
                    sub_end = min(i + UPLOAD_BATCH_SIZE, len(ids))
                    collection.add(
                        ids=ids[i:sub_end],
                        embeddings=batch_embeddings[i:sub_end],
                        documents=documents[i:sub_end],
                        metadatas=metadatas[i:sub_end],
                    )

                return len(batch_chunks)

            logger.info(f"Start processing file: {file_name}")
            for chunk_text, start_idx, end_idx in iter_chunks_from_file(content_bytes, file_name, chunk_size, overlap):
                pending.append({"text": chunk_text, "start_index": start_idx, "end_index": end_idx})
                pending_char_count += len(chunk_text)

                if pending_char_count >= MAX_CHARS_PER_BATCH:
                    logger.info(f"Flushing {len(pending)} chunks (total so far: {file_chunk_count}) for {file_name}")
                    file_chunk_count += _flush_batch(pending, file_chunk_count)
                    pending = []
                    pending_char_count = 0

            # Flush the tail
            if pending:
                logger.info(f"Flushing final {len(pending)} chunks for {file_name}")
                file_chunk_count += _flush_batch(pending, file_chunk_count)

            total_chunks += file_chunk_count
            processed_files.append({
                "file_name": file_name,
                "chunks_count": file_chunk_count
            })
        
        return {
            "status": "success",
            "upload_history_id": str(upload_history_id),
            "collection_name": collection_name,
            "total_files": len(file_data),
            "total_chunks": total_chunks,
            # "processed_files": processed_files
        }
        
    except Exception as e:
        logger.info(f"Error in process_and_upload_documents: {str(e)}")

        # Step 1: Delete partial vectors already uploaded for this session
        try:
            delete_vectors_from_collection(collection_name, upload_history_id)
            logger.info(f"Rolled back partial vectors for upload_history_id={upload_history_id}")
        except Exception as cleanup_err:
            logger.info(f"Failed to rollback vectors during cleanup: {cleanup_err}")

        # Step 2: Delete ChromaDB collection if now empty
        try:
            chroma_client = get_chromadb_client()
            coll = chroma_client.get_collection(name=collection_name)
            if coll.count() == 0:
                chroma_client.delete_collection(name=collection_name)
                logger.info(f"Deleted empty collection '{collection_name}' after rollback")
        except Exception as coll_err:
            logger.info(f"Could not clean up collection '{collection_name}': {coll_err}")

        return {
            "status": "error",
            "upload_history_id": str(upload_history_id),
            "error": "An error occurred during processing and uploading documents."
        }


def process_and_upload_raw_vectors(
    file_data: list[dict],
    collection_name: str,
    upload_history_id: UUID,
) -> dict:
    """Process and upload raw vectors to ChromaDB from JSON or CSV files.
    
    Args:
        file_data: List of dicts with 'filename' and 'content' keys (content is bytes)
        collection_name: Name of the ChromaDB collection
        upload_history_id: ID of the upload history record
        
    Returns:
        dict: Processing results with status and metadata
        
    Supported formats:
        JSON: {"vectors": [{"id": "str", "document": "str", "vector": [0.0, ...], "metadata": {}}]}
        CSV: id, document, vector, metadata1, metadata2, ...
             vector column should contain space-separated floats
    """
    try:
        client = get_chromadb_client()
        
        # Get or create collection
        collection = client.get_or_create_collection(name=collection_name)
        
        total_vectors = 0
        processed_files = []
        
        # Process each file
        for file_info in file_data:
            content_bytes = file_info["content"]
            file_name = file_info["filename"]
            file_extension = os.path.splitext(file_name)[1].lower()
            
            vectors_data = []
            
            try:
                if file_extension == ".json":
                    # Parse JSON file
                    content_str = content_bytes.decode("utf-8")
                    data = json.loads(content_str)
                    
                    if "vectors" not in data or not isinstance(data["vectors"], list):
                        raise ValueError(f"Invalid JSON format in {file_name}. Expected {{'vectors': [...]}} structure")
                    
                    for idx, item in enumerate(data["vectors"]):
                        # Validate required fields
                        if "id" not in item:
                            raise ValueError(f"Missing 'id' field in vector {idx} of {file_name}")
                        if "document" not in item:
                            raise ValueError(f"Missing 'document' field in vector {idx} of {file_name}")
                        if "vector" not in item:
                            raise ValueError(f"Missing 'vector' field in vector {idx} of {file_name}")
                        
                        # Validate vector is a list of numbers
                        if not isinstance(item["vector"], list) or not all(isinstance(x, (int, float)) for x in item["vector"]):
                            raise ValueError(f"Invalid 'vector' format in vector {idx} of {file_name}. Must be a list of numbers")
                        
                        # Extract metadata (all fields except id, document, vector)
                        metadata = item.get("metadata", {})
                        if not isinstance(metadata, dict):
                            metadata = {}
                        
                        # Add upload tracking metadata
                        metadata["upload_history_id"] = str(upload_history_id)
                        metadata["file_name"] = file_name
                        
                        vectors_data.append({
                            "id": str(item["id"]),
                            "document": item["document"],
                            "embedding": item["vector"],
                            "metadata": metadata
                        })
                
                elif file_extension == ".csv":
                    # Parse CSV file
                    content_str = content_bytes.decode("utf-8")
                    csv_reader = csv.DictReader(StringIO(content_str))
                    
                    # Check required columns
                    if not csv_reader.fieldnames:
                        raise ValueError(f"CSV file {file_name} has no headers")
                    
                    required_cols = {"id", "document", "vector"}
                    missing_cols = required_cols - set(csv_reader.fieldnames)
                    if missing_cols:
                        raise ValueError(f"CSV file {file_name} missing required columns: {missing_cols}")
                    
                    for row_idx, row in enumerate(csv_reader):
                        # Parse vector from space-separated string
                        vector_str = row["vector"].strip()
                        try:
                            vector = [float(x) for x in vector_str.split()]
                        except ValueError:
                            raise ValueError(f"Invalid vector format at row {row_idx + 2} in {file_name}. Expected space-separated numbers")
                        
                        if not vector:
                            raise ValueError(f"Empty vector at row {row_idx + 2} in {file_name}")
                        
                        # Extract metadata (all columns except id, document, vector)
                        metadata = {
                            key: value
                            for key, value in row.items()
                            if key not in {"id", "document", "vector"} and value.strip()
                        }
                        
                        # Add upload tracking metadata
                        metadata["upload_history_id"] = str(upload_history_id)
                        metadata["file_name"] = file_name
                        
                        vectors_data.append({
                            "id": row["id"],
                            "document": row["document"],
                            "embedding": vector,
                            "metadata": metadata
                        })
                
                else:
                    raise ValueError(f"Unsupported file type: {file_extension}. Supported types: .json, .csv")
                
                # Upload vectors to ChromaDB
                # ChromaDB has a maximum batch size of 1000
                if vectors_data:
                    UPLOAD_BATCH_SIZE = 300
                    for i in range(0, len(vectors_data), UPLOAD_BATCH_SIZE):
                        batch_end = min(i + UPLOAD_BATCH_SIZE, len(vectors_data))
                        batch = vectors_data[i:batch_end]
                        collection.add(
                            ids=[v["id"] for v in batch],
                            embeddings=[v["embedding"] for v in batch],
                            documents=[v["document"] for v in batch],
                            metadatas=[v["metadata"] for v in batch]
                        )
                    
                    total_vectors += len(vectors_data)
                    processed_files.append({
                        "file_name": file_name,
                        "vectors_count": len(vectors_data)
                    })
            
            except Exception as e:
                # Include file-specific error in the result
                return {
                    "status": "error",
                    "upload_history_id": str(upload_history_id),
                    "error": f"Error processing {file_name}: {str(e)}"
                }
        
        return {
            "status": "success",
            "upload_history_id": str(upload_history_id),
            "collection_name": collection_name,
            "total_files": len(file_data),
            "total_vectors": total_vectors,
            # "processed_files": processed_files
        }
        
    except Exception as e:
        return {
            "status": "error",
            "upload_history_id": str(upload_history_id),
            "error": str(e)
        }


