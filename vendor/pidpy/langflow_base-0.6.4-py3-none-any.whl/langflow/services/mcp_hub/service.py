import json
import os
from typing import Any

import httpx

from langflow.services.database.models.mcp.models import MCPServerCreate
from langflow.services.database.models.mcp_tools.models import MCPToolCreate


class MCPHubService:
    """Service for interacting with the MCP Hub."""

    def __init__(self):
        self.mcp_hub_url = os.getenv("MCP_HUB_URL", "http://localhost:8000")
        self.client = httpx.AsyncClient(timeout=30.0)

    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()

    def verify_mcp_server_config(self, server_type: str, config: dict | None) -> None:
        """Verify that the MCP server config follows the expected structure.
        
        Args:
            server_type: The type of the MCP server
            config: The configuration dictionary to verify
            
        Raises:
            ValueError: If the config doesn't follow the expected structure
        """
        if server_type == "SELF_HOSTED":
            if not config:
                msg = "Config is required for SELF_HOSTED server type"
                raise ValueError(msg)
            
            required_fields = ["baseUrl"]
            optional_fields = ["authType", "authKey", "authValue", "defaultHeaders"]
            
            # Check required fields
            for field in required_fields:
                if field not in config:
                    msg = (
                        f"Missing required field '{field}' in config. "
                        f"Config must follow this structure:\n"
                        f"{{\n"
                        f'  "baseUrl": "string",\n'
                        f'  "authType": "string or None",\n'
                        f'  "authKey": "string or None",\n'
                        f'  "authValue": "string or None",\n'
                        f'  "defaultHeaders": {{\n'
                        f'    "key": "string"\n'
                        f"  }}\n"
                        f"}}"
                    )
                    raise ValueError(msg)
            
            # Validate baseUrl is a string
            if not isinstance(config["baseUrl"], str):
                msg = "Field 'baseUrl' must be a string"
                raise ValueError(msg)
            
            # Validate optional fields if present
            if "authType" in config and config["authType"] is not None and not isinstance(config["authType"], str):
                msg = "Field 'authType' must be a string or None"
                raise ValueError(msg)
            
            if "authKey" in config and config["authKey"] is not None and not isinstance(config["authKey"], str):
                msg = "Field 'authKey' must be a string or None"
                raise ValueError(msg)
            
            if "authValue" in config and config["authValue"] is not None and not isinstance(config["authValue"], str):
                msg = "Field 'authValue' must be a string or None"
                raise ValueError(msg)
            
            if "defaultHeaders" in config and not isinstance(config["defaultHeaders"], dict):
                msg = "Field 'defaultHeaders' must be a dictionary"
                raise ValueError(msg)
        
        elif server_type == "EXTERNAL_STDIO":
            if not config:
                msg = "Config is required for EXTERNAL_STDIO server type"
                raise ValueError(msg)
            
            required_fields = ["command"]
            optional_fields = ["args", "env"]
            
            # Check required fields
            for field in required_fields:
                if field not in config:
                    msg = (
                        f"Missing required field '{field}' in config. "
                        f"Config must follow this structure:\n"
                        f"{{\n"
                        f'  "command": "string",\n'
                        f'  "args": ["string"],\n'
                        f'  "env": {{"string": "string"}}\n'
                        f"}}"
                    )
                    raise ValueError(msg)
            
            # Validate command is a string
            if not isinstance(config["command"], str):
                msg = "Field 'command' must be a string"
                raise ValueError(msg)
            
            # Validate optional fields if present
            if "args" in config:
                if not isinstance(config["args"], list):
                    msg = "Field 'args' must be a list"
                    raise ValueError(msg)
                # Validate all items in args are strings
                if not all(isinstance(arg, str) for arg in config["args"]):
                    msg = "All items in 'args' must be strings"
                    raise ValueError(msg)
            
            if "env" in config:
                if not isinstance(config["env"], dict):
                    msg = "Field 'env' must be a dictionary"
                    raise ValueError(msg)
                # Validate all values in env are strings
                if not all(isinstance(v, str) for v in config["env"].values()):
                    msg = "All values in 'env' must be strings"
                    raise ValueError(msg)
        
        elif server_type == "EXTERNAL_SSE":
            if not config:
                msg = "Config is required for EXTERNAL_SSE server type"
                raise ValueError(msg)
            
            required_fields = ["url"]
            optional_fields = ["headers", "env"]
            
            # Check required fields
            for field in required_fields:
                if field not in config:
                    msg = (
                        f"Missing required field '{field}' in config. "
                        f"Config must follow this structure:\n"
                        f"{{\n"
                        f'  "url": "string",\n'
                        f'  "headers": {{"string": "string"}},\n'
                        f'  "env": {{"string": "string"}}\n'
                        f"}}"
                    )
                    raise ValueError(msg)
            
            # Validate url is a string
            if not isinstance(config["url"], str):
                msg = "Field 'url' must be a string"
                raise ValueError(msg)
            
            # Validate optional fields if present
            if "headers" in config:
                if not isinstance(config["headers"], dict):
                    msg = "Field 'headers' must be a dictionary"
                    raise ValueError(msg)
                # Validate all values in headers are strings
                if not all(isinstance(v, str) for v in config["headers"].values()):
                    msg = "All values in 'headers' must be strings"
                    raise ValueError(msg)
            
            if "env" in config:
                if not isinstance(config["env"], dict):
                    msg = "Field 'env' must be a dictionary"
                    raise ValueError(msg)
                # Validate all values in env are strings
                if not all(isinstance(v, str) for v in config["env"].values()):
                    msg = "All values in 'env' must be strings"
                    raise ValueError(msg)
        else:
            raise ValueError(f"Server type must be one of SELF_HOSTED, EXTERNAL_SSE, EXTERNAL_STDIO")

    async def create_or_update_mcp_server(self, body: MCPServerCreate, config: dict) -> dict[str, Any]:
        """Create or update an MCP server in the MCP Hub.
        
        Args:
            body: The MCP server creation request
            config: The configuration dictionary
            
        Returns:
            The response from the MCP Hub API
        """
        name = body.name.replace(" ", "_").lower()
        
        # Build the request body
        request_body = {
            "name": name,
            "baseUrl": config["baseUrl"],
            "auth": {
                "type": config.get("authType"),
                "key": config.get("authKey"),
                "value": config.get("authValue"),
            },
            "defaultHeaders": config.get("defaultHeaders", {}),
            "active": True,
        }
        
        url = f"{self.mcp_hub_url}/api/servers/{name}"
        response = await self.client.post(url, json=request_body)
        response.raise_for_status()
        return response.json()

    async def create_or_update_mcp_tool(self, body: MCPToolCreate, mcp_server_name: str) -> dict[str, Any]:
        """Create or update an MCP tool in the MCP Hub.
        
        Args:
            body: The MCP tool creation request
            mcp_server_name: The name of the MCP server this tool belongs to
            
        Returns:
            The response from the MCP Hub API
        """
        name = body.name.replace(" ", "_").lower()
        
        # Build the request body
        request_body = {
            "name": name,
            "description": body.description or "",
            "method": body.http_method.value,
            "pathTemplate": body.path_template,
            "paramMapping": {
                "path": body.path_mapping,
                "query": body.query_mapping,
                "headers": body.headers_mapping,
                "body": body.body_mapping,
                "rawBody": body.raw_body_key,
            },
            "inputSchema": body.input_schema,
            "active": True,
            "responseMapping": {
                "pick": body.response_mapping,
            },
        }
        
        url = f"{self.mcp_hub_url}/api/tools/{mcp_server_name}/{name}"
        response = await self.client.post(url, json=request_body)
        response.raise_for_status()
        return response.json()

    async def delete_mcp_server(self, server_name: str) -> None:
        """Delete an MCP server from the MCP Hub.
        
        Args:
            server_name: The name of the MCP server to delete
            
        Raises:
            httpx.HTTPError: If the deletion fails
        """
        name = server_name.replace(" ", "_").lower()
        url = f"{self.mcp_hub_url}/api/servers/{name}"
        response = await self.client.delete(url)
        response.raise_for_status()

    async def delete_mcp_tool(self, server_name: str, tool_name: str) -> None:
        """Delete an MCP tool from the MCP Hub.
        
        Args:
            server_name: The name of the MCP server this tool belongs to
            tool_name: The name of the tool to delete
            
        Raises:
            httpx.HTTPError: If the deletion fails
        """
        server_name_normalized = server_name.replace(" ", "_").lower()
        tool_name_normalized = tool_name.replace(" ", "_").lower()
        url = f"{self.mcp_hub_url}/api/tools/{server_name_normalized}/{tool_name_normalized}"
        response = await self.client.delete(url)
        response.raise_for_status()

    async def test_mcp_tool(self, server_name: str, tool_name: str, args: dict) -> dict[str, Any]:
        """Test an MCP tool by calling it through the MCP Hub.
        
        Args:
            server_name: The name of the MCP server this tool belongs to
            tool_name: The name of the tool to test
            args: The arguments to pass to the tool
            
        Returns:
            The response from the MCP Hub API containing the tool execution result
            
        Raises:
            httpx.HTTPError: If the test call fails
        """
        server_name_normalized = server_name.replace(" ", "_").lower()
        tool_name_normalized = tool_name.replace(" ", "_").lower()
        url = f"{self.mcp_hub_url}/mcp/{server_name_normalized}/{tool_name_normalized}"
        
        # Build the request body
        request_body = {"args": args}
        
        # Call the tool endpoint and collect SSE stream
        response = await self.client.post(url, json=request_body)
        response.raise_for_status()
        
        # Parse the SSE response
        result = {
            "success": False,
            "data": None,
            "error": None,
            "status_code": response.status_code
        }
        
        # Process the SSE stream
        lines = response.text.split("\n")
        for line in lines:
            if line.startswith("event: "):
                event_type = line.replace("event: ", "").strip()
            elif line.startswith("data: "):
                try:
                    data_str = line.replace("data: ", "").strip()
                    data = json.loads(data_str) if data_str else {}
                    
                    if event_type == "output.delta":
                        result["data"] = data
                        result["success"] = True
                    elif event_type == "tool_call.completed":
                        result["status_code"] = data.get("status", 200)
                    elif event_type == "tool_call.error":
                        result["error"] = data.get("error")
                        result["success"] = False
                except Exception:
                    pass
        
        return result

