from __future__ import annotations

import asyncio
from uuid import UUID
from typing import TYPE_CHECKING

from lfx.log.logger import logger
from lfx.services.settings.constants import DEFAULT_SUPERUSER, DEFAULT_SUPERUSER_PASSWORD
from sqlalchemy import delete
from sqlalchemy import exc as sqlalchemy_exc
from sqlmodel import col, select

from langflow.services.auth.utils import create_super_user, verify_password
from langflow.services.cache.base import ExternalAsyncBaseCacheService
from langflow.services.cache.factory import CacheServiceFactory
from langflow.services.database.models.user.model import User
from langflow.services.database.models.transactions.model import TransactionTable
from langflow.services.database.models.vertex_builds.model import VertexBuildTable
from langflow.services.database.models.group.utils import create_default_groups, get_group_by_name
from langflow.services.database.models.group.constants import DEFAULT_GROUP_NAME
from langflow.services.database.models.user_role.crud import create_default_roles, get_user_role_by_name
from langflow.services.database.models.user_role.constants import DEFAULT_ADMIN_ROLE_NAME
from langflow.services.database.models.masterdata.crud import create_default_masterdatas, get_first_three_homepage_config
from langflow.services.database.utils import initialize_database
from langflow.services.schema import ServiceType

from .deps import get_db_service, get_service, get_settings_service, session_scope

if TYPE_CHECKING:
    from lfx.services.settings.manager import SettingsService
    from sqlmodel.ext.asyncio.session import AsyncSession


async def get_or_create_super_user(session: AsyncSession, username, password, is_default):
    stmt = select(User).where(User.username == username)
    result = await session.exec(stmt)
    user = result.first()

    if user and user.is_superuser:
        return None  # Superuser already exists

    if user and is_default:
        if user.is_superuser:
            if verify_password(password, user.password):
                return None
            # Superuser exists but password is incorrect
            # which means that the user has changed the
            # base superuser credentials.
            # This means that the user has already created
            # a superuser and changed the password in the UI
            # so we don't need to do anything.
            await logger.adebug(
                "Superuser exists but password is incorrect. "
                "This means that the user has changed the "
                "base superuser credentials."
            )
            return None
        logger.debug("User with superuser credentials exists but is not a superuser.")
        return None

    if user:
        if verify_password(password, user.password):
            msg = "User with superuser credentials exists but is not a superuser."
            raise ValueError(msg)
        msg = "Incorrect superuser credentials"
        raise ValueError(msg)

    if is_default:
        logger.debug("Creating default superuser.")
    else:
        logger.debug("Creating superuser.")
    return await create_super_user(username, password, db=session)


async def setup_superuser(settings_service: SettingsService, session: AsyncSession) -> None:
    if settings_service.auth_settings.AUTO_LOGIN:
        await logger.adebug("AUTO_LOGIN is set to True. Creating default superuser.")
        username = DEFAULT_SUPERUSER
        password = DEFAULT_SUPERUSER_PASSWORD.get_secret_value()
    else:
        # Remove the default superuser if it exists
        await teardown_superuser(settings_service, session)
        # If AUTO_LOGIN is disabled, attempt to use configured credentials
        # or fall back to default credentials if none are provided.
        username = settings_service.auth_settings.SUPERUSER or DEFAULT_SUPERUSER
        password = (settings_service.auth_settings.SUPERUSER_PASSWORD or DEFAULT_SUPERUSER_PASSWORD).get_secret_value()

    if not username or not password:
        msg = "Username and password must be set"
        raise ValueError(msg)

    is_default = (username == DEFAULT_SUPERUSER) and (password == DEFAULT_SUPERUSER_PASSWORD.get_secret_value())

    try:
        user = await get_or_create_super_user(
            session=session, username=username, password=password, is_default=is_default
        )
        if user is not None:
            await logger.adebug("Superuser created successfully.")
    except Exception as exc:
        logger.exception(exc)
        msg = "Could not create superuser. Please create a superuser manually."
        raise RuntimeError(msg) from exc
    finally:
        # Scrub credentials from in-memory settings after setup
        settings_service.auth_settings.reset_credentials()


async def teardown_superuser(settings_service, session: AsyncSession) -> None:
    """Teardown the superuser."""
    # If AUTO_LOGIN is True, we will remove the default superuser
    # from the database.

    if not settings_service.auth_settings.AUTO_LOGIN:
        try:
            await logger.adebug("AUTO_LOGIN is set to False. Removing default superuser if exists.")
            username = DEFAULT_SUPERUSER

            stmt = select(User).where(User.username == username)
            result = await session.exec(stmt)
            user = result.first()
            # Check if super was ever logged in, if not delete it
            # if it has logged in, it means the user is using it to login
            if user and user.is_superuser is True and not user.last_login_at:
                await session.delete(user)
                await session.commit()
                await logger.adebug("Default superuser removed successfully.")

        except Exception as exc:
            logger.exception(exc)
            await session.rollback()
            msg = "Could not remove default superuser."
            raise RuntimeError(msg) from exc


async def setup_default_roles(session: AsyncSession) -> None:
    """Setup default user roles in the database."""
    try:
        await logger.adebug("Setting up default user roles.")

        # Get the superuser to use as the creator of default roles
        stmt = select(User).where(User.is_superuser == True).limit(1)  # noqa: E712
        result = await session.exec(stmt)
        superuser = result.first()

        if superuser:
            system_user_id = superuser.id  # Keep as UUID object
        else:
            # If no superuser exists yet, use a placeholder
            # This shouldn't happen in practice since setup_superuser runs first
            await logger.awarning("No superuser found, using placeholder for role creation")
            system_user_id = UUID("00000000-0000-0000-0000-000000000000")

        roles = await create_default_roles(session, system_user_id)
        await logger.adebug(f"Successfully set up {len(roles)} default roles.")
    except Exception as exc:
        logger.exception(exc)
        await session.rollback()
        msg = "Could not create default roles."
        raise RuntimeError(msg) from exc


async def setup_default_groups(session: AsyncSession) -> None:
    """Setup default groups in the database."""
    try:
        await logger.adebug("Setting up default groups.")

        # Get the superuser to use as the creator of default groups
        stmt = select(User).where(User.is_superuser == True).limit(1)  # noqa: E712
        result = await session.exec(stmt)
        superuser = result.first()

        if superuser:
            system_user_id = superuser.id
        else:
            # If no superuser exists yet, use a placeholder
            # This shouldn't happen in practice since setup_superuser runs first
            await logger.awarning("No superuser found, using placeholder for group creation")
            from uuid import UUID
            system_user_id = UUID("00000000-0000-0000-0000-000000000000")

        groups = await create_default_groups(session, system_user_id)
        await logger.adebug(f"Successfully set up {len(groups)} default groups.")
    except Exception as exc:
        logger.exception(exc)
        await session.rollback()
        msg = "Could not create default groups."
        raise RuntimeError(msg) from exc
    

async def setup_default_metadatas(session: AsyncSession) -> None:
    """Setup default user metadatas in the database."""
    try:
        await logger.adebug("Setting up default user metadatas.")

        # Get the superuser to use as the creator of default metadatas
        stmt = select(User).where(User.is_superuser == True).limit(1)  # noqa: E712
        result = await session.exec(stmt)
        superuser = result.first()

        if superuser:
            system_user_id = superuser.id  # Keep as UUID object
        else:
            # If no superuser exists yet, use a placeholder
            # This shouldn't happen in practice since setup_superuser runs first
            await logger.awarning("No superuser found, using placeholder for metadata creation")
            system_user_id = UUID("00000000-0000-0000-0000-000000000000")

        metadatas = await create_default_masterdatas(session, system_user_id)
        await logger.adebug(f"Successfully set up {len(metadatas)} default metadatas.")
    except Exception as exc:
        logger.exception(exc)
        await session.rollback()
        msg = "Could not create default metadatas."
        raise RuntimeError(msg) from exc


async def setup_default_mcp_templates(session: AsyncSession) -> None:
    """Setup default MCP server templates in the database."""
    try:
        await logger.adebug("Setting up default MCP server templates.")
        
        from langflow.initial_setup.mcp_templates import initialize_mcp_templates
        
        await initialize_mcp_templates(session)
        await logger.adebug("Successfully set up default MCP server templates.")
    except Exception as exc:
        logger.exception(exc)
        await session.rollback()
        msg = "Could not create default MCP server templates."
        raise RuntimeError(msg) from exc
    

async def setup_default_selfhost_vdb_collection() -> None:
    """Setup default self-hosted VDB collection in the database."""
    try:
        import chromadb
        import os
        host = os.getenv("SELFHOST_CHROMA_HOST", None)
        if host:
            client = chromadb.HttpClient(
                host=host,
                port=int(os.getenv("SELFHOST_CHROMA_PORT", "8000")),
                settings=chromadb.config.Settings(
                    chroma_client_auth_provider="chromadb.auth.token_authn.TokenAuthClientProvider",
                    chroma_client_auth_credentials=os.getenv("SELFHOST_CHROMA_API_KEY") or "_",
                    chroma_auth_token_transport_header="Authorization",
                ),
            )
        else:
            client = chromadb.CloudClient(
                api_key=os.getenv("SELFHOST_CHROMA_API_KEY"),
                tenant=os.getenv("SELFHOST_CHROMA_TENANT_ID"),
                database=os.getenv("SELFHOST_CHROMA_DATABASE_NAME"),
            )
        collection_name = os.getenv("SELFHOST_VDB_COLLECTION_NAME", "default_collection")
        collection = client.get_or_create_collection(name=collection_name)
        logger.debug(f"Self-hosted VDB collection '{collection_name}' is set up.")
    except Exception as exc:
        logger.exception(exc)
        msg = "Could not create self-hosted VDB collection."
        raise RuntimeError(msg) from exc
    

async def update_super_user_with_default_data(session: AsyncSession) -> None:
    """TODO: look into this"""
    stmt = select(User).where(User.is_superuser == True).limit(1)  # noqa: E712
    result = await session.exec(stmt)
    superuser = result.first()
    
    if not superuser:
        print("No superuser found to update with default data.")
        return

    # Update homepage_config only if not already set
    first_three_masterdatas = await get_first_three_homepage_config(session)
    if first_three_masterdatas:
        if not superuser.homepage_config:
            superuser.homepage_config = ",".join([str(md.id) for md in first_three_masterdatas])
            print("Superuser homepage_config updated with default masterdata.")
        else:
            print("Superuser homepage_config already set.")

    # Update role_id only if not already set
    default_admin_role = await get_user_role_by_name(session, DEFAULT_ADMIN_ROLE_NAME)
    if default_admin_role:
        if not superuser.role_id:
            superuser.role_id = default_admin_role.id
            print("Superuser updated with default admin role.")
        else:
            print("Superuser role_id already set.")
    
    default_group = await get_group_by_name(session, DEFAULT_GROUP_NAME)
    if superuser and default_group:
        from langflow.services.database.models.user_group.model import UserGroup
        
        # Check if the user is already in the group to avoid duplicates
        user_group_stmt = select(UserGroup).where(
            UserGroup.user_id == superuser.id,
            UserGroup.group_id == default_group.id
        )
        user_group_result = await session.exec(user_group_stmt)
        existing_user_group = user_group_result.first()
        
        if not existing_user_group:
            user_group = UserGroup(
                user_id=superuser.id,
                group_id=default_group.id,
                is_group_admin=True,
                create_by=superuser.id
            )
            session.add(user_group)
            print("Superuser added to default group as admin.")
        else:
            print("Superuser already exists in default group.")
    
    session.add(superuser)
    await session.commit()


async def teardown_services() -> None:
    """Teardown all the services."""
    async with session_scope() as session:
        await teardown_superuser(get_settings_service(), session)

    from lfx.services.manager import get_service_manager

    service_manager = get_service_manager()
    await service_manager.teardown()


def initialize_settings_service() -> None:
    """Initialize the settings manager."""
    from lfx.services.settings import factory as settings_factory

    get_service(ServiceType.SETTINGS_SERVICE, settings_factory.SettingsServiceFactory())


def initialize_session_service() -> None:
    """Initialize the session manager."""
    from langflow.services.cache import factory as cache_factory
    from langflow.services.session import factory as session_service_factory

    initialize_settings_service()

    get_service(
        ServiceType.CACHE_SERVICE,
        cache_factory.CacheServiceFactory(),
    )

    get_service(
        ServiceType.SESSION_SERVICE,
        session_service_factory.SessionServiceFactory(),
    )


async def clean_transactions(settings_service: SettingsService, session: AsyncSession) -> None:
    """Clean up old transactions from the database.

    This function deletes transactions that exceed the maximum number to keep (configured in settings).
    It orders transactions by timestamp descending and removes the oldest ones beyond the limit.

    Args:
        settings_service: The settings service containing configuration like max_transactions_to_keep
        session: The database session to use for the deletion
    """
    try:
        # Delete transactions using bulk delete
        delete_stmt = delete(TransactionTable).where(
            col(TransactionTable.id).in_(
                select(TransactionTable.id)
                .order_by(col(TransactionTable.timestamp).desc())
                .offset(settings_service.settings.max_transactions_to_keep)
            )
        )

        await session.exec(delete_stmt)
        await session.commit()
        logger.debug("Successfully cleaned up old transactions")
    except (sqlalchemy_exc.SQLAlchemyError, asyncio.TimeoutError) as exc:
        logger.error(f"Error cleaning up transactions: {exc!s}")
        await session.rollback()
        # Don't re-raise since this is a cleanup task


async def clean_vertex_builds(settings_service: SettingsService, session: AsyncSession) -> None:
    """Clean up old vertex builds from the database.

    This function deletes vertex builds that exceed the maximum number to keep (configured in settings).
    It orders vertex builds by timestamp descending and removes the oldest ones beyond the limit.

    Args:
        settings_service: The settings service containing configuration like max_vertex_builds_to_keep
        session: The database session to use for the deletion
    """
    try:
        # Delete vertex builds using bulk delete
        delete_stmt = delete(VertexBuildTable).where(
            col(VertexBuildTable.id).in_(
                select(VertexBuildTable.id)
                .order_by(col(VertexBuildTable.timestamp).desc())
                .offset(settings_service.settings.max_vertex_builds_to_keep)
            )
        )

        await session.exec(delete_stmt)
        await session.commit()
        logger.debug("Successfully cleaned up old vertex builds")
    except (sqlalchemy_exc.SQLAlchemyError, asyncio.TimeoutError) as exc:
        logger.error(f"Error cleaning up vertex builds: {exc!s}")
        await session.rollback()
        # Don't re-raise since this is a cleanup task


def register_all_service_factories() -> None:
    """Register all available service factories with the service manager."""
    # Import all service factories
    from lfx.services.manager import get_service_manager

    service_manager = get_service_manager()
    from lfx.services.mcp_composer import factory as mcp_composer_factory
    from lfx.services.settings import factory as settings_factory

    from langflow.services.auth import factory as auth_factory
    from langflow.services.cache import factory as cache_factory
    from langflow.services.chat import factory as chat_factory
    from langflow.services.database import factory as database_factory
    from langflow.services.job_queue import factory as job_queue_factory
    from langflow.services.session import factory as session_factory
    from langflow.services.shared_component_cache import factory as shared_component_cache_factory
    from langflow.services.state import factory as state_factory
    from langflow.services.storage import factory as storage_factory
    from langflow.services.store import factory as store_factory
    from langflow.services.task import factory as task_factory
    from langflow.services.telemetry import factory as telemetry_factory
    from langflow.services.tracing import factory as tracing_factory
    from langflow.services.variable import factory as variable_factory

    # Register all factories
    service_manager.register_factory(settings_factory.SettingsServiceFactory())
    service_manager.register_factory(cache_factory.CacheServiceFactory())
    service_manager.register_factory(chat_factory.ChatServiceFactory())
    service_manager.register_factory(database_factory.DatabaseServiceFactory())
    service_manager.register_factory(session_factory.SessionServiceFactory())
    service_manager.register_factory(storage_factory.StorageServiceFactory())
    service_manager.register_factory(variable_factory.VariableServiceFactory())
    service_manager.register_factory(telemetry_factory.TelemetryServiceFactory())
    service_manager.register_factory(tracing_factory.TracingServiceFactory())
    service_manager.register_factory(state_factory.StateServiceFactory())
    service_manager.register_factory(job_queue_factory.JobQueueServiceFactory())
    service_manager.register_factory(task_factory.TaskServiceFactory())
    service_manager.register_factory(store_factory.StoreServiceFactory())
    service_manager.register_factory(shared_component_cache_factory.SharedComponentCacheServiceFactory())
    service_manager.register_factory(auth_factory.AuthServiceFactory())
    service_manager.register_factory(mcp_composer_factory.MCPComposerServiceFactory())
    service_manager.set_factory_registered()


async def initialize_services(*, fix_migration: bool = False) -> None:
    """Initialize all the services needed."""
    # Register all service factories first
    register_all_service_factories()

    cache_service = get_service(ServiceType.CACHE_SERVICE, default=CacheServiceFactory())
    # Test external cache connection
    if isinstance(cache_service, ExternalAsyncBaseCacheService) and not (await cache_service.is_connected()):
        msg = "Cache service failed to connect to external database"
        raise ConnectionError(msg)

    # Setup the superuser
    await initialize_database(fix_migration=fix_migration)
    db_service = get_db_service()
    await db_service.initialize_alembic_log_file()
    async with session_scope() as session:
        settings_service = get_service(ServiceType.SETTINGS_SERVICE)
        await setup_superuser(settings_service, session)
        # Setup default roles, groups, metadatas, and MCP templates after superuser is created
        await setup_default_roles(session)
        await setup_default_groups(session)
        await setup_default_metadatas(session)
        await setup_default_mcp_templates(session)
        await update_super_user_with_default_data(session)
        await setup_default_selfhost_vdb_collection() # warning: blocking call
    try:
        await get_db_service().assign_orphaned_flows_to_superuser()
    except sqlalchemy_exc.IntegrityError as exc:
        await logger.awarning(f"Error assigning orphaned flows to the superuser: {exc!s}")
    await clean_transactions(settings_service, session)
    await clean_vertex_builds(settings_service, session)
