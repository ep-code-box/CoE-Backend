"""260506 fix enum

Revision ID: aeeaf5f940c5
Revises: acf8d888a4e8
Create Date: 2026-05-06 15:02:53.823109

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel
from sqlalchemy.engine.reflection import Inspector
from langflow.utils import migration


# revision identifiers, used by Alembic.
revision: str = 'aeeaf5f940c5'
down_revision: Union[str, None] = 'acf8d888a4e8'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_RENAME_MAP = {
    "faq": "FAQ",
    "faq_general": "FAQ_GENERAL",
    "faq_account": "FAQ_ACCOUNT",
    "faq_agent_designer": "FAQ_AGENT_DESIGNER",
    "faq_db": "FAQ_DB",
    "faq_mcp": "FAQ_MCP",
    "faq_ax_monitor": "FAQ_AX_MONITOR",
    "faq_permission_approval": "FAQ_PERMISSION_APPROVAL",
    "ai_agent": "AI_AGENT",
    "tool_catalog": "TOOL_CATALOG",
    "data_catalog": "DATA_CATALOG",
    "ax_studio_features": "AX_STUDIO_FEATURES",
}


def upgrade() -> None:
    conn = op.get_bind()
    if conn.dialect.name == "postgresql":
        for old, new in _RENAME_MAP.items():
            op.execute(sa.text(f"""
                DO $$
                BEGIN
                    IF EXISTS (
                        SELECT 1 FROM pg_enum
                        JOIN pg_type ON pg_type.oid = pg_enum.enumtypid
                        WHERE pg_type.typname = 'guidetypeenum'
                          AND pg_enum.enumlabel = '{old}'
                    ) THEN
                        ALTER TYPE guidetypeenum RENAME VALUE '{old}' TO '{new}';
                    END IF;
                END;
                $$;
            """))
    else:
        # SQLite / other: enum stored as plain VARCHAR, just UPDATE rows
        for old, new in _RENAME_MAP.items():
            op.execute(
                sa.text("UPDATE guide SET guide_type = :new WHERE guide_type = :old"),
                {"new": new, "old": old},
            )


def downgrade() -> None:
    conn = op.get_bind()
    if conn.dialect.name == "postgresql":
        for old, new in _RENAME_MAP.items():
            op.execute(sa.text(f"""
                DO $$
                BEGIN
                    IF EXISTS (
                        SELECT 1 FROM pg_enum
                        JOIN pg_type ON pg_type.oid = pg_enum.enumtypid
                        WHERE pg_type.typname = 'guidetypeenum'
                          AND pg_enum.enumlabel = '{new}'
                    ) THEN
                        ALTER TYPE guidetypeenum RENAME VALUE '{new}' TO '{old}';
                    END IF;
                END;
                $$;
            """))
    else:
        for old, new in _RENAME_MAP.items():
            op.execute(
                sa.text("UPDATE guide SET guide_type = :old WHERE guide_type = :new"),
                {"new": new, "old": old},
            )
 