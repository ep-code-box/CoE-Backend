"""260504 merge heads

Revision ID: acf8d888a4e8
Revises: 7669928c0c87, a1b2c3d4e5f6
Create Date: 2026-05-04 10:50:22.509877

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel
from sqlalchemy.engine.reflection import Inspector
from langflow.utils import migration


# revision identifiers, used by Alembic.
revision: str = 'acf8d888a4e8'
down_revision: Union[str, None] = ('7669928c0c87', 'a1b2c3d4e5f6')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()
    pass


def downgrade() -> None:
    conn = op.get_bind()
    pass
