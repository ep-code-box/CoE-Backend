"""260515 add component_id to occupied_resource

Revision ID: a3f7e2b9c104
Revises: 551fa4039363
Create Date: 2026-05-15 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a3f7e2b9c104'
down_revision: Union[str, None] = '551fa4039363'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('occupiedresource', schema=None) as batch_op:
        batch_op.add_column(sa.Column('component_id', sa.String(), nullable=True))
        batch_op.create_index(batch_op.f('ix_occupiedresource_component_id'), ['component_id'], unique=False)


def downgrade() -> None:
    with op.batch_alter_table('occupiedresource', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_occupiedresource_component_id'))
        batch_op.drop_column('component_id')
