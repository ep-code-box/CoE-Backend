"""2026-04-21_add_mcp_server_history

Revision ID: a1b2c3d4e5f6
Revises: 7e5f3c684891
Create Date: 2026-04-23 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel


# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f6'
down_revision: Union[str, None] = '7e5f3c684891'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        'mcpserverhistory',
        sa.Column('id', sa.Uuid(), nullable=False),
        sa.Column('mcp_server_id', sa.Uuid(), nullable=False),
        sa.Column('action', sqlmodel.sql.sqltypes.AutoString(), nullable=False),
        sa.Column('description', sqlmodel.sql.sqltypes.AutoString(), nullable=False),
        sa.Column('old_values', sqlmodel.sql.sqltypes.AutoString(), nullable=True),
        sa.Column('new_values', sqlmodel.sql.sqltypes.AutoString(), nullable=True),
        sa.Column('create_by', sa.Uuid(), nullable=False),
        sa.Column('create_at', sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('id'),
    )
    with op.batch_alter_table('mcpserverhistory', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_mcpserverhistory_mcp_server_id'), ['mcp_server_id'], unique=False)


def downgrade() -> None:
    with op.batch_alter_table('mcpserverhistory', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_mcpserverhistory_mcp_server_id'))
    op.drop_table('mcpserverhistory')
