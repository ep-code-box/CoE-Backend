from typing import Any
import os
from lfx.settings import DEV

from lfx.base.vectorstores.model import LCVectorStoreComponent, check_cached_vector_store
from lfx.inputs.inputs import DropdownInput, HandleInput, IntInput, SecretStrInput, StrInput
from lfx.schema.data import Data
from lfx.log.logger import logger


class QdrantVectorStoreComponent(LCVectorStoreComponent):
    display_name = "Qdrant"
    description = "Qdrant Vector Store from Data Catalog with search capabilities"
    icon = "QDrant"
    name = "Qdrant"

    inputs = [
        DropdownInput(
            name="database_name",
            display_name="Vector Database",
            info="Select the database from your configured data assets",
            options=[],
            value="",
            refresh_button=True,
            real_time_refresh=True,
        ),
        DropdownInput(
            name="collection_name",
            display_name="Collection Name",
            info="Select a collection from the connected Qdrant database",
            options=[],
            value="",
            refresh_button=True,
            real_time_refresh=True,
        ),
        StrInput(name="url", display_name="URL", advanced=True),
        StrInput(name="host", display_name="Host", value="", advanced=True),
        IntInput(name="port", display_name="Port", value=6333, advanced=True),
        StrInput(name="api_key_cfg", display_name="Qdrant API Key", advanced=True),
        *LCVectorStoreComponent.inputs,

        HandleInput(name="embedding", display_name="Embedding", input_types=["Embeddings"]),
        IntInput(
            name="number_of_results",
            display_name="Number of Results",
            info="Number of results to return.",
            value=4,
            advanced=True,
        ),

    ]

    '''BEGIN SAME LOGIC'''

    def _add_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Record that the current flow occupies (uses) a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import add_new_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await add_new_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error recording occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def _remove_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Remove the record of the current flow occupying a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import remove_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await remove_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error removing occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def update_build_config(self, build_config: dict, field_value: Any, field_name: str | None = None) -> dict:
        """Update build configuration - MUST be synchronous."""
        if field_name in {"database_name", None}:
            data_asset = self._load_data_asset_sync()

            name_counts: dict[str, int] = {}
            for ds in data_asset:
                name_counts[ds["name"]] = name_counts.get(ds["name"], 0) + 1
            for ds in data_asset:
                if name_counts[ds["name"]] > 1:
                    ds["display_name"] = f"{ds['name']} ({str(ds['id'])[-8:]})"
                else:
                    ds["display_name"] = ds["name"]

            self._data_asset_cache = data_asset
            build_config["database_name"]["options"] = [ds["display_name"] for ds in data_asset]
            build_config["database_name"]["options_metadata"] = [
                {"id": str(ds["id"]), "type": ds["type"].value, "created_by": ds["created_by"]} for ds in data_asset
            ]

        if field_name == "database_name" and field_value:
            options = build_config["database_name"].get("options", [])
            options_metadata = build_config["database_name"].get("options_metadata", [])
            try:
                idx = options.index(field_value)
                asset_id = options_metadata[idx]["id"]
                asset_type = options_metadata[idx]["type"]
            except (ValueError, IndexError):
                return build_config

            vdb_config = self._get_connection_config_sync(asset_id, asset_type)
            if vdb_config:
                from langflow.services.database.models.resource_permission.constants import ResourceTypes
                self._add_occupied_resource_sync(asset_id, ResourceTypes.DATABASE)
                build_config["url"]["value"] = vdb_config.uri 
                build_config["host"]["value"] = vdb_config.host 
                build_config["port"]["value"] = vdb_config.port or 6333
                build_config["api_key_cfg"]["value"] = vdb_config.api_key

                collections = self._load_collections_sync(vdb_config)
                build_config["collection_name"]["options"] = collections
                build_config["collection_name"]["value"] = collections[0] if collections else ""

        return build_config

    def _load_data_asset_sync(self) -> list[dict]:
        """Synchronously load data_asset using asyncio.run."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.datasource import get_data_asset_list
        from langflow.services.database.models.user.crud import get_user_by_id
        from langflow.services.database.models.datasource.constants import DataAssetType

        async def _load():
            try:
                async with session_scope() as db:
                    if not self.user_id:
                        print("User ID is not available")
                        return []

                    current_user = await get_user_by_id(db, self.user_id)
                    if not current_user or not current_user.user_groups:
                        print("User or user groups not found")
                        return []

                    user_group_id = current_user.user_groups[0].group_id
                    all_data_asset, _ = await get_data_asset_list(
                        db,
                        filter_by={
                            "group_id": user_group_id,
                            "datasource_type": DataAssetType.QDRANT,
                        },
                        page_size=1000,
                        user_id=self.user_id,
                        filter_by_permission=True,
                    )
                    return [
                        {"name": ds.name, "id": ds.id, "type": ds.datasource_type, "created_by": ds.create_by}
                        for ds in all_data_asset
                    ]
            except Exception as e:
                print(f"Error loading data_asset: {e}")
                return []

        try:
            return asyncio.run(_load())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")
            return []

    def _get_connection_config_sync(self, data_asset_id: str, data_asset_type: str):
        """Synchronously get connection config for a data_asset."""
        import asyncio
        from uuid import UUID
        from lfx.services.deps import session_scope
        from langflow.services.database.models.data_asset_vdb import get_data_asset_config_vdb_by_id

        async def _load():
            try:
                async with session_scope() as db:
                    vdb_config = await get_data_asset_config_vdb_by_id(db, data_asset_id=UUID(data_asset_id))
                    return vdb_config
            except Exception as e:
                print(f"Error loading connection config: {e}")
                return None

        try:
            return asyncio.run(_load())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")
            return None

    def _load_collections_sync(self, vdb_config) -> list[str]:
        """Load collection list from cached_metadata in DataAssetConnectionVdb."""
        if vdb_config and vdb_config.cached_metadata:
            collections_data = vdb_config.cached_metadata.get("collections", [])
            if collections_data:
                return [c["collection_name"] for c in collections_data if c.get("collection_name")]
        return []

    '''END SAME LOGIC'''
    @check_cached_vector_store
    def build_vector_store(self):
        """Build the Qdrant vector store."""
        from langchain_qdrant import QdrantVectorStore
        from qdrant_client import QdrantClient
        # Import specific exception to provide clearer error messages for HTTP errors
        try:
            # qdrant_client may expose HTTP exceptions from different modules depending on version
            from qdrant_client.http.exceptions import UnexpectedResponse
        except Exception:
            UnexpectedResponse = Exception

        api_key = self.api_key_cfg

        # Fail fast if the API key is missing so we can trace where it becomes None
        if api_key is None:
            try:
                host_or_url = self.host or self.url or "<not provided>"
                logger.error(
                    "QDRANT-ERROR missing api_key: url=%s, host=%s, port=%s, collection=%s",
                    self.url,
                    self.host,
                    self.port,
                    self.collection_name,
                )
            except Exception:
                pass
            raise RuntimeError(
                f"Qdrant API key is None for connection (url={self.url}, host={self.host}, port={self.port}, collection={self.collection_name})."
                "Ensure {self.api_key_cfg} the DataAssetConnectionVdb entry includes an api_key and that update_build_config/_get_connection_config_sync return it."
            )

        # Create Qdrant client with graceful error reporting
        try:
            if self.host:
                client = QdrantClient(
                    host=self.host,
                    port=int(self.port),
                    api_key=self.api_key_cfg,
                )
            else:
                client = QdrantClient(
                    url=self.url,
                    api_key=self.api_key_cfg,
                )
        except Exception as e:  # network/auth errors
            logger.exception("Failed to create Qdrant client")
            host_or_url = self.host or self.url or "<not provided>"
            raise RuntimeError(f"Unable to connect to Qdrant at {host_or_url}:{self.port} - {e}") from e

        # Convert ingest data to documents
        self.ingest_data = self._prepare_ingest_data()
        documents = []
        for _input in self.ingest_data or []:
            if isinstance(_input, Data):
                documents.append(_input.to_lc_document())
            else:
                documents.append(_input)

        try:
            if documents:
                # When a full URL is provided (including scheme), do not pass a numeric port
                # to avoid constructing an incorrect endpoint (common with Qdrant Cloud URLs).
                from_docs_kwargs = dict(
                    documents=documents,
                    embedding=self.embedding,
                    api_key=self.api_key_cfg,
                    collection_name=self.collection_name,
                )
                if self.url:
                    from_docs_kwargs["url"] = self.url
                else:
                    from_docs_kwargs["host"] = self.host or None
                    from_docs_kwargs["port"] = int(self.port)

                qdrant = QdrantVectorStore.from_documents(**from_docs_kwargs)
            else:
                qdrant = QdrantVectorStore(
                    client=client,
                    collection_name=self.collection_name,
                    embedding=self.embedding,
                )
        except UnexpectedResponse as ure:
            # Provide clearer guidance when the remote Qdrant HTTP API returns a 4xx/5xx
            logger.exception("Qdrant UnexpectedResponse when initializing vector store")
            # Try to extract useful info from the exception; be defensive because exception
            # shape may vary between qdrant_client versions.
            exc_text = None
            try:
                exc_text = str(ure)
            except Exception:
                exc_text = repr(ure)

            host_or_url = self.host or self.url or "<not provided>"



            # Per developer request (dev server): include the full original API key in the error message
            which_connect = "host/port" if self.host else "url"

            msg = (
                f"Qdrant HTTP error while accessing collection '{self.collection_name}' on {host_or_url}:{self.port}."
                f" (connect_via={which_connect}, url={self.url or '<none>'}, host={self.host or '<none>'}, port={self.port})\n"
                f"api_key_present={bool(self.api_key_cfg)}, api_key={self.api_key_cfg}.\n"
                f"Response/exception: {exc_text}.\n"
                "Common causes: invalid/expired API key, insufficient permissions on the Qdrant collection, or a proxy rejecting requests.\n"
                "Verify the DataAssetConnectionVdb entry for this vector DB (uri/host/port/api_key), and test the HTTP API directly using curl or the qdrant_client python snippet."
            )
            raise RuntimeError(msg) from ure
        except Exception as e:
            logger.exception("Failed to initialize Qdrant vector store")
            host_or_url = self.host or self.url or "<not provided>"
            raise RuntimeError(f"Failed to initialize Qdrant vector store for {host_or_url}:{self.port} - {e}") from e
        logger.debug(f"Built Qdrant vector store with config: api_key={self.api_key_cfg}, url={self.url}, host={self.host}, port={self.port}, collection_name={self.collection_name}")

        return qdrant

    def search_documents(self) -> list[Data]:
        vector_store = self.build_vector_store()

        if self.search_query and isinstance(self.search_query, str) and self.search_query.strip():
            docs = vector_store.similarity_search(
                query=self.search_query,
                k=self.number_of_results,
            )
            data = [Data.from_document(doc) for doc in docs]
            self.status = data
            return data
        return []
