"""
Custom embedding model component for AX-Studio.

Loads available collections from the VDB upload history, auto-fetches the embedding
model name stored in the database, and resolves the API key / base URL from
environment variables so the user does not have to configure them manually.
"""
import os
from typing import Any

from langchain_openai import OpenAIEmbeddings

from lfx.base.embeddings.model import LCEmbeddingsModel
from lfx.field_typing import Embeddings
from lfx.inputs.inputs import DropdownInput, StrInput


class EmbeddingModelComponent(LCEmbeddingsModel):
    display_name = "AX-Studio Embedding Model"
    description = (
        "Auto-generate embeddings using the embedding model stored in the selected "
        "data asset. API key and base URL are resolved from environment variables."
    )
    documentation: str = "https://docs.langflow.org/components-embedding-models"
    icon = "binary"
    name = "AX-Studio Embedding Model"
    category = "models"

    inputs = [
        DropdownInput(
            name="database_name",
            display_name="Upload Session Name",
            info="Select the data asset (collection) from your configured data assets.",
            options=[],
            value="",
            refresh_button=True,
            real_time_refresh=True,
        ),
        StrInput(
            name="collection_name",
            display_name="Collection Name",
            info="Chroma collection name (auto-filled when a session is selected).",
            value="",
            advanced=True,
        ),
        StrInput(
            name="embedding_model_name",
            display_name="Embedding Model Name",
            info="Model name (auto-filled from the database when a session is selected).",
            value="",
            advanced=False,
        ),
    ]

    # ---------------------------------------------------------------------------
    # Dynamic config
    # ---------------------------------------------------------------------------

    def _add_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Record that the current flow occupies (uses) a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import add_new_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await add_new_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error recording occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def _remove_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Remove the record of the current flow occupying a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import remove_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await remove_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error removing occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def update_build_config(
        self, build_config: dict, field_value: Any, field_name: str | None = None
    ) -> dict:
        """Populate the dropdown and auto-fill dependent fields."""
        if field_name in {"database_name", None}:
            data_assets = self._load_data_asset_sync()
            self._data_asset_cache = data_assets
            build_config["database_name"]["options"] = [ds["name"] for ds in data_assets]

        if field_name == "database_name" and field_value:
            cache = getattr(self, "_data_asset_cache", None) or self._load_data_asset_sync()
            selected = next((ds for ds in cache if ds["name"] == field_value), None)
            if selected:
                from langflow.services.database.models.resource_permission.constants import ResourceTypes
                self._add_occupied_resource_sync(str(selected["id"]), ResourceTypes.SELF_HOSTED_VDB)
                build_config["collection_name"]["value"] = selected["collection_name"]
                build_config["embedding_model_name"]["value"] = selected["embedding_model_name"] or ""

        return build_config

    # ---------------------------------------------------------------------------
    # Sync DB loader (mirrors chromaselfhost.py pattern)
    # ---------------------------------------------------------------------------

    def _load_data_asset_sync(self) -> list[dict]:
        """Synchronously fetch available data assets from the database."""
        import asyncio

        async def _load() -> list[dict]:
            try:
                from lfx.services.deps import session_scope
                from langflow.services.database.models.vdb_upload_history import get_vdb_upload_history_list
                from langflow.services.database.models.user.crud import get_user_by_id

                async with session_scope() as db:
                    if not self.user_id:
                        return []

                    current_user = await get_user_by_id(db, self.user_id)
                    if not current_user or not current_user.user_groups:
                        return []

                    user_group_id = current_user.user_groups[0].group_id
                    all_data_assets, _ = await get_vdb_upload_history_list(
                        db,
                        filter_by={"group_id": user_group_id},
                        page_size=1000,
                        user_id=self.user_id,
                        filter_by_permission=True,
                    )

                    seen_names: set[str] = set()
                    result: list[dict] = []
                    for da in all_data_assets:
                        if da.name not in seen_names:
                            seen_names.add(da.name)
                            result.append(
                                {
                                    "name": da.name,
                                    "id": da.id,
                                    "collection_name": da.collection_name,
                                    "embedding_model_name": da.embedding_model_name,
                                }
                            )
                    return result
            except Exception as e:
                print(f"Error loading data assets: {e}")
                return []

        try:
            return asyncio.run(_load())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")
            return []

    # ---------------------------------------------------------------------------
    # Embedding builder
    # ---------------------------------------------------------------------------

    def build_embeddings(self) -> Embeddings:
        model = self.embedding_model_name
        if not model:
            msg = (
                "No embedding model found. Please select an Upload Session that has an "
                "embedding model stored in the database."
            )
            raise ValueError(msg)

        api_key = self._get_api_key()
        api_base = self._get_api_base()

        return OpenAIEmbeddings(
            model=model,
            api_key=api_key,
            base_url=api_base or None,
        )

    # ---------------------------------------------------------------------------
    # Environment variable helpers
    # ---------------------------------------------------------------------------

    def _get_api_key(self) -> str:
        key = os.getenv("OPENAI_EMB_API_KEY")
        if not key:
            raise ValueError("OPENAI_EMB_API_KEY environment variable is not set.")
        return key

    def _get_api_base(self) -> str | None:
        return os.getenv("OPENAI_EMB_API_BASE") or None
    
    
