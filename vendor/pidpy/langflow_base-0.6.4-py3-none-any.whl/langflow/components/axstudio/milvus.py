from lfx.base.vectorstores.model import LCVectorStoreComponent, check_cached_vector_store
from lfx.helpers.data import docs_to_data
from lfx.io import (
    BoolInput,
    DictInput,
    DropdownInput,
    FloatInput,
    HandleInput,
    IntInput,
    SecretStrInput,
    StrInput,
)
from lfx.schema.data import Data

from typing import TYPE_CHECKING, Any

from lfx.log.logger import logger


class MilvusVectorStoreComponent(LCVectorStoreComponent):
    """Milvus vector store with search capabilities."""

    display_name: str = "Milvus External Database"
    description: str = "Milvus vector store with search capabilities"
    name = "Milvus External Database"
    icon = "Milvus"

    inputs = [
        DropdownInput(
            name="database_name",
            display_name="Database Name",
            info="Select the database from your configured data assets",
            options=[],
            value="",
            refresh_button=True,
            real_time_refresh=True,
        ),
        DropdownInput(
            name="collection_name",
            display_name="Collection Name",
            info="Select the collection from your configured data assets",
            options=[],
            value="",
            refresh_button=True,
            real_time_refresh=True,
        ),
        StrInput(
            name="uri",
            display_name="Connection URI",
            value="",
            advanced=True,
            info="Auto-populated when a database is selected.",
        ),
        SecretStrInput(
            name="password",
            display_name="Milvus Token (API Key)",
            value="",
            advanced=True,
            info="Auto-populated when a database is selected.",
        ),
        DictInput(name="connection_args", display_name="Other Connection Arguments", advanced=True),
        StrInput(name="primary_field", display_name="Primary Field Name", value="pk"),
        StrInput(name="collection_description", display_name="Collection Description", value=""),
        DropdownInput(
            name="text_field",
            display_name="Text Field Name",
            options=[],
            value="",
            info="Auto-populated from the selected collection's schema.",
        ),
        StrInput(name="vector_field", display_name="Vector Field Name", value="vector"),
        DropdownInput(
            name="consistency_level",
            display_name="Consistencey Level",
            options=["Bounded", "Session", "Strong", "Eventual"],
            value="Session",
            advanced=True,
        ),
        DictInput(name="index_params", display_name="Index Parameters", advanced=True),
        DictInput(name="search_params", display_name="Search Parameters", advanced=True),
        BoolInput(name="drop_old", display_name="Drop Old Collection", value=False, advanced=True),
        FloatInput(name="timeout", display_name="Timeout", advanced=True),
        StrInput(
            name="collection_schema",
            display_name="Collection Schema",
            info="Auto-populated with the schema of the selected collection (JSON).",
            value="",
            advanced=True,
        ),
        *LCVectorStoreComponent.inputs,
        HandleInput(name="embedding", display_name="Embedding", input_types=["Embeddings"]),
        IntInput(
            name="number_of_results",
            display_name="Number of Results",
            info="Number of results to return.",
            value=4,
            advanced=True,
        ),
    ]

    
    '''BEGIN SAME LOGIC'''

    # Vector field type identifiers (int enum values and string names)
    _VECTOR_TYPES = {
        100, 101, 102, 103, 104,  # BINARY_VECTOR, FLOAT_VECTOR, FLOAT16_VECTOR, BFLOAT16_VECTOR, SPARSE_FLOAT_VECTOR
        'BINARY_VECTOR', 'FLOAT_VECTOR', 'FLOAT16_VECTOR', 'BFLOAT16_VECTOR', 'SPARSE_FLOAT_VECTOR',
    }

    def _add_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Record that the current flow occupies (uses) a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import add_new_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await add_new_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error recording occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def _remove_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Remove the record of the current flow occupying a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import remove_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await remove_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error removing occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def update_build_config(self, build_config: dict, field_value: Any, field_name: str | None = None) -> dict:
        """Update build configuration - MUST be synchronous."""
        # Step 1: Load database list on init, database refresh, or collection refresh
        if field_name in {"database_name", "collection_name", None}:
            logger.info("Updating database_name list in build config")
            database_name = self._load_milvus_database_name_sync()

            # Generate unique display names when multiple assets share the same name
            name_counts: dict[str, int] = {}
            for ds in database_name:
                name_counts[ds["name"]] = name_counts.get(ds["name"], 0) + 1
            for ds in database_name:
                if name_counts[ds["name"]] > 1:
                    ds["display_name"] = f"{ds['name']} ({str(ds['id'])[-8:]})"
                else:
                    ds["display_name"] = ds["name"]

            build_config["database_name"]["options"] = [ds["display_name"] for ds in database_name]
            build_config["database_name"]["options_metadata"] = [
                {
                    "id": str(ds["id"]),
                    "uri": ds.get("uri") or "",
                    "api_key": ds.get("api_key") or "",
                    "cached_metadata": ds.get("cached_metadata") or {},
                    "created_by": ds["created_by"],
                }
                for ds in database_name
            ]

        # Step 2: When a database is selected, auto-set connection fields and collection list
        if field_name == "database_name" and field_value:
            options = build_config["database_name"].get("options", [])
            options_metadata = build_config["database_name"].get("options_metadata", [])
            try:
                idx = options.index(field_value)
                meta = options_metadata[idx]
            except (ValueError, IndexError):
                logger.info(f"Could not find metadata for selected database: {field_value}")
                return build_config

            uri = meta.get("uri", "")
            api_key = meta.get("api_key", "")
            cached_metadata = meta.get("cached_metadata") or {}

            from langflow.services.database.models.resource_permission.constants import ResourceTypes
            self._add_occupied_resource_sync(meta["id"], ResourceTypes.DATABASE)

            build_config["uri"]["value"] = uri
            build_config["password"]["value"] = api_key

            # Populate collection list from cached_metadata
            collections_data = cached_metadata.get("collections", [])
            collections = [c["collection_name"] for c in collections_data if c.get("collection_name")]
            logger.info(f"Found {len(collections)} collections in cached_metadata for {field_value}")
            build_config["collection_name"]["options"] = collections
            build_config["collection_name"]["value"] = collections[0] if collections else ""

        # Step 2b: When collection refresh is clicked, reload collections for the current database
        if field_name == "collection_name":
            current_db = build_config["database_name"].get("value", "")
            if current_db:
                options = build_config["database_name"].get("options", [])
                options_metadata = build_config["database_name"].get("options_metadata", [])
                try:
                    idx = options.index(current_db)
                    meta = options_metadata[idx]
                    cached_metadata = meta.get("cached_metadata") or {}
                    build_config["uri"]["value"] = meta.get("uri", "")
                    build_config["password"]["value"] = meta.get("api_key", "")
                    collections_data = cached_metadata.get("collections", [])
                    collections = [c["collection_name"] for c in collections_data if c.get("collection_name")]
                    logger.info(f"Reloaded {len(collections)} collections for database: {current_db}")
                    build_config["collection_name"]["options"] = collections
                except (ValueError, IndexError):
                    logger.info(f"Could not reload collections for database: {current_db}")

        # Step 3: When a collection is selected, fetch schema and auto-populate fields
        if field_name == "collection_name" and field_value:
            import json
            uri = build_config.get("uri", {}).get("value", "")
            password = build_config.get("password", {}).get("value", "")
            info = self._fetch_collection_info_sync(uri, password, field_value)
            build_config["collection_schema"]["value"] = json.dumps(info, default=str)

            schema_fields = info.get("fields", [])
            primary_name = None
            vector_name = None
            text_options = []

            for field in schema_fields:
                fname = field.get("name", "")
                ftype = field.get("type")
                is_primary = field.get("is_primary", False)

                if is_primary:
                    primary_name = fname
                elif ftype in self._VECTOR_TYPES:
                    vector_name = fname
                else:
                    text_options.append(fname)

            if primary_name:
                build_config["primary_field"]["value"] = primary_name
            if vector_name:
                build_config["vector_field"]["value"] = vector_name
            build_config["text_field"]["options"] = text_options
            build_config["text_field"]["value"] = text_options[0] if text_options else ""

        return build_config

    def _load_milvus_database_name_sync(self) -> list[str]:
        """Read collection names from cached_metadata of the DataAssetConnectionVdb matching the URI."""

        import asyncio
        from sqlmodel import select, or_, and_
        from lfx.services.deps import session_scope
        from langflow.services.database.models.user.crud import get_user_by_id
        from langflow.services.database.models.datasource.model import Datasource
        from langflow.services.database.models.datasource.constants import DataAssetType
        from langflow.services.database.models.data_asset_vdb.model import DataAssetConnectionVdb


        async def _load():
            try:
                logger.info("Loading database names from cached metadata")
                async with session_scope() as db:
                    if not self.user_id:
                        logger.info("User ID is not available")
                        return []

                    current_user = await get_user_by_id(db, self.user_id)
                    if not current_user or not current_user.user_groups:
                        logger.info("User or user groups not found")
                        return []

                    user_group_id = current_user.user_groups[0].group_id

                    fiter_condition = [
                        Datasource.datasource_type == DataAssetType.MILVUS,
                        Datasource.is_active == True,  # noqa: E712
                        Datasource.group_id == user_group_id,
                    ]
                    
                    if current_user.is_superuser:
                        fiter_condition.pop() # pop group filter for superusers


                    stmt = (
                        select(
                            Datasource.name,
                            Datasource.id,
                            Datasource.datasource_type,
                            DataAssetConnectionVdb.host,
                            DataAssetConnectionVdb.port,
                            DataAssetConnectionVdb.api_key,
                            DataAssetConnectionVdb.uri,
                            DataAssetConnectionVdb.cached_metadata,
                            Datasource.create_by,
                        )
                        .select_from(DataAssetConnectionVdb)
                        .join(Datasource, DataAssetConnectionVdb.data_source_id == Datasource.id, isouter=True)
                        .where(and_(*fiter_condition))
                    )

                    results = await db.exec(stmt)
                    rows = results.all()

                    logger.info(f"Found {len(rows)} Milvus data assets")
                    return [
                        {
                            "name": row.name,
                            "id": row.id,
                            "type": row.datasource_type,
                            "host": row.host,
                            "port": row.port,
                            "api_key": row.api_key,
                            "uri": row.uri,
                            "cached_metadata": row.cached_metadata,
                            "created_by": row.create_by,
                        }
                        for row in rows
                    ]
            except Exception as e:
                logger.info(f"Error loading data_asset: {e}")
                return []

        try:
            return asyncio.run(_load())
        except Exception as e:
            logger.info(f"Error in sync wrapper: {e}")
            return []

    @staticmethod
    def _run_in_thread(fn, *args, **kwargs):
        """Run a blocking function in a thread pool to avoid blocking the async server loop."""
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            return executor.submit(fn, *args, **kwargs).result()

    def _list_milvus_collections_sync(self, uri: str, password: str) -> list[str]:
        """Use synchronous MilvusClient in a thread to list collections.

        AsyncMilvusClient uses grpc.aio which caches the server event loop globally,
        causing 'Future attached to a different loop' errors regardless of thread tricks.
        The synchronous MilvusClient has no asyncio dependency and is safe to call here.
        """
        def _in_thread():
            from pymilvus import MilvusClient
            client = MilvusClient(uri=uri, token=password if password else None)
            try:
                return client.list_collections()
            except Exception as e:
                logger.info(f"Error listing Milvus collections: {e}")
                return []
            finally:
                client.close()

        try:
            return self._run_in_thread(_in_thread)
        except Exception as e:
            logger.info(f"Error in sync wrapper: {e}")
            return []

    def _fetch_collection_info_sync(self, uri: str, password: str, collection_name: str) -> dict:
        """Use synchronous MilvusClient in a thread to fetch collection info."""
        def _in_thread():
            from pymilvus import MilvusClient
            client = MilvusClient(uri=uri, token=password if password else None)
            try:
                return client.describe_collection(collection_name)
            except Exception as e:
                logger.info(f"Error fetching Milvus collection info for '{collection_name}': {e}")
                return {}
            finally:
                client.close()

        try:
            return self._run_in_thread(_in_thread)
        except Exception as e:
            logger.info(f"Error in sync wrapper: {e}")
            return {}

    '''END SAME LOGIC'''

    @check_cached_vector_store
    def build_vector_store(self):
        try:
            from langchain_milvus.vectorstores import Milvus as LangchainMilvus
        except ImportError as e:
            msg = "Could not import Milvus integration package. Please install it with `pip install langchain-milvus`."
            raise ImportError(msg) from e
        self.connection_args.update(uri=self.uri, token=self.password)
        milvus_store = LangchainMilvus(
            embedding_function=self.embedding,
            collection_name=self.collection_name,
            collection_description=self.collection_description,
            connection_args=self.connection_args,
            consistency_level=self.consistency_level,
            index_params=self.index_params,
            search_params=self.search_params,
            drop_old=self.drop_old,
            auto_id=True,
            primary_field=self.primary_field,
            text_field=self.text_field,
            vector_field=self.vector_field,
            timeout=self.timeout,
        )

        # Convert DataFrame to Data if needed using parent's method
        self.ingest_data = self._prepare_ingest_data()

        documents = []
        for _input in self.ingest_data or []:
            if isinstance(_input, Data):
                documents.append(_input.to_lc_document())
            else:
                documents.append(_input)

        if documents:
            milvus_store.add_documents(documents)

        return milvus_store

    def search_documents(self) -> list[Data]:
        vector_store = self.build_vector_store()

        if self.search_query and isinstance(self.search_query, str) and self.search_query.strip():
            docs = vector_store.similarity_search(
                query=self.search_query,
                k=self.number_of_results,
            )

            data = docs_to_data(docs)
            self.status = data
            return data
        return []
