from typing import TYPE_CHECKING, Any

from langchain_community.utilities import SQLDatabase
from sqlalchemy.exc import SQLAlchemyError

from lfx.custom.custom_component.component_with_cache import ComponentWithCache
from lfx.io import BoolInput, DropdownInput, MessageTextInput, MultilineInput, Output
from lfx.schema.dataframe import DataFrame
from lfx.schema.message import Message
from lfx.services.cache.utils import CacheMiss

if TYPE_CHECKING:
    from sqlalchemy.engine import Result


class SQLComponent(ComponentWithCache):
    """A axstudio sql component."""

    display_name = "SQL Database"
    description = "Axstudio custom component that executes SQL queries on SQLAlchemy-compatible databases."
    icon = "database"
    name = "SQLComponent"
    metadata = {"keywords": ["sql", "database", "query", "db", "fetch", "axstudio"]}

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.db: SQLDatabase = None
        self._datasources_cache = None

    def maybe_create_db(self):
        if self.database_url != "":
            if self._shared_component_cache:
                cached_db = self._shared_component_cache.get(self.database_url)
                if not isinstance(cached_db, CacheMiss):
                    self.db = cached_db
                    return
                print("Connecting to database")
            try:
                self.db = SQLDatabase.from_uri(self.database_url)
            except Exception as e:
                msg = f"An error occurred while connecting to the database: {e}"
                raise ValueError(msg) from e
            if self._shared_component_cache:
                self._shared_component_cache.set(self.database_url, self.db)

    inputs = [
        DropdownInput(
            name="database_name",
            display_name="Database",
            info="Select the database from your configured datasources",
            options=[],
            value="",
            refresh_button=True,
            real_time_refresh=True,
        ),
        MessageTextInput(
            name="database_url",
            display_name="Database URL",
            info="Auto-filled from selected database, or enter manually",
        ),
        MultilineInput(name="query", display_name="SQL Query", tool_mode=True, required=True),
        BoolInput(name="include_columns", display_name="Include Columns", value=True, tool_mode=True, advanced=True),
        BoolInput(
            name="add_error",
            display_name="Add Error",
            value=False,
            tool_mode=True,
            info="If True, the error will be added to the result",
            advanced=True,
        ),
    ]

    outputs = [
        Output(display_name="Result Table", name="run_sql_query", method="run_sql_query"),
    ]

    def _load_datasources_sync(self) -> list[dict]:
        """Synchronously load datasources using asyncio.run."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.datasource import get_data_asset_list
        from langflow.services.database.models.datasource.constants import DataAssetType
        from langflow.services.database.models.user.crud import get_user_by_id
        
        async def _load():
            try:
                async with session_scope() as db:
                    if not self.user_id:
                        print("User ID is not available")
                        return []
                    
                    current_user = await get_user_by_id(db, self.user_id)
                    if not current_user or not current_user.user_groups:
                        print("User or user groups not found")
                        return []
                    
                    user_group_id = current_user.user_groups[0].group_id
                    all_data_asset, _ = await get_data_asset_list(
                        db, 
                        filter_by={
                            "group_id": user_group_id,
                            "datasource_type": [
                                DataAssetType.POSTGRESQL,
                                DataAssetType.ORACLE, 
                                DataAssetType.MYSQL,
                                DataAssetType.MARIA_DB
                            ],
                        },
                        page_size=1000,
                        user_id=self.user_id,
                        filter_by_permission=True,
                    )
                    data_assets = [
                        {
                            "name": ds.name, "id": ds.id, "type": ds.datasource_type, "created_by": str(ds.create_by)
                        } for ds in all_data_asset
                    ]
                    return data_assets
            except Exception as e:
                print(f"Error loading data_assets: {e}")
                return []
        
        try:
            return asyncio.run(_load())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")
            return []

    def _add_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Record that the current flow occupies (uses) a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import add_new_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await add_new_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error recording occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def _remove_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Remove the record of the current flow occupying a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import remove_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await remove_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error removing occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def update_build_config(self, build_config: dict, field_value: Any, field_name: str | None = None) -> dict:
        """Update build configuration - MUST be synchronous."""
        # Load datasources when refresh button is clicked or component is initialized
        if field_name in {"database_name", None}:
            datasources = self._load_datasources_sync()
            self._datasources_cache = datasources
            build_config["database_name"]["options"] = [ds["name"] for ds in datasources]
            build_config["database_name"]["options_metadata"] = [
                {"id": str(ds["id"]), "type": ds["type"].value, "created_by": ds["created_by"]} for ds in datasources
            ]
        
        # When a database is selected, load its connection URL
        if field_name == "database_name" and field_value:
            if self._datasources_cache:
                selected = next((ds for ds in self._datasources_cache if ds["name"] == field_value), None)
                if selected:
                    from langflow.services.database.models.resource_permission.constants import ResourceTypes
                    self._add_occupied_resource_sync(str(selected["id"]), ResourceTypes.DATABASE)
                    # Load the connection string
                    conn_str = self._get_connection_string_sync(selected["id"], selected["type"].value)
                    if conn_str:
                        build_config["database_url"]["value"] = conn_str
        
        return build_config

    def _get_connection_string_sync(self, datasource_id: str, datasource_type: str) -> str:
        """Synchronously get connection string for a datasource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.datasource_rdb import get_datasource_rdb_by_datasource_id
        from langflow.services.database.models.datasource_rdb.utils import build_database_url_from_type
        from langflow.services.database.models.datasource.constants import DatasourceRDB
        
        async def _load():
            try:
                async with session_scope() as db:
                    rdb_config = await get_datasource_rdb_by_datasource_id(db, datasource_id)
                    if not rdb_config:
                        return ""
                    
                    dialect = "pymysql" if datasource_type in [DatasourceRDB.MYSQL.value, DatasourceRDB.MARIA_DB.value] else None
                    conn_str = build_database_url_from_type(
                        datasource_type=datasource_type,
                        host=rdb_config.host,
                        port=rdb_config.port,
                        database_name=rdb_config.database_name,
                        username=rdb_config.username,
                        password=rdb_config.password,
                        dialect=dialect,
                    )
                    return conn_str
            except Exception as e:
                print(f"Error loading connection string: {e}")
                return ""
        
        try:
            return asyncio.run(_load())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")
            return ""

    def __execute_query(self) -> list[dict[str, Any]]:
        self.maybe_create_db()
        try:
            cursor: Result[Any] = self.db.run(self.query, fetch="cursor")
            return [x._asdict() for x in cursor.fetchall()]
        except SQLAlchemyError as e:
            msg = f"An error occurred while running the SQL Query: {e}"
            print(msg)
            raise ValueError(msg) from e

    def run_sql_query(self) -> DataFrame:
        result = self.__execute_query()
        df_result = DataFrame(result)
        self.status = df_result
        return df_result