from copy import deepcopy
from typing import TYPE_CHECKING, Any

from chromadb.config import Settings
from langchain_chroma import Chroma
from typing_extensions import override

from lfx.base.vectorstores.model import LCVectorStoreComponent, check_cached_vector_store
from lfx.base.vectorstores.utils import chroma_collection_to_data
from lfx.inputs.inputs import BoolInput, DropdownInput, HandleInput, IntInput, StrInput
from lfx.schema.data import Data

import os

if TYPE_CHECKING:
    from lfx.schema.dataframe import DataFrame



class AXVectorStoreComponent(LCVectorStoreComponent):
    """Chroma Vector Store from Data Catalog with search capabilities."""

    display_name: str = "AX Studio Vector DB"
    description: str = "Chroma Vector Store from AX Studio with search capabilities"
    name = "AX Studio Vector DB"
    icon = "Chroma"

    inputs = [
        DropdownInput(
            name="database_name",
            display_name="Upload Session Name",
            info="Select the database from your configured data assets",
            options=[],
            value="",
            refresh_button=True,
            real_time_refresh=True,
        ),
        StrInput(
            name="collection_name",
            display_name="Collection Name",
            value="",
        ),
        StrInput(
            name="database",
            display_name="Database",
            advanced=True,
            value=os.getenv("SELFHOST_CHROMA_DATABASE_NAME") or "",
        ),


        StrInput(
            name="persist_directory",
            display_name="Persist Directory",
            advanced=True,
        ),
        *LCVectorStoreComponent.inputs,
        HandleInput(name="embedding", display_name="Embedding", input_types=["Embeddings"]),
        BoolInput(
            name="allow_duplicates",
            display_name="Allow Duplicates",
            advanced=True,
            info="If false, will not add documents that are already in the Vector Store.",
        ),
        DropdownInput(
            name="search_type",
            display_name="Search Type",
            options=["Similarity", "MMR"],
            value="Similarity",
            advanced=True,
        ),
        IntInput(
            name="number_of_results",
            display_name="Number of Results",
            info="Number of results to return.",
            advanced=True,
            value=10,
        ),
        IntInput(
            name="limit",
            display_name="Limit",
            advanced=True,
            info="Limit the number of records to compare when Allow Duplicates is False.",
        ),
    ]

    '''BEGIN SAME LOGIC'''
    
    def _add_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Record that the current flow occupies (uses) a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import add_new_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await add_new_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error recording occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def _remove_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Remove the record of the current flow occupying a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import remove_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await remove_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error removing occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def update_build_config(self, build_config: dict, field_value: Any, field_name: str | None = None) -> dict:
        """Update build configuration - MUST be synchronous."""
        # Load data_asset when refresh button is clicked or component is initialized
        if field_name in {"database_name", None}:
            data_asset = self._load_data_asset_sync()
            self._data_asset_cache = data_asset
            build_config["database_name"]["options"] = [ds["name"] for ds in data_asset]
            build_config["database_name"]["options_metadata"] = [{"created_by": ds["created_by"]} for ds in data_asset]
            print(f"[chromaselfhost] options_metadata set: {build_config['database_name']['options_metadata']}")
        
        # When a database is selected, load its connection URL
        if field_name == "database_name" and field_value:
            if self._data_asset_cache:
                selected = next((ds for ds in self._data_asset_cache if ds["name"] == field_value), None)
                if selected:
                    from langflow.services.database.models.resource_permission.constants import ResourceTypes
                    self._add_occupied_resource_sync(str(selected["id"]), ResourceTypes.SELF_HOSTED_VDB)
                    build_config["collection_name"]["value"] = selected["collection_name"]
        
        return build_config
    
    def _load_data_asset_sync(self) -> list[dict]:
        """Synchronously load data_asset using asyncio.run."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.vdb_upload_history import get_vdb_upload_history_list
        from langflow.services.database.models.user.crud import get_user_by_id
        from langflow.services.database.models.vdb_upload_history.constants import VdbUploadStatus
        
        async def _load():
            try:
                async with session_scope() as db:
                    if not self.user_id:
                        print("User ID is not available")
                        return []
                    
                    current_user = await get_user_by_id(db, self.user_id)
                    if not current_user or not current_user.user_groups:
                        print("User or user groups not found")
                        return []
                    
                    user_group_id = current_user.user_groups[0].group_id
                    all_data_asset, _ = await get_vdb_upload_history_list(
                        db,
                        filter_by={
                            "group_id": user_group_id,
                        },
                        page_size=1000,
                        user_id=self.user_id,
                        filter_by_permission=True,
                    )
                    seen_names = set()
                    result = []
                    for da in all_data_asset:
                        if da.name not in seen_names:
                            seen_names.add(da.name)
                            result.append({"name": da.name, "id": da.id, "collection_name": da.collection_name, "type": "chroma", "created_by": da.created_by})
                    return result
            except Exception as e:
                print(f"Error loading data_asset: {e}")
                return []
        
        try:
            return asyncio.run(_load())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")
            return []

    '''END SAME LOGIC'''

    @override
    @check_cached_vector_store
    def build_vector_store(self) -> Chroma:
        """Builds the Chroma object."""
        try:
            from chromadb import Client, CloudClient, HttpClient
            from langchain_chroma import Chroma
        except ImportError as e:
            msg = "Could not import Chroma integration package. Please install it with `pip install langchain-chroma`."
            raise ImportError(msg) from e
        # Chroma settings
        chroma_settings = None
        client = None
        import chromadb
        host = os.getenv("SELFHOST_CHROMA_HOST", None)
        if host:
            client = chromadb.HttpClient(
                host=host,
                port=int(os.getenv("SELFHOST_CHROMA_PORT", "8000")),
                settings=chromadb.config.Settings(
                    chroma_client_auth_provider="chromadb.auth.token_authn.TokenAuthClientProvider",
                    chroma_client_auth_credentials=os.getenv("SELFHOST_CHROMA_API_KEY") or "_",
                    chroma_auth_token_transport_header="Authorization",
                ),
            )
        else:
            raise Exception()

        # Check persist_directory and expand it if it is a relative path
        persist_directory = self.resolve_path(self.persist_directory) if self.persist_directory is not None else None

        chroma = Chroma(
            persist_directory=persist_directory,
            client=client,
            embedding_function=self.embedding,
            collection_name=self.collection_name,
        )

        self._add_documents_to_vector_store(chroma)
        limit = int(self.limit) if self.limit is not None and str(self.limit).strip() else None
        self.status = chroma_collection_to_data(chroma.get(limit=limit))
        return chroma

    def _add_documents_to_vector_store(self, vector_store: "Chroma") -> None:
        """Adds documents to the Vector Store."""
        ingest_data: list | Data | DataFrame = self.ingest_data
        if not ingest_data:
            self.status = ""
            return

        # Convert DataFrame to Data if needed using parent's method
        ingest_data = self._prepare_ingest_data()

        stored_documents_without_id = []
        if self.allow_duplicates:
            stored_data = []
        else:
            limit = int(self.limit) if self.limit is not None and str(self.limit).strip() else None
            stored_data = chroma_collection_to_data(vector_store.get(limit=limit))
            for value in deepcopy(stored_data):
                del value.id
                stored_documents_without_id.append(value)

        documents = []
        for _input in ingest_data or []:
            if isinstance(_input, Data):
                if _input not in stored_documents_without_id:
                    documents.append(_input.to_lc_document())
            else:
                msg = "Vector Store Inputs must be Data objects."
                raise TypeError(msg)

        if documents and self.embedding is not None:
            self.log(f"Adding {len(documents)} documents to the Vector Store.")
            # Filter complex metadata to prevent ChromaDB errors
            try:
                from langchain_community.vectorstores.utils import filter_complex_metadata

                filtered_documents = filter_complex_metadata(documents)
                vector_store.add_documents(filtered_documents)
            except ImportError:
                self.log("Warning: Could not import filter_complex_metadata. Adding documents without filtering.")
                vector_store.add_documents(documents)
        else:
            self.log("No documents to add to the Vector Store.")
