from typing import Any
from pathlib import Path
from lfx.custom import Component  
from lfx.io import DropdownInput, Output, BoolInput
from lfx.schema.message import Message
from lfx.schema import Data
from lfx.utils.image import create_data_url
import mimetypes
  
class S3FileReaderComponent(Component):  
    display_name = "S3 File Reader"  
    description = "Reads files from S3 (text, images, and other binary files)"  
    icon = "file-text"  
    name = "S3FileReader"

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._datasources_cache = None
        self._aws_access_key_id = None
        self._aws_secret_access_key = None
        self._aws_region = None
        self._schema_stored_value = None
      
    inputs = [  
        DropdownInput(
            name="datasource_name",
            display_name="S3 Data Asset",
            info="Select the S3 data asset from your data catalog",
            options=[],
            value="",
            refresh_button=True,
            real_time_refresh=True,
        ),
        DropdownInput(
            name="bucket_name",
            display_name="S3 Bucket Name",
            info="Select the S3 bucket",
            options=[],
            value="",
            required=True,
            real_time_refresh=True,
        ),
        DropdownInput(
            name="file_key",
            display_name="File Key",
            info="Select the file from the bucket",
            options=[],
            value="",
            required=True,
        ),
        BoolInput(
            name="as_data_url",
            display_name="Return as Data URL",
            info="If True, binary files (images, etc.) will be returned as data URLs. If False, text content will be returned.",
            value=False,
            advanced=True,
        ),
    ]  
      
    outputs = [  
        Output(display_name="File Content", name="file_content", method="read_s3_file"),  
    ]

    def _load_datasources_sync(self) -> list[dict]:
        """Synchronously load S3 datasources using asyncio.run."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.datasource import get_data_asset_list
        from langflow.services.database.models.datasource.constants import DataAssetType
        from langflow.services.database.models.user.crud import get_user_by_id
        
        async def _load():
            try:
                async with session_scope() as db:
                    if not self.user_id:
                        print("User ID is not available")
                        return []
                    
                    current_user = await get_user_by_id(db, self.user_id)
                    if not current_user or not current_user.user_groups:
                        print("User or user groups not found")
                        return []
                    
                    user_group_id = current_user.user_groups[0].group_id
                    all_data_asset, _ = await get_data_asset_list(
                        db, 
                        filter_by={
                            "group_id": user_group_id,
                            "datasource_type": DataAssetType.S3,
                        },
                        page_size=1000,
                        user_id=self.user_id,
                        filter_by_permission=True,
                    )
                    data_assets = [
                        {"name": ds.name, "id": ds.id, "type": ds.datasource_type}
                        for ds in all_data_asset
                    ]
                    return data_assets
            except Exception as e:
                print(f"Error loading data_assets: {e}")
                return []
        
        try:
            return asyncio.run(_load())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")
            return []

    def _get_s3_credentials_sync(self, datasource_id: str) -> dict:
        """Synchronously get S3 credentials for a datasource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.datasource_s3 import get_datasource_s3_by_datasource_id
        
        async def _load():
            try:
                async with session_scope() as db:
                    s3_config = await get_datasource_s3_by_datasource_id(db, datasource_id)
                    if not s3_config:
                        return {}
                    
                    return {
                        "region": s3_config.aws_s3_region,
                        "access_key": s3_config.aws_s3_public_key,
                        "secret_key": s3_config.aws_s3_secret_key,
                        "schema": s3_config.schema_stored_value,
                    }
            except Exception as e:
                print(f"Error loading S3 credentials: {e}")
                return {}
        
        try:
            return asyncio.run(_load())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")
            return {}

    def _extract_buckets_from_schema(self, schema: dict) -> list[str]:
        """Extract bucket names from schema_stored_value."""
        try:
            if not schema:
                return []
            return list(schema.keys())
        except Exception as e:
            print(f"Error extracting buckets from schema: {e}")
            return []

    def _extract_files_from_bucket(self, schema: dict, bucket_name: str) -> list[str]:
        """Extract all file paths from a bucket in the schema."""
        try:
            if not schema or bucket_name not in schema:
                return []
            
            files = []
            bucket_data = schema[bucket_name]
            
            def traverse_structure(obj, path=""):
                """Recursively traverse the structure to find all files."""
                if isinstance(obj, dict):
                    if "__content" in obj:
                        # Found files at this level
                        for file in obj["__content"]:
                            full_path = f"{path}/{file}" if path else file
                            files.append(full_path)
                    # Continue traversing other keys
                    for key, value in obj.items():
                        if key != "__content":
                            new_path = f"{path}/{key}" if path else key
                            traverse_structure(value, new_path)
            
            traverse_structure(bucket_data)
            return sorted(files)
        except Exception as e:
            print(f"Error extracting files from bucket: {e}")
            return []

    def _add_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Record that the current flow occupies (uses) a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import add_new_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await add_new_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error recording occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def _remove_occupied_resource_sync(self, resource_id: str, resource_type) -> None:
        """Remove the record of the current flow occupying a resource."""
        import asyncio
        from lfx.services.deps import session_scope
        from langflow.services.database.models.occupied_resource.crud import remove_occupied_resource

        flow_id = getattr(getattr(self, "graph", None), "flow_id", None)
        if flow_id is not None:
            flow_id = str(flow_id)
        component_id = getattr(self, "_id", None)

        async def _run():
            try:
                async with session_scope() as db:
                    await remove_occupied_resource(db, resource_id, resource_type, flow_id, component_id)
            except Exception as e:
                print(f"Error removing occupied resource: {e}")

        try:
            asyncio.run(_run())
        except Exception as e:
            print(f"Error in sync wrapper: {e}")

    def update_build_config(self, build_config: dict, field_value: Any, field_name: str | None = None) -> dict:
        """Update build configuration - MUST be synchronous."""
        # Initialize hidden field for schema storage if it doesn't exist
        if "_schema_data" not in build_config:
            build_config["_schema_data"] = {"value": None}
        if "_credentials_data" not in build_config:
            build_config["_credentials_data"] = {"value": {}}
        
        # Load datasources when refresh button is clicked or component is initialized
        if field_name in {"datasource_name", None}:
            datasources = self._load_datasources_sync()
            self._datasources_cache = datasources
            build_config["datasource_name"]["options"] = [ds["name"] for ds in datasources]
        
        # When a datasource is selected, load its credentials and bucket list
        if field_name == "datasource_name" and field_value:
            if self._datasources_cache:
                selected = next((ds for ds in self._datasources_cache if ds["name"] == field_value), None)
                if selected:
                    from langflow.services.database.models.resource_permission.constants import ResourceTypes
                    self._add_occupied_resource_sync(str(selected["id"]), ResourceTypes.DATABASE)
                    # Load the S3 credentials and store them internally
                    credentials = self._get_s3_credentials_sync(selected["id"])
                    if credentials:
                        # Store in both instance variables AND build_config
                        self._aws_region = credentials.get("region", "")
                        self._aws_access_key_id = credentials.get("access_key", "")
                        self._aws_secret_access_key = credentials.get("secret_key", "")
                        self._schema_stored_value = credentials.get("schema")
                        
                        # IMPORTANT: Persist in build_config so it survives across instances
                        build_config["_schema_data"]["value"] = credentials.get("schema")
                        build_config["_credentials_data"]["value"] = {
                            "region": credentials.get("region", ""),
                            "access_key": credentials.get("access_key", ""),
                            "secret_key": credentials.get("secret_key", ""),
                        }
                                                
                        # Update bucket options
                        buckets = self._extract_buckets_from_schema(self._schema_stored_value)
                        build_config["bucket_name"]["options"] = buckets
                        build_config["bucket_name"]["value"] = ""
                        
                        # Reset file options when datasource changes
                        build_config["file_key"]["options"] = []
                        build_config["file_key"]["value"] = ""
        
        # When a bucket is selected, load its file list
        # Restore schema from build_config if not in instance
        if not self._schema_stored_value and build_config.get("_schema_data", {}).get("value"):
            self._schema_stored_value = build_config["_schema_data"]["value"]
        
        # Also restore credentials if needed
        if not self._aws_access_key_id and build_config.get("_credentials_data", {}).get("value"):
            creds = build_config["_credentials_data"]["value"]
            self._aws_region = creds.get("region", "")
            self._aws_access_key_id = creds.get("access_key", "")
            self._aws_secret_access_key = creds.get("secret_key", "")
        
        current_bucket = None
        if field_name == "bucket_name" and field_value:
            current_bucket = field_value
        elif "bucket_name" in build_config and build_config["bucket_name"].get("value"):
            # Fallback: if field_name is wrong but we have a bucket value, use it
            current_bucket = build_config["bucket_name"]["value"]
        
        if current_bucket:
            if self._schema_stored_value:
                files = self._extract_files_from_bucket(self._schema_stored_value, current_bucket)
                build_config["file_key"]["options"] = files
                if field_name == "bucket_name":
                    # Only reset value if we're explicitly changing the bucket
                    build_config["file_key"]["value"] = ""
        
        return build_config
      
    def read_s3_file(self) -> Message:  
        """Read file content from S3 and return as text."""
        
        try:  
            import boto3  
        except ImportError as e:  
            msg = "boto3 is not installed. Please install it using `uv pip install boto3`."  
            raise ImportError(msg) from e  
  
        # Validate all required inputs
        datasource = getattr(self, 'datasource_name', None)
        bucket = getattr(self, 'bucket_name', None)
        file = getattr(self, 'file_key', None)
        
        print(f"Validation - datasource: {datasource}, bucket: {bucket}, file: {file}")
        
        if not datasource:
            msg = "Error: Please select an S3 datasource."
            print(msg)
            return Message(text=msg)
        
        if not bucket:
            msg = "Error: Please select an S3 bucket."
            print(msg)
            return Message(text=msg)
        
        if not file:
            msg = "Error: Please select a file."
            print(msg)
            return Message(text=msg)
        
        # Load credentials from database
        try:
            # Find the datasource by name
            datasources = self._load_datasources_sync()
            selected_datasource = next((ds for ds in datasources if ds["name"] == datasource), None)
            
            if not selected_datasource:
                msg = f"Error: Datasource '{datasource}' not found."
                print(msg)
                return Message(text=msg)
            
            # Get S3 credentials
            credentials = self._get_s3_credentials_sync(selected_datasource["id"])
            
            if not credentials or not credentials.get("access_key") or not credentials.get("secret_key"):
                msg = "Error: Failed to load AWS credentials from datasource."
                print(msg)
                return Message(text=msg)
            
            aws_access_key_id = credentials.get("access_key")
            aws_secret_access_key = credentials.get("secret_key")
            aws_region = credentials.get("region", "")
            
        except Exception as e:
            msg = f"Error loading credentials: {str(e)}"
            print(msg)
            import traceback
            traceback.print_exc()
            return Message(text=msg)

        # Create S3 client  
        client_config = {  
            "aws_access_key_id": aws_access_key_id,  
            "aws_secret_access_key": aws_secret_access_key,  
        }  
          
        if aws_region:  
            client_config["region_name"] = aws_region  
          
        s3_client = boto3.client("s3", **client_config)
          
        # Download file from S3  
        try:
            response = s3_client.get_object(Bucket=bucket, Key=file)
            
            # Get file content as bytes
            file_bytes = response['Body'].read()
            
            # Detect MIME type from file extension
            mime_type = mimetypes.guess_type(file)[0]
            
            # Check if it's an image or binary file based on MIME type
            is_image = mime_type and mime_type.startswith('image/')
            is_binary = mime_type and not mime_type.startswith('text/')
            
            # If user wants data URL or it's an image, return as Data with data URL
            if self.as_data_url or is_image:
                import base64
                import tempfile
                
                # Save to temporary file to use create_data_url utility
                with tempfile.NamedTemporaryFile(suffix=Path(file).suffix, delete=False) as tmp_file:
                    tmp_file.write(file_bytes)
                    tmp_path = tmp_file.name
                
                try:
                    # Create data URL (base64 encoded with MIME type)
                    data_url = create_data_url(tmp_path, mime_type)
                    
                    # Return as Data with the data URL
                    result = Data(data={
                        "file_path": file,
                        "mime_type": mime_type,
                        "data_url": data_url,
                        "text": f"File: {file} (Type: {mime_type})"
                    })
                    return result
                finally:
                    # Clean up temp file
                    import os
                    try:
                        os.unlink(tmp_path)
                    except Exception:
                        pass
            else:
                # Return as text
                try:
                    file_content = file_bytes.decode('utf-8')
                    result = Message(text=file_content)
                    return result
                except UnicodeDecodeError:
                    # If it fails to decode as text, return error message
                    msg = f"Error: File '{file}' appears to be binary. Enable 'Return as Data URL' option to view binary files."
                    print(msg)
                    return Message(text=msg)
                    
        except Exception as e:
            msg = f"Error reading file from S3: {str(e)}"
            print(msg)
            import traceback
            traceback.print_exc()
            return Message(text=msg)