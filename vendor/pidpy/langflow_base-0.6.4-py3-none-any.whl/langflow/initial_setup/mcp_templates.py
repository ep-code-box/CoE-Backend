"""MCP template initialization for the database."""

from sqlalchemy import delete
from sqlmodel.ext.asyncio.session import AsyncSession

from lfx.log.logger import logger

# Use upsert to avoid recreating templates (preserve IDs for stable links)
from langflow.services.database.models.mcp_template.models import MCPServerTemplateCreate
from langflow.services.database.models.mcp_template.crud import upsert_mcp_server_template
from langflow.services.deps import session_scope


MCP_TEMPLATE_LIST = [
    {
        "name": "GitHub",
        "description": "GitHub API 연결 및 리포지토리 관리, 이슈/PR 처리",
        "version": "0.21.0",
        "provider": "GitHub, Inc.",
        "type": "EXTERNAL_SSE",
        "config": {
            "url": "https://api.githubcopilot.com/mcp/",
            "headers": {
                "Authorization": "Bearer ${ACCESS_TOKEN}"
            },
        },
        "more_info": {
            "주요 기능": [
                "리포지토리 조회 및 검색",
                "이슈/PR 생성 및 관리",
                "코드 검색 및 분석",
                "워크플로우 자동화",
                "팀 협업 기능",
            ],
            "활용 사례": [
                "자동화된 이슈 트래킹 및 관리",
                "코드 리뷰 프로세스 최적화",
                "릴리즈 노트 자동 생성",
                "팀 활동 모니터링",
            ],
            "기술적 특징": [
                "실시간 동기화\nGitHub와 실시간으로 데이터를 동기화합니다",
                "안전한 인증\nOAuth 2.0을 통한 안전한 인증을 지원합니다",
                "API 제한 관리\nGitHub API 제한을 자동으로 관리합니다",
            ],
            "연결 안내": [
                "이 MCP는 AX Studio에서 제공하는 검증된 서버입니다. \"연결하기\" 버튼을 클릭하면 필요한 설정을 진행할 수 있습니다.",
                "연결 후 즉시 사용 가능합니다",
                "보안이 검증된 안전한 연결입니다",
            ],
        }
    },
    {
        "name": "Notion MCP",
        "description": "Connect your AI tools to Notion using the Model Context Protocol (MCP), an open standard that lets AI assistants interact with your Notion workspace.",
        "version": "",
        "provider": "Notion Labs, Inc.",
        "type": "EXTERNAL_STDIO",
        "config":  {
            "command": "npx",
            "args": [
                "-y",
                "@notionhq/notion-mcp-server"
            ],
            "env": {
                "NOTION_TOKEN": "ntn_****",
            }
        },
        "more_info": {
            "주요 기능": [
                "기본 연결 기능",
                "데이터 조회",
                "기본 CRUD 작업",
            ],
            "활용 사례": [
                "데이터 통합",
                "자동화 워크플로우",
            ],
            "기술적 특징": [
                "안정성\n안정적인 연결 및 에러 처리",
                "확장성\n다양한 사용 사례에 대응",
            ],
            "연결 안내": [
                "이 MCP는 AX Studio에서 제공하는 검증된 서버입니다. \"연결하기\" 버튼을 클릭하면 필요한 설정을 진행할 수 있습니다.",
                "연결 후 즉시 사용 가능합니다",
                "보안이 검증된 안전한 연결입니다",
            ],
        }
    },
    {
        "name": "Alpha Vantage",
        "description": "Connect your AI tools to Alpha Vantage financial market data using the Model Context Protocol (MCP), enabling AI assistants to access real-time and historical stock, forex, and cryptocurrency data.",
        "version": "",
        "provider": "Alpha Vantage Inc.",
        "type": "EXTERNAL_SSE",
        "config": {
            "url": "https://mcp.alphavantage.co/mcp?apikey=YOUR_API_KEY",
        },
        "more_info": {
            "주요 기능": [
                "주식 시세 조회",
                "외환 환율 데이터",
                "암호화폐 시세",
                "기술적 지표 분석",
                "재무제표 데이터",
            ],
            "활용 사례": [
                "실시간 금융 데이터 분석",
                "자동화된 투자 리서치",
                "시장 트렌드 모니터링",
                "포트폴리오 데이터 통합",
            ],
            "기술적 특징": [
                "실시간 데이터\n주식, 외환, 암호화폐 실시간 시세를 제공합니다",
                "다양한 지표\n50개 이상의 기술적 지표를 지원합니다",
                "역사적 데이터\n장기 역사적 시계열 데이터를 조회할 수 있습니다",
            ],
            "연결 안내": [
                "이 MCP는 AX Studio에서 제공하는 검증된 서버입니다. \"연결하기\" 버튼을 클릭하면 필요한 설정을 진행할 수 있습니다.",
                "Alpha Vantage API 키를 URL의 YOUR_API_KEY 부분에 입력하세요",
                "보안이 검증된 안전한 연결입니다",
            ],
        }
    },
]

async def initialize_mcp_templates(session: AsyncSession) -> None:
    """Initialize or update MCP server templates from the predefined list.
    
    This function upserts all templates from MCP_TEMPLATE_LIST into the database.
    It's safe to run multiple times as it will update existing templates.
    
    Args:
        session: Database session
    """
    try:
        # Upsert templates so that template IDs remain stable across restarts
        successfully_loaded = 0
        for template_data in MCP_TEMPLATE_LIST:
            try:
                template_create = MCPServerTemplateCreate(**template_data)
                await upsert_mcp_server_template(session, template_create)
                successfully_loaded += 1
            except Exception as e:
                await logger.aexception(
                    f"Error loading template '{template_data.get('name', 'unknown')}': {e}"
                )

        await logger.adebug(f"Successfully loaded/updated {successfully_loaded} MCP server templates")
    except Exception as e:
        await logger.aexception(f"Error initializing MCP templates: {e}")


async def load_mcp_templates() -> None:
    """Load MCP server templates into the database.
    
    This is a convenience function that creates a session and calls initialize_mcp_templates.
    """
    async with session_scope() as session:
        await initialize_mcp_templates(session)
