# Router for base api
from fastapi import APIRouter

from langflow.api.v1 import (
    api_key_router,
    chat_router,
    endpoints_router,
    files_router,
    flows_router,
    folders_router,
    knowledge_bases_router,
    login_router,
    mcp_projects_router,
    mcp_router as mcp_router_v1,
    monitor_router,
    openai_responses_router,
    projects_router,
    starter_projects_router,
    store_router,
    users_router,
    validate_router,
    variables_router,
)
from langflow.api.v1.voice_mode import router as voice_mode_router
from langflow.api.v2 import files_router as files_router_v2
from langflow.api.v2 import mcp_router as mcp_router_v2
from langflow.api.ax_studio import mcp_router
from langflow.api.ax_studio import mcp_tools_router
from langflow.api.ax_studio import mcp_server_history_router
from langflow.api.ax_studio import user_group_router
from langflow.api.ax_studio import user_role_router
from langflow.api.ax_studio import group_router
from langflow.api.ax_studio import datasource_router
from langflow.api.ax_studio import datasource_rdb_router
from langflow.api.ax_studio import datasource_s3_router
from langflow.api.ax_studio import data_asset_vdb_router
from langflow.api.ax_studio import agent_flow_router
from langflow.api.ax_studio import agent_flow_history_router
from langflow.api.ax_studio import datasource_history_router
from langflow.api.ax_studio import vdb_upload_action_history_router
from langflow.api.ax_studio import masterdata_router
from langflow.api.ax_studio import resource_permission_router
from langflow.api.ax_studio import rag_upload_router
from langflow.api.ax_studio import reports_router
from langflow.api.ax_studio import recent_activity_router
from langflow.api.ax_studio import faq_router
from langflow.api.ax_studio import guide_router
from langflow.api.ax_studio import occupied_resource_router

router_v1 = APIRouter(
    prefix="/v1",
)

router_v2 = APIRouter(
    prefix="/v2",
)

router_v1.include_router(chat_router)
router_v1.include_router(endpoints_router)
router_v1.include_router(validate_router)
router_v1.include_router(store_router)
router_v1.include_router(flows_router)
router_v1.include_router(users_router)
router_v1.include_router(api_key_router)
router_v1.include_router(login_router)
router_v1.include_router(variables_router)
router_v1.include_router(files_router)
router_v1.include_router(monitor_router)
router_v1.include_router(folders_router)
router_v1.include_router(projects_router)
router_v1.include_router(starter_projects_router)
router_v1.include_router(knowledge_bases_router)
router_v1.include_router(mcp_router_v1)
router_v1.include_router(voice_mode_router)
router_v1.include_router(mcp_projects_router)
router_v1.include_router(openai_responses_router)

router_v2.include_router(files_router_v2)
router_v2.include_router(mcp_router_v2)

router_ax_studio = APIRouter(
    prefix="/ax-studio",
)
router_ax_studio.include_router(mcp_router)
router_ax_studio.include_router(mcp_tools_router)
router_ax_studio.include_router(mcp_server_history_router)
router_ax_studio.include_router(user_group_router)
router_ax_studio.include_router(user_role_router)
router_ax_studio.include_router(group_router)
router_ax_studio.include_router(datasource_router)
router_ax_studio.include_router(datasource_rdb_router)
router_ax_studio.include_router(datasource_s3_router)
router_ax_studio.include_router(data_asset_vdb_router)
router_ax_studio.include_router(agent_flow_router)
router_ax_studio.include_router(agent_flow_history_router)
router_ax_studio.include_router(datasource_history_router)
router_ax_studio.include_router(vdb_upload_action_history_router)
router_ax_studio.include_router(masterdata_router)
router_ax_studio.include_router(resource_permission_router)
router_ax_studio.include_router(rag_upload_router)
router_ax_studio.include_router(reports_router)
router_ax_studio.include_router(recent_activity_router)
router_ax_studio.include_router(faq_router)
router_ax_studio.include_router(guide_router)
router_ax_studio.include_router(occupied_resource_router)

router = APIRouter(
    prefix="/api",
)
router.include_router(router_v1)
router.include_router(router_v2)
router.include_router(router_ax_studio)
