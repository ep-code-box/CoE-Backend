from uuid import UUID
from botocore.exceptions import ClientError, BotoCoreError
from fastapi import APIRouter, HTTPException
from langflow.api.ax_studio.schemas import FetchMetadataS3Request, DatasourceS3UpdateRequest
from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.services.database.models.datasource_s3 import (
    DatasourceS3,
    DatasourceS3Read,
    get_datasource_s3_by_datasource_id,
    update_datasource_s3,
    s3_perform_connect,
)

router = APIRouter(tags=["DATA_ASSET_S3"], prefix="/datasource_s3")


@router.post("/fetch_metadata")
async def fetch_metadata(
        session: DbSession,
        request: FetchMetadataS3Request,
) -> dict:
    """Get S3 datasource metadata (buckets, folders, and files)."""
    try:
        metadata_obj = {}
        s3_client, region = await s3_perform_connect(session, request.datasource_id, request.connection_config)
        region_bucket_names = [
            bucket["Name"] for bucket in s3_client.list_buckets()["Buckets"] 
            if s3_client.get_bucket_location(Bucket=bucket['Name'])['LocationConstraint'] == region
        ]
        for bucket_name in region_bucket_names:
            metadata_obj[bucket_name] = {}
            response = s3_client.list_objects_v2(Bucket=bucket_name)
            for object in response.get('Contents', []):
                key = object['Key']
                parts = key.split('/')
                
                # Navigate/create nested structure
                current_level = metadata_obj[bucket_name]
                
                # Process each folder in the path
                for i, part in enumerate(parts[:-1]):  # All parts except the last (filename)
                    if part not in current_level:
                        current_level[part] = {}
                    current_level = current_level[part]
                
                # Add the file to the final folder level
                file_name = parts[-1]
                if file_name:  # Only add if not empty (folder markers end with /)
                    if '__content' not in current_level:
                        current_level['__content'] = []
                    current_level['__content'].append(file_name)
        
        return {"detail": metadata_obj}

    except ClientError as e:
        error_code = e.response['Error']['Code']
        error_message = e.response['Error']['Message']
        raise HTTPException(
            status_code=400,
            detail=f"Failed to fetch S3 metadata - {error_code}: {error_message}"
        ) from e
    except BotoCoreError as e:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to fetch S3 metadata - BotoCore error: {str(e)}"
        ) from e
    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to fetch S3 metadata: {str(e)}"
        ) from e


# @router.put("/{datasource_id}", response_model=DatasourceS3Read)
async def update_s3_config(
        datasource_id: UUID,
        request: DatasourceS3UpdateRequest,
        session: DbSession,
        user: CurrentActiveUser,
) -> DatasourceS3:
    """Update S3 configuration for a datasource."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    s3_config = await get_datasource_s3_by_datasource_id(session, datasource_id)
    if not s3_config:
        raise HTTPException(status_code=404, detail="S3 configuration not found")
    
    return await update_datasource_s3(s3_config, request, session)
