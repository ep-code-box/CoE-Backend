from typing import Optional
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy.exc import IntegrityError

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.omnipotent_access_granter_2000 import is_global_admin
from langflow.services.database.models.guide.crud import (
    list_guides_mini_response,
    get_guide_by_id,
    create_guide,
    edit_guide,
    delete_guide,
    rate_guide,
    save_guide,
    bulk_update_guide_order,
)
from langflow.services.database.models.guide.model import (
    GuideCreate,
    GuideUpdate,
    GuideRead,
    GuideListResponse,
    GuideTypeEnum,
)

from .faq import (
    get_helps,
    get_help,
    create_new_help,
    update_help,
    delete_help
)
from .schemas import GuideOrderRequest

router = APIRouter(tags=["Guide"], prefix="/guide")

@router.get("/", response_model=dict)
async def get_helps(
    session: DbSession,
    user: CurrentActiveUser,
    skip: int = Query(0, description="Number of items to skip"),
    limit: int = Query(100, description="Maximum number of items to return"),
    search: Optional[str] = Query(None, description="Search term for title or content"),
    guide_type: Optional[GuideTypeEnum] = Query(None, description="Filter by guide type"),
    is_published: Optional[bool] = Query(None, description="Filter by published status"),
    saved_only: bool = Query(False, description="Show only saved guides"),
    sort_by: Optional[str] = Query("created_at", description="Field to sort by"),
    sort_dir: str = Query("desc", description="Sort direction (asc or desc)"),
) -> dict:
    """
    Retrieve a list of guides with filtering, search, and pagination.
    """
    # Build filter dictionary
    filter_by = {}
    if guide_type:
        filter_by["guide_type"] = guide_type
    if is_published is not None:
        filter_by["is_published"] = is_published
    
    # Determine saved_by parameter
    saved_by = user.id if saved_only else None
    
    # Get guides
    guides, total_count = await list_guides_mini_response(
        db=session,
        filter_by=filter_by,
        sort_by=sort_by,
        sort_dir=sort_dir,
        limit=limit,
        offset=skip,
        search_term=search,
        saved_by=saved_by,
        current_user_id=user.id,
    )
    
    return {
        "guides": guides,
        "total_count": total_count,
        "skip": skip,
        "limit": limit,
    }

# router.get("/")(get_helps)
router.get("/{guide_id}", response_model=GuideRead)(get_help)
router.post("/", response_model=GuideRead)(create_new_help)
router.patch("/{guide_id}", response_model=GuideRead)(update_help)
router.delete("/{guide_id}")(delete_help)


@router.post("/order_guide")
async def order_guide(
    session: DbSession,
    user: CurrentActiveUser,
    request: GuideOrderRequest,
) -> dict:
    """Bulk update guide order."""
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")
    order_updates = [item.model_dump() for item in request.data]
    await bulk_update_guide_order(db=session, order_updates=order_updates, user_id=user.id)
    return {"success": True, "message": "Guide orders updated successfully"}


