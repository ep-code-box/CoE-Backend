import json
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, desc
from sqlmodel import select
from sqlmodel.sql.expression import SelectOfScalar

from langflow.api.utils import DbSession
from langflow.services.database.models.mcp_server_history.model import (
    MCPServerHistory,
    MCPServerHistoryRead,
    MCPServerHistoryResponse,
)
from langflow.services.database.models.user.model import User

router = APIRouter(tags=["MCP_SERVER_HISTORY"], prefix="/mcp_server_history")


@router.get("/{mcp_server_history_id}", response_model=MCPServerHistoryRead)
async def read_mcp_server_history_by_id(
    *,
    mcp_server_history_id: UUID,
    session: DbSession,
) -> MCPServerHistoryRead:
    """Retrieve a single MCP server history record by ID."""
    query: SelectOfScalar = select(MCPServerHistory).where(MCPServerHistory.id == mcp_server_history_id)
    history = (await session.exec(query)).first()

    if history is None:
        raise HTTPException(status_code=404, detail="MCP server history not found")

    history_dict = history.model_dump()
    history_dict["old_values"] = json.loads(history_dict.get("old_values") or "{}")
    history_dict["new_values"] = json.loads(history_dict.get("new_values") or "{}")

    creator_q = select(User).where(User.id == history.create_by)
    creator = (await session.exec(creator_q)).first()
    history_dict["created_by_username"] = creator.username if creator else None

    return MCPServerHistoryRead(**history_dict)


@router.get("/", response_model=MCPServerHistoryResponse)
async def read_all_mcp_server_histories(
    *,
    skip: int = Query(0, description="Number of items to skip"),
    limit: int = Query(10, description="Maximum number of items to return"),
    mcp_server_id: UUID = Query(..., description="MCP Server ID is required"),
    session: DbSession,
) -> MCPServerHistoryResponse:
    """Retrieve paginated history records for a given MCP server."""
    query = select(MCPServerHistory)
    count_query = select(func.count()).select_from(MCPServerHistory)

    where_condition = MCPServerHistory.mcp_server_id == mcp_server_id
    query = query.where(where_condition)
    count_query = count_query.where(where_condition)

    query = query.order_by(desc(MCPServerHistory.create_at))
    query = query.offset(skip).limit(limit)

    histories_raw = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()

    histories = []
    for h in histories_raw:
        h_dict = h.model_dump()
        h_dict["old_values"] = json.loads(h_dict.get("old_values") or "{}")
        h_dict["new_values"] = json.loads(h_dict.get("new_values") or "{}")

        creator_q = select(User).where(User.id == h.create_by)
        creator = (await session.exec(creator_q)).first()
        h_dict["created_by_username"] = creator.username if creator else None

        histories.append(MCPServerHistoryRead(**h_dict))

    return MCPServerHistoryResponse(
        total_count=total_count,
        mcp_server_histories=histories,
    )
