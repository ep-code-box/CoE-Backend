from langflow.api.ax_studio.user_group import router as user_group_router
from langflow.api.ax_studio.user_role import router as user_role_router
from langflow.api.ax_studio.group import router as group_router
from langflow.api.ax_studio.datasource import router as datasource_router
from langflow.api.ax_studio.datasource_rdb import router as datasource_rdb_router
from langflow.api.ax_studio.datasource_s3 import router as datasource_s3_router
from langflow.api.ax_studio.data_asset_vdb import router as data_asset_vdb_router
from langflow.api.ax_studio.agent_flow import router as agent_flow_router
from langflow.api.ax_studio.agent_flow_history import router as agent_flow_history_router
from langflow.api.ax_studio.datasource_history import router as datasource_history_router
from langflow.api.ax_studio.vdb_upload_action_history import router as vdb_upload_action_history_router
from langflow.api.ax_studio.mcp import router as mcp_router
from langflow.api.ax_studio.mcp_tools import router as mcp_tools_router
from langflow.api.ax_studio.mcp_server_history import router as mcp_server_history_router
from langflow.api.ax_studio.masterdata import router as masterdata_router
from langflow.api.ax_studio.resource_permission import router as resource_permission_router
from langflow.api.ax_studio.rag_upload import router as rag_upload_router
from langflow.api.ax_studio.reports import router as reports_router
from langflow.api.ax_studio.recent_activity import router as recent_activity_router
from langflow.api.ax_studio.faq import router as faq_router
from langflow.api.ax_studio.guide import router as guide_router
from langflow.api.ax_studio.occupied_resource import router as occupied_resource_router

__all__ = [
    "user_group_router",
    "user_role_router",
    "group_router",
    "datasource_router",
    "datasource_rdb_router",
    "datasource_s3_router",
    "data_asset_vdb_router",
    "agent_flow_router",
    "agent_flow_history_router",
    "datasource_history_router",
    "vdb_upload_action_history_router",
    "mcp_router",
    "mcp_tools_router",
    "mcp_server_history_router",
    "masterdata_router",
    "resource_permission_router",
    "rag_upload_router",
    "reports_router",
    "recent_activity_router",
    "faq_router",
    "guide_router",
    "occupied_resource_router",
]