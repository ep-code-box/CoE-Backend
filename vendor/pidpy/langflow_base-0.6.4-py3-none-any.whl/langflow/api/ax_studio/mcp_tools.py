
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query
from langflow.services.database.models.user_group.crud import get_one_membership_by_user_id, get_membership_by_user_id_and_group_id
from pydantic import BaseModel, Field
from sqlalchemy.exc import IntegrityError
from langflow.api.utils import CurrentActiveUser, DbSession
from langflow.api.ax_studio.omnipotent_access_granter_2000 import has_permission, PermCheckActionEnum
from langflow.services.database.models.mcp.crud import (
    get_mcp_server_by_id,
    update_mcp_server,
)
from langflow.services.database.models.mcp.models import (
    MCPServerUpdate,
    MCPServerStatusEnum,
    MCPServerTypeEnum,
)
from langflow.services.database.models.mcp_tools.crud import (
    create_mcp_tool,
    delete_mcp_tool,
    get_mcp_tool_by_id,
    get_mcp_tool_list,
    update_mcp_tool,
)
from langflow.services.database.models.mcp_tools.models import (
    HTTPMethod,
    MCPToolCreate,
    MCPToolList,
    MCPToolRead,
    MCPToolUpdate,
    MCPToolStatusEnum,
)
from langflow.services.mcp_hub import MCPHubService
from langflow.services.database.models.recent_activity.crud import add_recent_activity, get_mcp_extra_info
from langflow.services.database.models.recent_activity.model import ActivityItemTypeEnum, ActivityTypeEnum

router = APIRouter(tags=["AX Studio MCP Tools"], prefix="/mcp/tools")


class MCPToolsListResponse(dict):
    """Response model for MCP tools list with pagination."""

    tools: list[MCPToolList]
    total: int
    page: int
    page_size: int


@router.get("", response_model=dict)
async def get_tools(
    current_user: CurrentActiveUser,
    session: DbSession,
    sort_by: str = Query(default="created_at", description="Field to sort by"),
    sort_direction: str = Query(default="desc", description="Sort direction (asc or desc)"),
    status: MCPToolStatusEnum | None = Query(
        default=None,
        description="Filter by status. Available values: PENDING, REJECTED, ACTIVE"
    ),
    http_method: HTTPMethod | None = Query(
        default=None,
        description="Filter by HTTP method. Available values: GET, POST, PUT, PATCH, DELETE"
    ),
    name: str | None = Query(default=None, description="Filter by name (partial match)"),
    mcp_server_id: UUID | None = Query(default=None, description="Filter by MCP Server ID"),
    page: int = Query(default=1, ge=1, description="Page number"),
    page_size: int = Query(default=10, ge=1, le=100, description="Items per page"),
):
    """Get the list of available MCP tools with pagination, sorting, and filtering.
    
    **Status values:**
    - `PENDING`: Tool is pending approval
    - `REJECTED`: Tool has been rejected
    - `ACTIVE`: Tool is active and available
    
    **HTTP Method values:**
    - `GET`: HTTP GET method
    - `POST`: HTTP POST method
    - `PUT`: HTTP PUT method
    - `PATCH`: HTTP PATCH method
    - `DELETE`: HTTP DELETE method
    """
    try:
        # Build filter dictionary
        filter_by = {}
        if status is not None:
            filter_by["status"] = status.value
        if http_method is not None:
            filter_by["http_method"] = http_method.value
        if name is not None:
            filter_by["name"] = name
        if mcp_server_id is not None:
            filter_by["mcp_server_id"] = mcp_server_id

        tools, total = await get_mcp_tool_list(
            session=session,
            sort_by=sort_by,
            sort_direction=sort_direction,
            filter_by=filter_by if filter_by else None,
            page=page,
            page_size=page_size,
        )

        return {
            "tools": tools,
            "total": total,
            "page": page,
            "page_size": page_size,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("", status_code=201, response_model=MCPToolRead)
async def create_tool(
    req: MCPToolCreate,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Create a new MCP tool.
    
    **HTTP Method values:**
    - `GET`: HTTP GET method
    - `POST`: HTTP POST method
    - `PUT`: HTTP PUT method
    - `PATCH`: HTTP PATCH method
    - `DELETE`: HTTP DELETE method
    
    **Note:** Status is automatically set to `PENDING` upon creation.
    
    **Example request:**
    ```json
    {
        "name": "Get User Info",
        "description": "Retrieve user information by ID",
        "http_method": "GET",
        "path_template": "/api/users/{user_id}",
        "input_schema": {
            "type": "object",
            "properties": {
                "user_id": {"type": "string"}
            },
            "required": ["user_id"]
        },
        "path_mapping": {"user_id": "user_id"},
        "query_mapping": {},
        "headers_mapping": {"Authorization": "auth_token"},
        "body_mapping": {},
        "raw_body_key": null,
        "response_mapping": "$.data",
        "mcp_server_id": "123e4567-e89b-12d3-a456-426614174000"
    }
    ```
    """
    mcp_hub_service = MCPHubService()
    try:
        # Check permissions against the parent MCP server
        mcp_server_for_perm = await get_mcp_server_by_id(session=session, mcp_server_id=req.mcp_server_id)
        if mcp_server_for_perm is None:
            raise HTTPException(status_code=404, detail="MCP Server not found")
        membership = await get_membership_by_user_id_and_group_id(session, current_user.id, mcp_server_for_perm.group_id)
        if not await has_permission(resource=mcp_server_for_perm, action=PermCheckActionEnum.CREATE, user=current_user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied")

        # Create the MCP tool in the database
        mcp_tool = await create_mcp_tool(
            session=session,
            mcp_tool_create=req,
            user_id=current_user.id,
        )

        # Set MCP server status to PENDING when creating a tool
        await update_mcp_server(
            session=session,
            mcp_server_id=req.mcp_server_id,
            mcp_server_update=MCPServerUpdate(status=MCPServerStatusEnum.PENDING),
            user_id=current_user.id,
        )

        # Sync to MCP Hub if server is SELF_HOSTED
        if mcp_server_for_perm.type == MCPServerTypeEnum.SELF_HOSTED:
            mcp_server_name = str(mcp_server_for_perm.id)
            tool_create_hub = MCPToolCreate(
                name=mcp_tool.name,
                description=mcp_tool.description,
                http_method=mcp_tool.http_method,
                path_template=mcp_tool.path_template,
                input_schema=mcp_tool.input_schema,
                path_mapping=mcp_tool.path_mapping,
                query_mapping=mcp_tool.query_mapping,
                headers_mapping=mcp_tool.headers_mapping,
                body_mapping=mcp_tool.body_mapping,
                raw_body_key=mcp_tool.raw_body_key,
                response_mapping=mcp_tool.response_mapping,
                mcp_server_id=mcp_tool.mcp_server_id,
            )
            await mcp_hub_service.create_or_update_mcp_tool(tool_create_hub, mcp_server_name)

        await add_recent_activity(
            session=session,
            user_id=current_user.id,
            activity_type=ActivityTypeEnum.UPDATED,
            item_id=mcp_server_for_perm.id,
            item_type=ActivityItemTypeEnum.MCP,
            title=f"{mcp_server_for_perm.name}",
            description=f"{mcp_server_for_perm.description or ''}",
            extra_info=get_mcp_extra_info(mcp_server_for_perm),
        )

        return mcp_tool
    except HTTPException:
        raise
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail="MCP tool with this name already exists.") from e
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()


@router.get("/{mcp_tool_id}", response_model=MCPToolRead)
async def get_tool(
    mcp_tool_id: UUID,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Get a specific MCP tool by ID."""
    try:
        mcp_tool = await get_mcp_tool_by_id(
            session=session,
            mcp_tool_id=mcp_tool_id,
        )
        if mcp_tool is None:
            raise HTTPException(status_code=404, detail="MCP Tool not found")
        
        return MCPToolRead.model_validate(mcp_tool, from_attributes=True)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.put("/{mcp_tool_id}", response_model=MCPToolRead)
async def update_tool(
    mcp_tool_id: UUID,
    req: MCPToolUpdate,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Update an existing MCP tool.
    
    **Status values:**
    - `PENDING`: Tool is pending approval
    - `REJECTED`: Tool has been rejected
    - `ACTIVE`: Tool is active and available
    
    **Note:** Only the fields provided in the request will be updated. Status will be reset to PENDING.
    """
    mcp_hub_service = MCPHubService()
    try:
        # Get the existing tool
        existing_tool = await get_mcp_tool_by_id(
            session=session,
            mcp_tool_id=mcp_tool_id,
        )
        if existing_tool is None:
            raise HTTPException(status_code=404, detail="MCP Tool not found")

        mcp_server_for_perm = await get_mcp_server_by_id(session=session, mcp_server_id=existing_tool.mcp_server_id)
        membership = await get_membership_by_user_id_and_group_id(session, current_user.id, mcp_server_for_perm.group_id)
        if not await has_permission(resource=mcp_server_for_perm, action=PermCheckActionEnum.WRITE, user=current_user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied")

        # Capture old name before any update mutates the ORM object
        old_tool_name = existing_tool.name

        # Set MCP server status to PENDING on update
        await update_mcp_server(
            session=session,
            mcp_server_id=existing_tool.mcp_server_id,
            mcp_server_update=MCPServerUpdate(status=MCPServerStatusEnum.PENDING),
            user_id=current_user.id,
        )

        # Update the MCP tool in the database
        mcp_tool = await update_mcp_tool(
            session=session,
            mcp_tool_id=mcp_tool_id,
            mcp_tool_update=req,
            user_id=current_user.id,
        )

        # Sync to MCP Hub if server is SELF_HOSTED
        if mcp_server_for_perm and mcp_server_for_perm.type == MCPServerTypeEnum.SELF_HOSTED:
            mcp_server_name = str(mcp_server_for_perm.id)
            tool_create_hub = MCPToolCreate(
                name=mcp_tool.name,
                description=mcp_tool.description,
                http_method=mcp_tool.http_method,
                path_template=mcp_tool.path_template,
                input_schema=mcp_tool.input_schema,
                path_mapping=mcp_tool.path_mapping,
                query_mapping=mcp_tool.query_mapping,
                headers_mapping=mcp_tool.headers_mapping,
                body_mapping=mcp_tool.body_mapping,
                raw_body_key=mcp_tool.raw_body_key,
                response_mapping=mcp_tool.response_mapping,
                mcp_server_id=mcp_tool.mcp_server_id,
            )
            await mcp_hub_service.delete_mcp_tool(mcp_server_name, old_tool_name)
            await mcp_hub_service.create_or_update_mcp_tool(tool_create_hub, mcp_server_name)

        return mcp_tool
    except HTTPException:
        raise
    except ValueError as e:
        await session.rollback()
        raise HTTPException(status_code=404, detail=str(e)) from e
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()


@router.delete("/{mcp_tool_id}", status_code=204)
async def delete_tool(
    mcp_tool_id: UUID,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Delete an MCP tool."""
    mcp_hub_service = MCPHubService()
    try:
        # Get the tool before deleting to retrieve server info
        existing_tool = await get_mcp_tool_by_id(
            session=session,
            mcp_tool_id=mcp_tool_id,
        )
        if existing_tool is None:
            raise HTTPException(status_code=404, detail="MCP Tool not found")
        
        # Get the MCP server to check its type
        mcp_server = await get_mcp_server_by_id(
            session=session,
            mcp_server_id=existing_tool.mcp_server_id,
        )

        membership = await get_membership_by_user_id_and_group_id(session, current_user.id, mcp_server.group_id)
        if not await has_permission(resource=mcp_server, action=PermCheckActionEnum.DELETE, user=current_user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied")

        # Delete from database
        await delete_mcp_tool(
            session=session,
            mcp_tool_id=mcp_tool_id,
            user_id=current_user.id,
        )
        
        # If the server is SELF_HOSTED, delete from MCP Hub
        if mcp_server and mcp_server.type == MCPServerTypeEnum.SELF_HOSTED:
            try:
                await mcp_hub_service.delete_mcp_tool(str(mcp_server.id), existing_tool.name)
            except Exception as hub_error:
                # Log the error but don't fail the request
                # The tool is deleted from DB, but MCP Hub deletion failed
                print(f"Warning: Failed to delete from MCP Hub: {hub_error}")
        
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()


@router.post("/{mcp_tool_id}/activate", response_model=MCPToolRead)
async def activate_tool(
    mcp_tool_id: UUID,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Activate an MCP tool (change status from PENDING to ACTIVE).
    
    **Authorization:** Requires superuser privileges.
    
    This endpoint changes the status of an MCP tool from PENDING to ACTIVE.
    For SELF_HOSTED MCP servers, this will also sync the tool with the MCP Hub.
    Only users with superuser privileges can activate tools.
    """
    mcp_hub_service = MCPHubService()
    try:
        # Check permissions
        membership = await get_one_membership_by_user_id(session, current_user.id)
        is_superuser = current_user.is_superuser
        if not is_superuser and not membership.is_group_admin:
            raise HTTPException(status_code=403, detail="Only superusers or group admins can activate MCP servers")
        
        
        # Get the existing tool
        existing_tool = await get_mcp_tool_by_id(
            session=session,
            mcp_tool_id=mcp_tool_id,
        )
        if existing_tool is None:
            raise HTTPException(status_code=404, detail="MCP Tool not found")
        
        # Check if tool is in PENDING status
        if existing_tool.status != MCPToolStatusEnum.PENDING:
            raise HTTPException(
                status_code=400, 
                detail=f"Tool must be in PENDING status to be activated. Current status: {existing_tool.status.value}"
            )
        
        # Get the MCP server to check its type
        mcp_server = await get_mcp_server_by_id(
            session=session,
            mcp_server_id=existing_tool.mcp_server_id,
        )
        if mcp_server is None:
            raise HTTPException(status_code=404, detail="MCP Server not found")
        
        # Update status to ACTIVE
        update_data = MCPToolUpdate(status=MCPToolStatusEnum.ACTIVE)
        mcp_tool = await update_mcp_tool(
            session=session,
            mcp_tool_id=mcp_tool_id,
            mcp_tool_update=update_data,
            user_id=current_user.id,
        )
        
        # If the server is SELF_HOSTED, sync with MCP Hub
        if mcp_server.type == MCPServerTypeEnum.SELF_HOSTED:
            try:
                # Create a MCPToolCreate object for the hub service
                tool_create = MCPToolCreate(
                    name=existing_tool.name,
                    description=existing_tool.description,
                    http_method=existing_tool.http_method,
                    path_template=existing_tool.path_template,
                    input_schema=existing_tool.input_schema,
                    path_mapping=existing_tool.path_mapping,
                    query_mapping=existing_tool.query_mapping,
                    headers_mapping=existing_tool.headers_mapping,
                    body_mapping=existing_tool.body_mapping,
                    raw_body_key=existing_tool.raw_body_key,
                    response_mapping=existing_tool.response_mapping,
                    mcp_server_id=existing_tool.mcp_server_id,
                )
                mcp_server_name = mcp_server.name.replace(" ", "_").lower()
                await mcp_hub_service.create_or_update_mcp_tool(tool_create, mcp_server_name)
            except Exception as hub_error:
                # Rollback the status change if hub sync fails
                await session.rollback()
                raise HTTPException(
                    status_code=500, 
                    detail=f"Failed to sync tool with MCP Hub: {str(hub_error)}"
                ) from hub_error
        
        return mcp_tool
    except HTTPException:
        raise
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()


@router.post("/{mcp_tool_id}/reject", response_model=MCPToolRead)
async def reject_tool(
    mcp_tool_id: UUID,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Reject an MCP tool (change status from PENDING to REJECTED).
    
    **Authorization:** Requires superuser privileges.
    
    This endpoint changes the status of an MCP tool from PENDING to REJECTED.
    Only users with superuser privileges can reject tools.
    """
    try:
        # Check if user is superuser
        if not current_user.is_superuser:
            raise HTTPException(status_code=403, detail="Only superusers can reject MCP tools")
        
        # Get the existing tool
        existing_tool = await get_mcp_tool_by_id(
            session=session,
            mcp_tool_id=mcp_tool_id,
        )
        if existing_tool is None:
            raise HTTPException(status_code=404, detail="MCP Tool not found")
        
        # Check if tool is in PENDING status
        if existing_tool.status != MCPToolStatusEnum.PENDING:
            raise HTTPException(
                status_code=400, 
                detail=f"Tool must be in PENDING status to be rejected. Current status: {existing_tool.status.value}"
            )
        
        # Update status to REJECTED
        update_data = MCPToolUpdate(status=MCPToolStatusEnum.REJECTED)
        mcp_tool = await update_mcp_tool(
            session=session,
            mcp_tool_id=mcp_tool_id,
            mcp_tool_update=update_data,
            user_id=current_user.id,
        )
        
        return mcp_tool
    except HTTPException:
        raise
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e


class TestToolRequest(BaseModel):
    """Request model for testing a tool."""

    args: dict = Field(default_factory=dict, description="Arguments to pass to the tool")


@router.post("/{mcp_tool_id}/test", status_code=200)
async def test_tool(
    mcp_tool_id: UUID,
    req: TestToolRequest,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Test an MCP tool by calling it through the MCP Hub.
    
    This endpoint tests a tool by sending a request to the MCP Hub and returning the result.
    
    **Parameters:**
    - `mcp_tool_id`: The UUID of the tool to test
    - `req`: Request body containing:
        - `args`: The arguments to pass to the tool (defaults to empty dict if not provided)
    
    **Returns:**
    - Test result including success status, data, error (if any), and status code
    """
    mcp_hub_service = MCPHubService()
    
    try:
        # Get the tool
        tool = await get_mcp_tool_by_id(
            session=session,
            mcp_tool_id=mcp_tool_id,
        )
        if tool is None:
            raise HTTPException(status_code=404, detail="MCP Tool not found")
        
        # Get the server
        server = await get_mcp_server_by_id(
            session=session,
            mcp_server_id=tool.mcp_server_id,
        )
        if server is None:
            raise HTTPException(status_code=404, detail="MCP Server not found")
        
        # if tool.status != MCPToolStatusEnum.ACTIVE:
        #     raise HTTPException(
        #         status_code=400,
        #         detail=f"Tool must be ACTIVE to be tested. Current status: {tool.status.value}"
        #     )
        
        # Test the tool
        result = await mcp_hub_service.test_mcp_tool(
            server_name=str(server.id),
            tool_name=tool.name,
            args=req.args,
        )
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()
