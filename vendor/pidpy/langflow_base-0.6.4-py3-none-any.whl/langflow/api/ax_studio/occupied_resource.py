from uuid import UUID
from datetime import datetime

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlmodel import select

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.omnipotent_access_granter_2000 import is_global_admin
from langflow.services.database.models.occupied_resource.crud import list_occupied_flows_by_resource_type_and_id
from langflow.services.database.models.occupied_resource.model import OccupiedResource
from langflow.services.database.models.flow.model import Flow
from langflow.services.database.models.resource_permission.constants import ResourceTypes

router = APIRouter(tags=["OCCUPIED_RESOURCE"], prefix="/occupied_resource")


class OccupiedResourceResponse(BaseModel):
    id: UUID
    resource_id: UUID
    resource_type: ResourceTypes
    flow_id: UUID | None
    flow_name: str | None
    create_at: datetime

    model_config = {"from_attributes": True}


@router.get("/{resource_type}/{resource_id}", response_model=list[OccupiedResourceResponse])
async def get_occupied_flows_by_resource(
    resource_type: ResourceTypes,
    resource_id: UUID,
    user: CurrentActiveUser,
    session: DbSession,
) -> list[OccupiedResourceResponse]:
    """List all flows that are occupying (using) the given resource."""
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")

    records = await list_occupied_flows_by_resource_type_and_id(
        session, resource_type, str(resource_id)
    )

    # Collect distinct flow IDs to fetch names in one query
    flow_ids = {r.flow_id for r in records if r.flow_id is not None}
    flow_name_map: dict[UUID, str] = {}
    if flow_ids:
        stmt = select(Flow.id, Flow.name).where(Flow.id.in_(flow_ids))
        rows = (await session.exec(stmt)).all()
        flow_name_map = {row.id: row.name for row in rows}

    return [
        OccupiedResourceResponse(
            id=r.id,
            resource_id=r.resource_id,
            resource_type=r.resource_type,
            flow_id=r.flow_id,
            flow_name=flow_name_map.get(r.flow_id) if r.flow_id else None,
            create_at=r.create_at,
        )
        for r in records
    ]
