from uuid import UUID
from typing import List

from fastapi import APIRouter, HTTPException

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.schemas import BulkUpdateUsersRequest
from langflow.services.database.models.user.crud import get_user_by_id
from langflow.services.database.models.user_group.model import MembershipRead, MembershipUpdate, MembershipCreate
from langflow.services.database.models.user_group.crud import get_one_membership_by_user_id, update_membership, update_membership_by_id, delete_one_membership, create_many_memberships, delete_many_memberships
from langflow.api.ax_studio.omnipotent_access_granter_2000 import is_global_admin

router = APIRouter(tags=["MEMBERSHIP"], prefix="/user_group")


# @router.patch("/{user_id}")
async def patch_membership_by_user_id(
        user_id: UUID,
        membership_update: MembershipUpdate,
        session: DbSession,
) -> MembershipRead:
    """Update an existing membership's data."""
    if membership_old := await get_one_membership_by_user_id(session, user_id):
        return await update_membership(membership_old, membership_update, session)

    raise HTTPException(status_code=404, detail="User group not found")


@router.patch("/bulk/update")
async def update_multiple_users(
        request: BulkUpdateUsersRequest,
        current_user: CurrentActiveUser,
        session: DbSession,
) -> dict:
    """Update multiple users with the same settings in a single request."""
    memberships_to_create = [
        MembershipCreate(
            user_id=user_id,
            group_id=request.updates.group_id,
            is_group_admin=request.updates.is_group_admin or False,
            create_by=current_user.id,
        )
        for user_id in request.user_ids
    ]

    try:
        await delete_many_memberships(session, request.user_ids)
        created = await create_many_memberships(session, memberships_to_create)
        results = [str(m.id) for m in created]
        errors = []
    except HTTPException as e:
        results = []
        errors = [{"error": e.detail}]

    # Return successful results even if there were some errors
    return {"results": results, "errors": errors}


@router.patch("/{membership_id}/admin")
async def update_membership_admin(
        membership_id: UUID,
        membership_update: MembershipUpdate,
        current_user: CurrentActiveUser,
        session: DbSession,
) -> MembershipRead:
    """Update group admin status of a membership. Requires global admin."""
    if not is_global_admin(current_user):
        raise HTTPException(status_code=403, detail="Only global admins can change group admin status")
    return await update_membership_by_id(membership_id, membership_update, session)


@router.patch("/usergroup_remove/{user_id}")
async def remove_membership(
        user_id: UUID,
        current_user: CurrentActiveUser,
        session: DbSession,
) -> MembershipRead:
    membership = await get_one_membership_by_user_id(session, user_id)
    if not membership:
        raise HTTPException(status_code=404, detail="Membership not found")

    await delete_one_membership(session, membership.id)
    return membership