import asyncio
from uuid import UUID
from sqlalchemy import text
from fastapi import APIRouter, HTTPException
from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.schemas import FetchMetadataRdbRequest, DatasourceRDBUpdateRequest
from langflow.services.database.models.datasource.constants import DatasourceRDB
from langflow.services.database.models.datasource_rdb import (
    DatasourceRdb,
    DatasourceRdbRead,
    get_datasource_rdb_by_datasource_id,
    update_datasource_rdb,
    rdb_perform_connect,
)

router = APIRouter(tags=["DATA_ASSET_RDB"], prefix="/datasource_rdb")


@router.post("/fetch_metadata")
async def fetch_metadata(
        session: DbSession,
        request: FetchMetadataRdbRequest,
) -> dict:
    """Get datasource metadata for RDB."""
    engine = None
    conn = None
    
    try:
        engine, conn, metadata = await rdb_perform_connect(session, request.datasource_id, request.datasource_type, request.connection_config)

        # conn was created inside a worker thread (asyncio.to_thread) and is not
        # thread-safe to use here. Close it immediately and use the thread-safe
        # engine for any subsequent queries.
        if conn:
            conn.close()
            conn = None

        metadata_obj = {"number of tables": len(metadata.tables)}

        db_name = (request.connection_config or {}).get('database_name')
        db_type = request.datasource_type

        def _get_db_size():
            with engine.connect() as c:
                if db_type == DatasourceRDB.POSTGRESQL:
                    return c.execute(text(f"SELECT pg_database_size('{db_name}')")).scalar()
                elif db_type == DatasourceRDB.ORACLE:
                    return c.execute(text("SELECT SUM(bytes) FROM user_segments")).scalar() or 0
                elif db_type in (DatasourceRDB.MYSQL, DatasourceRDB.MARIA_DB):
                    return c.execute(text(f"SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = '{db_name}'")).scalar() or 0
                return None

        metadata_obj["size"] = await asyncio.to_thread(_get_db_size)

        metadata_obj["tables"] = []
        for table_name, table_obj in metadata.tables.items():
            table_dict = {"name": table_name, "columns": [], "comment": table_obj.comment}
            for column in table_obj.columns:
                # Get default value from either client-side or server-side default
                default_value = None
                if column.default is not None:
                    default_value = str(column.default.arg)
                elif column.server_default is not None:
                    default_value = str(column.server_default.arg)
                
                col_dict = {
                    'name': column.name,
                    'type': str(column.type),
                    'nullable': column.nullable,
                    'default': default_value,
                    'primary_key': column.primary_key,
                    'unique': column.unique,
                    'comment': column.comment,
                    'foreign_keys': ", ".join([str(fk.column) for fk in column.foreign_keys])
                }
                table_dict["columns"].append(col_dict)
            metadata_obj["tables"].append(table_dict)

    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Connection test failed: {str(e)}") from e
    finally:
        if conn:
            conn.close()
        if engine:
            engine.dispose()
    
    return {"detail": metadata_obj}


# @router.put("/{datasource_id}", response_model=DatasourceRdbRead)
async def update_rdb_config(
        datasource_id: UUID,
        request: DatasourceRDBUpdateRequest,
        session: DbSession,
        user: CurrentActiveUser,
) -> DatasourceRdb:
    """Update RDB configuration for a datasource."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    rdb_config = await get_datasource_rdb_by_datasource_id(session, datasource_id)
    if not rdb_config:
        raise HTTPException(status_code=404, detail="RDB configuration not found")
    
    return await update_datasource_rdb(rdb_config, request, session)
