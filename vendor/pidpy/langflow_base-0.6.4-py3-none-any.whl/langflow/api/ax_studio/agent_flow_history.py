import json
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, desc
from sqlmodel import select
from sqlmodel.sql.expression import SelectOfScalar

from langflow.api.utils import DbSession
from langflow.api.ax_studio.schemas import AgentFlowHistoryResponse
from langflow.services.database.models.agent_flow_history.model import AgentFlowHistory, AgentFlowHistoryRead
from langflow.services.database.models.user.model import User

router = APIRouter(tags=["EXPORTED_FLOW_HISTORY"], prefix="/agent_flow_history")

@router.get("/{agent_flow_history_id}")
async def read_agent_flow_history_by_id(
    *,
    agent_flow_history_id: UUID,
    session: DbSession,
) -> AgentFlowHistoryRead:
    """Retrieve agent flow history's data by id."""
    query: SelectOfScalar = select(AgentFlowHistory).where(AgentFlowHistory.id == agent_flow_history_id)
    agent_flow_history = (await session.exec(query)).first()

    if agent_flow_history is None:
        raise HTTPException(status_code=404, detail="Agent flow history not found")

    agent_flow_history_dict = agent_flow_history.model_dump()
    agent_flow_history_dict["old_values"] = json.loads(agent_flow_history_dict.get("old_values") or "{}")
    agent_flow_history_dict["new_values"] = json.loads(agent_flow_history_dict.get("new_values") or "{}")

    creator_q = select(User).where(User.id == agent_flow_history.create_by)
    creator = (await session.exec(creator_q)).first()
    agent_flow_history_dict["created_by_username"] = creator.username if creator else None

    return AgentFlowHistoryRead(**agent_flow_history_dict)


@router.get("/")
async def read_all_agent_flow_histories(
        *,
        skip: int = Query(0, description="Number of items to skip"),
        limit: int = Query(10, description="Maximum number of items to return"),
        agent_flow_id: UUID = Query(..., description="Agent flow ID is required"),
        session: DbSession,
) -> AgentFlowHistoryResponse:
    """Retrieve a list of agent flow histories from the database with pagination."""
    query = select(AgentFlowHistory)
    count_query = select(func.count()).select_from(AgentFlowHistory)

    # Apply filtering
    where_condition = AgentFlowHistory.agent_flow_id == agent_flow_id
    query = query.where(where_condition)
    count_query = count_query.where(where_condition)
    
    # Apply sorting
    query = query.order_by(desc(AgentFlowHistory.create_at))

    # Apply pagination
    query = query.offset(skip).limit(limit)

    agent_flow_histories = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()

    histories = []
    for history_data in agent_flow_histories:
        history_dict = history_data.model_dump()
        history_dict["old_values"] = json.loads(history_dict.get("old_values") or "{}")
        history_dict["new_values"] = json.loads(history_dict.get("new_values") or "{}")

        creator_q = select(User).where(User.id == history_data.create_by)
        creator = (await session.exec(creator_q)).first()
        history_dict["created_by_username"] = creator.username if creator else None
        
        histories.append(history_dict)

    return AgentFlowHistoryResponse(
        total_count=total_count,
        agent_flow_histories=[AgentFlowHistoryRead(**history) for history in histories],
    )
