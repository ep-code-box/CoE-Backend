from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, and_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlmodel import select

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.schemas import UserRoleResponse, UserRoleCreateRequest, UserRoleUpdateRequest
from langflow.services.database.models.user_role.crud import get_user_role_by_id, update_user_role
from langflow.services.database.models.user_role.model import UserRole, UserRoleCreate, UserRoleRead, UserRoleUpdate
from langflow.services.database.models.user_role.constants import DEFAULT_ROLES

router = APIRouter(tags=["USER_ROLE"], prefix="/user_role")


@router.post("/", response_model=UserRoleCreate, status_code=201)
async def add_user_role(
        request: UserRoleCreateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> UserRole:
    """Add a new user role to the database."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    # Convert UserRoleCreateRequest to UserRoleCreate
    user_role_name = request.name.strip()

    if not 1 <= len(user_role_name) <= 50:
        raise HTTPException(status_code=400, detail="User role name must be between 1 and 50 characters.")

    user_role_create = UserRoleCreate(
        name=user_role_name,
        create_by=user.id
    )

    new_user_role = UserRole.model_validate(user_role_create, from_attributes=True)
    new_user_role.update_search_field()
    try:
        session.add(new_user_role)
        await session.commit()
        await session.refresh(new_user_role)
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail="This user role name is unavailable.") from e

    return new_user_role


@router.get("/{user_role_id}")
async def read_user_role_by_id(
        *,
        user_role_id: UUID,
        session: DbSession,
) -> UserRoleRead:
    """Retrieve user role's data by id."""
    user_role = await get_user_role_by_id(session, user_role_id)

    if user_role is None:
        raise HTTPException(status_code=404, detail="User role not found")

    return UserRoleRead(**user_role.model_dump())


@router.get("")
async def read_all_user_roles(
        *,
        skip: int = Query(0, description="Number of items to skip"),
        limit: int = Query(10, description="Maximum number of items to return"),
        search_str: str = None,
        session: DbSession,
) -> UserRoleResponse:
    """Retrieve a list of user roles from the database with pagination."""
    where_queries = __build_user_role_where_query(search_str=search_str)

    if where_queries is not None:
        query = select(UserRole).where(where_queries).offset(skip).limit(limit)
        count_query = select(func.count()).select_from(UserRole).where(where_queries)
    else:
        query = select(UserRole).offset(skip).limit(limit)
        count_query = select(func.count()).select_from(UserRole)
    user_roles = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()

    return UserRoleResponse(
        total_count=total_count,
        user_roles=[UserRoleRead(**user_role.model_dump()) for user_role in user_roles],
    )


def __build_user_role_where_query(search_str=None):
    conditions = []

    if search_str:
        conditions.append(UserRole.search_field.ilike(f"%{search_str}%"))

    if conditions:
        return and_(*conditions)
    else:
        return None


@router.patch("/{user_role_id}", response_model=UserRoleRead)
async def patch_user_role(
        user_role_id: UUID,
        request: UserRoleUpdateRequest,
        session: DbSession,
) -> UserRole:
    """Update an existing user's role data."""
    # Convert UserRoleUpdateRequest to UserRoleUpdate
    user_role_name = request.name.strip()
    if not 1 <= len(user_role_name) <= 50:
        raise HTTPException(status_code=400, detail="User role name must be between 1 and 50 characters.")

    user_role_update = UserRoleUpdate(name=user_role_name)
    
    if user_role_db := await get_user_role_by_id(session, user_role_id):
        return await update_user_role(user_role_db, user_role_update, session)

    raise HTTPException(status_code=404, detail="User role not found")


@router.delete("/{user_role_id}")
async def delete_user_role(
        user_role_id: UUID,
        session: DbSession,
) -> dict:
    """Delete an user role from the database."""
    stmt = select(UserRole).where(UserRole.id == user_role_id).options(selectinload(UserRole.users))
    user_role_db = (await session.exec(stmt)).first()
    if not user_role_db:
        raise HTTPException(status_code=404, detail="User role not found")
    
    # Prevent deletion of default user roles
    default_role_names = [role["name"] for role in DEFAULT_ROLES]
    if user_role_db.name in default_role_names:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete default role '{user_role_db.name}'. Default roles are protected."
        )

    # Check if user role is being used
    if user_role_db.users and len(user_role_db.users) > 0:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete role '{user_role_db.name}'. It is currently assigned to {len(user_role_db.users)} user(s)."
        )

    await session.delete(user_role_db)
    await session.commit()

    return {"detail": "User role deleted"}
