from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy.exc import IntegrityError

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.omnipotent_access_granter_2000 import is_global_admin
from langflow.services.database.models.guide.crud import (
    list_guides,
    get_guide_by_id,
    create_guide,
    edit_guide,
    delete_guide,
    rate_guide,
    save_guide,
    react_to_guide,
)
from langflow.services.database.models.guide.model import (
    GuideCreate,
    GuideUpdate,
    GuideRead,
    GuideListResponse,
    GuideTypeEnum,
    ReactionEnum,
)

router = APIRouter(tags=["FAQ"], prefix="/faq")


@router.get("/", response_model=dict)
async def get_helps(
    session: DbSession,
    user: CurrentActiveUser,
    skip: int = Query(0, description="Number of items to skip"),
    limit: int = Query(100, description="Maximum number of items to return"),
    search: Optional[str] = Query(None, description="Search term for title or content"),
    guide_type: List[GuideTypeEnum] = Query([GuideTypeEnum.FAQ], description="Filter by guide type"),
    is_published: Optional[bool] = Query(None, description="Filter by published status"),
    saved_only: bool = Query(False, description="Show only saved guides"),
    sort_by: Optional[str] = Query("created_at", description="Field to sort by"),
    sort_dir: str = Query("desc", description="Sort direction (asc or desc)"),
) -> dict:
    """
    Retrieve a list of guides with filtering, search, and pagination.
    """
    # Build filter dictionary
    filter_by = {}
    if guide_type:
        filter_by["guide_type"] = guide_type
    if is_published is not None:
        filter_by["is_published"] = is_published
    
    # Determine saved_by parameter
    saved_by = user.id if saved_only else None
    
    # Get guides
    guides, total_count = await list_guides(
        db=session,
        filter_by=filter_by,
        sort_by=sort_by,
        sort_dir=sort_dir,
        limit=limit,
        offset=skip,
        search_term=search,
        saved_by=saved_by,
        current_user_id=user.id,
    )
    
    return {
        "guides": guides,
        "total_count": total_count,
        "skip": skip,
        "limit": limit,
    }


@router.get("/{guide_id}", response_model=GuideRead)
async def get_help(
    guide_id: UUID,
    session: DbSession,
    user: CurrentActiveUser,
) -> GuideRead:
    """
    Retrieve a single guide by ID.
    """
    guide = await get_guide_by_id(session, guide_id)
    
    if not guide:
        raise HTTPException(status_code=404, detail="Guide not found")
    
    return GuideRead(**guide.model_dump())


@router.post("/", response_model=GuideRead, status_code=201)
async def create_new_help(
    request: GuideCreate,
    session: DbSession,
    user: CurrentActiveUser,
) -> GuideRead:
    """
    Create a new guide.
    """
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")
    
    try:
        new_guide = await create_guide(
            db=session,
            guide_create=request,
            user_id=user.id,
        )
        return GuideRead(**new_guide.model_dump())
    except IntegrityError as e:
        raise HTTPException(status_code=400, detail=f"Failed to create guide: {str(e)}") from e


@router.patch("/{guide_id}", response_model=GuideRead)
async def update_help(
    guide_id: UUID,
    request: GuideUpdate,
    session: DbSession,
    user: CurrentActiveUser,
) -> GuideRead:
    """
    Update an existing guide.
    """
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")
    
    updated_guide = await edit_guide(
        db=session,
        guide_id=guide_id,
        guide_update=request,
        user_id=user.id,
    )
    
    return GuideRead(**updated_guide.model_dump())


@router.delete("/{guide_id}")
async def delete_help(
    guide_id: UUID,
    session: DbSession,
    user: CurrentActiveUser,
) -> dict:
    """
    Delete a guide by ID.
    """
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")
    
    await delete_guide(session, guide_id)
    
    return {"message": "Guide deleted successfully"}


@router.post("/{guide_id}/rate")
async def rate_help(
    guide_id: UUID,
    session: DbSession,
    user: CurrentActiveUser,
    rating: int = Query(..., ge=1, le=5, description="Rating value (1-5)"),
) -> dict:
    """
    Rate a guide (1-5 stars).
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    guide_rating = await rate_guide(
        db=session,
        guide_id=guide_id,
        user_id=user.id,
        rating=rating,
    )
    
    return {
        "message": "Rating submitted successfully",
        "rating": guide_rating.rating,
        "rated_at": guide_rating.rated_at,
    }


@router.post("/{guide_id}/save")
async def save_help(
    session: DbSession,
    user: CurrentActiveUser,
    guide_id: UUID,
    save: bool = Query(True, description="True to save, False to unsave"),
) -> dict:
    """
    Save or unsave a guide.
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    is_saved = await save_guide(
        db=session,
        guide_id=guide_id,
        user_id=user.id,
        save=save,
    )
    
    return {
        "message": "Guide saved successfully" if is_saved else "Guide unsaved successfully",
        "is_saved": is_saved,
    }


@router.post("/{guide_id}/react")
async def react_help(
    guide_id: UUID,
    session: DbSession,
    user: CurrentActiveUser,
    reaction: Optional[ReactionEnum] = Query(None, description="Reaction type (like/dislike) or None to remove reaction"),
) -> dict:
    """
    React to a guide (like/dislike) or remove reaction.
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    guide_reaction = await react_to_guide(
        db=session,
        guide_id=guide_id,
        user_id=user.id,
        reaction=reaction,
    )
    
    if guide_reaction is None:
        return {
            "message": "Reaction removed successfully",
            "reaction": None,
        }
    else:
        return {
            "message": "Reaction submitted successfully",
            "reaction": guide_reaction.reaction,
            "reacted_at": guide_reaction.reacted_at,
        }
