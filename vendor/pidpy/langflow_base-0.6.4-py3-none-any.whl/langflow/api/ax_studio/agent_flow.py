from uuid import UUID
from datetime import datetime, timezone
from typing import Optional
import os
import json
import httpx

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, and_, asc, desc
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.attributes import flag_modified
from sqlmodel import select
from sqlalchemy.orm import selectinload

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.schemas import (
    ExportedFlowResponse, 
    AgentFlowCreateRequest, 
    AgentFlowUpdateRequest,
    CoEBackendResponse
)
from langflow.services.database.models.agent_flow.crud import get_exported_flow_by_id
from langflow.services.database.models.agent_flow.model import AgentFlow, ExportedFlowCreate, ExportedFlowRead
from langflow.services.database.models.agent_flow.constants import AgentFlowStatus
from langflow.services.database.models.agent_flow_history.constants import AgentFlowHistoryAction
from langflow.services.database.models.agent_flow_history.crud import create_exported_flow_history
from langflow.services.database.models.resource_permission.crud import get_resource_permission_by_user_id, create_resource_permission, delete_resource_permissions_by_resource_id
from langflow.services.database.models.resource_permission.constants import ResourceTypes
from langflow.services.database.models.user_group.crud import get_membership_by_user_id_and_group_id
from langflow.services.database.models.user_group.model import UserGroup
from langflow.services.database.models.resource_permission.model import ResourcePermission
from langflow.api.ax_studio.omnipotent_access_granter_2000 import has_permission, PermCheckActionEnum
from langflow.services.database.models.recent_activity.crud import add_recent_activity
from langflow.services.database.models.recent_activity.model import ActivityItemTypeEnum, ActivityTypeEnum

router = APIRouter(tags=["EXPORTED_FLOW"], prefix="/agent_flow")

# CoE Backend URL from environment variable
# Set COE_FLOWS_URL in your .env file to configure the CoE Backend endpoint
# Default: http://localhost:8000/flows/
# Example: COE_FLOWS_URL=https://your-coe-backend.com/flows/
COE_FLOWS_URL = os.getenv("COE_FLOWS_URL", "http://localhost:8000")


def get_flow_url_from_coe():
    """
    Get and return flow url from coe.
    """
    
    return f"{COE_FLOWS_URL}/flows"  # Use .format(endpoint=...) to format the URL


def create_insert_or_delete_flow_by_flow_id_from_coe_url(flow_id:str):
    """
    Create and return url for inserting or deleting flow to/from coe.
    """
    return f"{COE_FLOWS_URL}/flows/langflow/{flow_id}"  # Use .format(flow_id=...) to format the URL


def create_check_flow_by_endpoint_from_coe_url(endpoint:str):
    """
    Create and return url for checking flow by endpoint in coe.
    """
    return f"{COE_FLOWS_URL}/flows/endpoint/{endpoint}"  # Use .format(endpoint=...) to format the URL


async def create_to_coe_backend(
    endpoint: str,
    description: Optional[str],
    flow_body: dict,
    flow_id: UUID,
    contexts: list[str],
    group_names: list[str],
    group_name: Optional[str] = None,
) -> CoEBackendResponse:
    """Send agent flow data to CoE Backend API.
    
    Args:
        endpoint: The endpoint name
        description: Flow description
        flow_body: The flow data
        flow_id: Flow ID
        contexts: List of context strings
        group_names: List of group names
        group_name: Primary group name (for name formatting)
    """
    try:
        # Build context_groups structure
        context_groups = []
        for ctx in contexts:
            entry = {"context": ctx}
            if group_names:
                entry["group_names"] = group_names
            context_groups.append(entry)
        
        payload = {
            "endpoint": endpoint,
            "description": description,
            "flow_body": flow_body,
            "flow_id": str(flow_id),
            "contexts": contexts,
            "context_groups": context_groups,
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            url = get_flow_url_from_coe()
            response = await client.post(
                url=url,
                json=payload,
                headers={"Content-Type": "application/json", "accept": "application/json"},
            )
            return CoEBackendResponse(
                success=response.is_success,
                status_code=response.status_code,
                response_text=response.text,
            )
            
    except httpx.TimeoutException as e:
        return CoEBackendResponse(
            success=False,
            error=f"Timeout connecting to CoE Backend: {str(e)}"
        )
    except Exception as e:
        return CoEBackendResponse(
            success=False,
            error=f"Failed to send to CoE Backend: {str(e)}"
        )


async def delete_to_coe_backend(
    flow_id: UUID,
) -> CoEBackendResponse:
    """Send DELETE request to remove agent flow from CoE Backend API.
    
    Args:
        flow_id: Flow ID to delete
    """
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            url = create_insert_or_delete_flow_by_flow_id_from_coe_url(flow_id=str(flow_id))
            response = await client.delete(
                url=url,
                headers={"accept": "application/json"},
            )
            return CoEBackendResponse(
                success=response.is_success,
                status_code=response.status_code,
                response_text=response.text,
            )
            
    except httpx.TimeoutException as e:
        return CoEBackendResponse(
            success=False,
            error=f"Timeout connecting to CoE Backend: {str(e)}"
        )
    except Exception as e:
        return CoEBackendResponse(
            success=False,
            error=f"Failed to delete from CoE Backend: {str(e)}"
        )


@router.post("/", response_model=ExportedFlowRead, status_code=201)
async def add_exported_flow(
        request: AgentFlowCreateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> AgentFlow:
    """Add a new agent flow to the database."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    exported_flow_name = request.name.strip()
    if not 1 <= len(exported_flow_name) <= 50:
        raise HTTPException(status_code=400, detail="Agent flow name must be between 1 and 50 characters.")
    
    # check existed flow with same endpoint
    print("Checking for existing flow with endpoint:", request.endpoint)
    if request.endpoint:
        existing_flow_query = select(AgentFlow).where(
            and_(
                AgentFlow.endpoint == request.endpoint,
                AgentFlow.status != AgentFlowStatus.DELETED.value,
            )
        ).limit(1)
        existing_flow_result = await session.exec(existing_flow_query)
        existing_flow = existing_flow_result.first()
        if existing_flow:
            raise HTTPException(status_code=400, detail="An agent flow with the same endpoint already exists.")

    # create record in db
    print("Create record in DB ...")
    exported_flow_create = ExportedFlowCreate(
        lf_flow_id=request.lf_flow_id,
        name=exported_flow_name,
        description=request.description.strip() if request.description else "",
        endpoint=request.endpoint,
        context=request.context,
        flow_operation=request.flow_operation,
        langgraph_group_id=request.langgraph_group_id,
        save_with_api_key=request.save_with_api_key,
        json_setting=request.json_setting,
        create_by=user.id,
        group_id=user.user_groups[0].group_id,
    )

    # validate flow
    new_exported_flow = AgentFlow.model_validate(exported_flow_create, from_attributes=True)
    new_exported_flow.update_search_field()
    
    # save to db
    print("Saving to DB ...")
    try:
        session.add(new_exported_flow)
        await session.flush()  # Flush to get the ID without committing
        await create_exported_flow_history(session, AgentFlowHistoryAction.REVIEW_REQUESTED, user.id, new_exported_flow)
        
        await session.commit()
        await session.refresh(new_exported_flow)
        
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail="This agent flow name is unavailable.") from e

    # create to coe Backend
    print("Creating to CoE Backend ...")
    await create_to_coe_backend(
        endpoint=new_exported_flow.endpoint,
        description=new_exported_flow.description,
        flow_body=json.loads(new_exported_flow.json_setting) if new_exported_flow.json_setting else {},
        flow_id=new_exported_flow.lf_flow_id,
        contexts=[ctx.strip() for ctx in new_exported_flow.context.split(',') if ctx.strip()] if new_exported_flow.context else [],
        group_names=[new_exported_flow.group.name] if new_exported_flow.group else [],
        group_name=new_exported_flow.group.name if new_exported_flow.group else None,
    )

    return new_exported_flow


@router.get("/check_endpoint")
async def check_endpoint_exists(
    endpoint: str = Query(..., description="Endpoint string to check"),
    session: DbSession = None,
    user: CurrentActiveUser = None,
) -> dict:
    """
    Returns:
        dict: { "exists": bool }
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    query = select(AgentFlow).where(
        and_(
            AgentFlow.endpoint == endpoint,
            # AgentFlow.status == AgentFlowStatus.APPROVED,
        )
    ).limit(1)

    result = await session.exec(query)
    flow = result.first()
    db_exists = flow is not None

    coe_exists = False
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            url = create_check_flow_by_endpoint_from_coe_url(endpoint=endpoint)
            coe_response = await client.get(
                url=url,
                headers={"accept": "application/json"},
            )
            if coe_response.status_code == 200:
                coe_exists = True
    except Exception as e:
        coe_exists = False

    return {
        "exists": db_exists or coe_exists,
        "db_exists": db_exists,
        "coe_exists": coe_exists,
    }


@router.get("/{exported_flow_id}")
async def read_exported_flow_by_id(
    *,
    exported_flow_id: UUID,
    user: CurrentActiveUser,
    session: DbSession,
) -> ExportedFlowRead:
    """Retrieve agent flow's data by id."""
    exported_flow = await get_exported_flow_by_id(session, exported_flow_id, load_creator=True, load_group=True, load_approver=True)

    membership = await get_membership_by_user_id_and_group_id(session, user.id, exported_flow.group_id)
    if not await has_permission(resource=exported_flow, action=PermCheckActionEnum.READ, user=user, membership=membership):
        raise HTTPException(status_code=403, detail="Permission denied: you cannot read this agent flow.")

    exported_flow_data = exported_flow.model_dump()
    exported_flow_data["create_by_username"] = exported_flow.creator.username if exported_flow.creator else None
    exported_flow_data["group_name"] = exported_flow.group.name if exported_flow.group else None
    exported_flow_data["approver_name"] = exported_flow.approver.username if exported_flow.approver else None
    return ExportedFlowRead(**exported_flow_data)


@router.get("/")
async def read_all_exported_flows(
        *,
        skip: int = Query(0, description="Number of items to skip"),
        limit: int = Query(10, description="Maximum number of items to return"),
        search_str: str = None,
        status: AgentFlowStatus = None,
        sort: str = Query(default="desc", description="Sort direction: 'asc' for A-Z, 'desc' for Z-A"),
        sort_by: str = Query(default="created_at", description="Field to sort by"),
        group_ids: list[UUID] | None = None,
        user: CurrentActiveUser,
        session: DbSession,
        filter_by_permission: bool = Query(default=False, description="Bypass permission filtering"),
) -> ExportedFlowResponse:
    """
    Retrieve a list of agent flows from the database with pagination.
    **Permission Logic:**
    - if is_superuser:
        + if group_ids is not None: filter_by group_ids
        + else: no group filter (get all)
    - else: filter_by current user's group_id
    - On top of filtering by group_id(s), also filter by ResourcePermission if filter_by_permission is True.
    
    TODO: support group_ids
    """
    # get_by_membership
    get_by_membership = not user.is_superuser


    def _filter_by_permission(select_query):
        # useless
        return (
            select_query
        )
    
    if not filter_by_permission:
        query = select(AgentFlow)
        count_query = select(func.count()).select_from(AgentFlow)
        status_count_query = select(AgentFlow.status, func.count(AgentFlow.id).label('count')).group_by(AgentFlow.status)
    else:
        query = _filter_by_permission(select(AgentFlow))
        count_query = _filter_by_permission(select(func.count()).select_from(AgentFlow))
        status_count_query = _filter_by_permission(select(AgentFlow.status, func.count(AgentFlow.id).label('count')).group_by(AgentFlow.status))

    if get_by_membership:
        _ug_join = (UserGroup.group_id == AgentFlow.group_id) & (UserGroup.user_id == user.id)
        query = query.join(UserGroup, _ug_join)
        count_query = count_query.join(UserGroup, _ug_join)
        status_count_query = status_count_query.join(UserGroup, _ug_join)

    # Apply filtering
    where_queries = __build_exported_flow_where_query(status=status, group_ids=group_ids, search_str=search_str)
    # Apply same filtering for status counts (excluding status filter to get all counts)
    where_queries_for_counts = __build_exported_flow_where_query(status=None, group_ids=group_ids, search_str=search_str)

    if where_queries is not None:
        query = query.where(where_queries)
        count_query = count_query.where(where_queries)
    
    if where_queries_for_counts is not None:
        status_count_query = status_count_query.where(where_queries_for_counts)
    
    # Apply sorting
    sort_column = getattr(AgentFlow, sort_by, AgentFlow.create_at)
    if sort == "asc":
        query = query.order_by(asc(sort_column))
    elif sort == "desc":
        query = query.order_by(desc(sort_column))
    
    # Apply pagination
    query = query.offset(skip).limit(limit)
    
    # Eagerly load creator and group relationships
    query = query.options(selectinload(AgentFlow.creator), selectinload(AgentFlow.group), selectinload(AgentFlow.approver))

    exported_flows = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()
    status_counts_result = (await session.exec(status_count_query)).fetchall()

    exported_flows_read = []
    for exported_flow in exported_flows:
        exported_flow_data = exported_flow.model_dump()
        exported_flow_data["create_by_username"] = exported_flow.creator.username if exported_flow.creator else None
        exported_flow_data["group_name"] = exported_flow.group.name if exported_flow.group else None
        exported_flow_data["approver_name"] = exported_flow.approver.username if exported_flow.approver else None
        exported_flows_read.append(ExportedFlowRead(**exported_flow_data))

    status_counts = {status: count for status, count in status_counts_result}

    return ExportedFlowResponse(
        total_count=total_count,
        agent_flows=exported_flows_read,
        status_counts=status_counts,
    )


def __build_exported_flow_where_query(status=None, group_ids=None, search_str=None):
    conditions = []

    if status:
        conditions.append(AgentFlow.status == status.value)
    if group_ids:
        conditions.append(AgentFlow.group_id.in_(group_ids))
    if search_str:
        conditions.append(AgentFlow.search_field.ilike(f"%{search_str}%"))
    conditions.append(AgentFlow.status != AgentFlowStatus.DELETED.value)

    if conditions:
        return and_(*conditions)
    else:
        return None


@router.patch("/{exported_flow_id}", response_model=ExportedFlowRead)
async def patch_exported_flow(
        exported_flow_id: UUID,
        request: AgentFlowUpdateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> AgentFlow:
    """Update an existing coe backend's data."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    try:
        exported_flow_old = await get_exported_flow_by_id(session, exported_flow_id, load_masterdata=True, load_group=True, load_creator=True, load_approver=True)

        req_status = request.status.value if isinstance(request.status, AgentFlowStatus) else request.status
        if req_status == AgentFlowStatus.APPROVED.value:
            action = PermCheckActionEnum.APPROVE
        elif req_status == AgentFlowStatus.REJECTED.value:
            action = PermCheckActionEnum.REJECT
        else:
            action = PermCheckActionEnum.WRITE

        membership = await get_membership_by_user_id_and_group_id(session, user.id, exported_flow_old.group_id)
        if not await has_permission(resource=exported_flow_old, action=action, user=user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied.")

        # Store old values for history - serialize immediately to avoid lazy loading issues
        old_values = exported_flow_old.model_dump_json()
        
        # Apply updates
        exported_flow_data = request.model_dump(exclude_unset=True, mode='python')
        if "name" in exported_flow_data:
            exported_flow_data["name"] = exported_flow_data["name"].strip()
            if not 1 <= len(exported_flow_data["name"]) <= 50:
                raise HTTPException(status_code=400, detail="Agent flow name must be between 1 and 50 characters.")

        changed = False
        for attr, value in exported_flow_data.items():
            if hasattr(exported_flow_old, attr) and value is not None:
                # Convert enum to string value if it's an AgentFlowStatus enum
                if attr == "status" and isinstance(value, AgentFlowStatus):
                    value = value.value
                setattr(exported_flow_old, attr, value.strip() if isinstance(value, str) else value)
                changed = True

        if not changed:
            raise HTTPException(status_code=304, detail="Nothing to update")

        exported_flow_old.updated_at = datetime.now(timezone.utc)
        exported_flow_old.update_search_field()
        flag_modified(exported_flow_old, "updated_at")
        
        # Flush changes to make them available to the session
        await session.flush()

        # Create history record for the update
        exported_flow_data_status = exported_flow_data.get('status').value if isinstance(exported_flow_data.get('status'), AgentFlowStatus) else exported_flow_data.get('status')
        if not exported_flow_data_status or exported_flow_data_status not in [AgentFlowStatus.REJECTED.value, AgentFlowStatus.APPROVED.value]:
            exported_flow_old.status = AgentFlowStatus.PENDING.value
            exported_flow_old.reject_approve_reason = ""
            await create_exported_flow_history(
                session, 
                AgentFlowHistoryAction.UPDATED,
                user.id, 
                exported_flow_old, 
                old_values=old_values
            )
        elif exported_flow_data_status == AgentFlowStatus.REJECTED.value:
            exported_flow_old.approved_by = user.id
            await create_exported_flow_history(
                session, 
                AgentFlowHistoryAction.REJECTED, 
                user.id, 
                exported_flow_old, 
                old_values=old_values
            )
        elif exported_flow_data_status == AgentFlowStatus.APPROVED.value:
            exported_flow_old.approved_by = user.id
            await create_exported_flow_history(
                session, 
                AgentFlowHistoryAction.APPROVED, 
                user.id, 
                exported_flow_old, 
                old_values=old_values
            )

            # Send to CoE Backend when approved
            if exported_flow_old.endpoint and exported_flow_old.context:
                contexts = [ctx.strip() for ctx in exported_flow_old.context.split(',') if ctx.strip()]
                group_names = []
                group_name_str = None
                
                # Get group name for formatting
                if exported_flow_old.group:
                    group_name_str = exported_flow_old.group.name
                    group_names = [group_name_str]
                
                formatted_endpoint = exported_flow_old.endpoint
                
                # Parse json_setting to get flow_body
                flow_body = {}
                if exported_flow_old.json_setting:
                    try:
                        flow_body = json.loads(exported_flow_old.json_setting)
                    except json.JSONDecodeError:
                        pass
                
                coe_response = await create_to_coe_backend(
                    endpoint=formatted_endpoint,
                    description=exported_flow_old.description,
                    flow_body=flow_body,
                    flow_id=exported_flow_old.lf_flow_id,
                    contexts=contexts,
                    group_names=group_names,
                    group_name=group_name_str,
                )
                
                # Log the result but don't fail the approval if CoE backend fails
                if not coe_response.success:
                    print(f"Warning: Failed to send approved flow to CoE Backend: {coe_response.error}")
            #send path request to   
        
        await add_recent_activity(
            session=session,
            user_id=user.id,
            activity_type=ActivityTypeEnum.UPDATED,
            item_id=exported_flow_old.id,
            item_type=ActivityItemTypeEnum.FLOW,
            title=f"{exported_flow_old.name}",
            description=f"{exported_flow_old.description or ''}",
        )
        await session.commit()
        await session.refresh(exported_flow_old)
        
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return exported_flow_old


@router.delete("/{exported_flow_id}")
async def delete_exported_flow(
        exported_flow_id: UUID,
        user: CurrentActiveUser,
        session: DbSession,
) -> dict:
    """Delete an exported flow from the database. (Soft delete)"""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    try:
        exported_flow_old = await get_exported_flow_by_id(session, exported_flow_id, load_masterdata=True)

        membership = await get_membership_by_user_id_and_group_id(session, user.id, exported_flow_old.group_id)
        if not await has_permission(resource=exported_flow_old, action=PermCheckActionEnum.DELETE, user=user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied: you cannot delete this agent flow.")

        # Store old values for history - serialize immediately to avoid lazy loading issues
        old_values = exported_flow_old.model_dump_json()
        
        # Update status to DELETED
        exported_flow_old.status = AgentFlowStatus.DELETED.value
        exported_flow_old.updated_at = datetime.now(timezone.utc)
        flag_modified(exported_flow_old, "updated_at")
        
        # Flush changes to make them available to the session
        await session.flush()

        # Create history record for the deletion
        await create_exported_flow_history(
            session, 
            AgentFlowHistoryAction.DELETED, 
            user.id, 
            exported_flow_old, 
            old_values=old_values
        )
        
        # Delete resource permissions for this flow
        await delete_resource_permissions_by_resource_id(session, exported_flow_old.id)

        # Send DELETE request to CoE Backend
        coe_response = await delete_to_coe_backend(
                flow_id=exported_flow_old.lf_flow_id,
            )
            
        if not coe_response.success:
            print(f"Warning: Failed to delete flow from CoE Backend: {coe_response.error}")
        await add_recent_activity(
            session=session,
            user_id=user.id,
            activity_type=ActivityTypeEnum.DELETED,
            item_id=exported_flow_old.id,
            item_type=ActivityItemTypeEnum.FLOW,
            title=f"{exported_flow_old.name}",
            description=f"{exported_flow_old.description or ''}",
        )
        await session.commit()
        
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e

    return {"detail": "Agent flow deleted"}
