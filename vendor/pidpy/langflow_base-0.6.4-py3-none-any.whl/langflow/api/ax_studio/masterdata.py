from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, and_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlmodel import select

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.schemas import MasterDataResponse, MasterDataCreateRequest, MasterDataUpdateRequest
from langflow.services.database.models.masterdata.crud import (
    get_all_default_masterdata, 
    get_masterdata_by_id, 
    update_masterdata,
    validate_masterdata_info
)
from langflow.services.database.models.masterdata.model import MasterData, MasterDataRead, MasterDataCreate
from langflow.services.database.models.masterdata.constants import MasterDataTypes

router = APIRouter(tags=["MASTERDATA"], prefix="/masterdata")


@router.post("/", response_model=MasterDataCreateRequest, status_code=201)
async def add_masterdata(
        request: MasterDataCreateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> MasterData:
    """Add a new masterdata to the database."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    masterdata_create = MasterDataCreate(**request.model_dump())
    masterdata_create.name = masterdata_create.name.strip()

    validate_masterdata_info(masterdata_create)

    masterdata_create.create_by = user.id
    new_masterdata = MasterData.model_validate(masterdata_create, from_attributes=True)
    new_masterdata.update_search_field()
    try:
        session.add(new_masterdata)
        await session.commit()
        await session.refresh(new_masterdata)
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail="This masterdata name is unavailable.") from e

    return new_masterdata


@router.get("/{masterdata_id}")
async def read_masterdata_by_id(
        *,
        masterdata_id: UUID,
        session: DbSession,
) -> MasterDataRead:
    """Retrieve masterdata's data by id."""
    masterdata = await get_masterdata_by_id(session, masterdata_id)

    if masterdata is None:
        raise HTTPException(status_code=404, detail="MasterData not found")

    return MasterDataRead(**masterdata.model_dump())


@router.get("/")
async def read_all_masterdatas(
        *,
        skip: int = Query(0, description="Number of items to skip"),
        limit: int = Query(10, description="Maximum number of items to return"),
        type: MasterDataTypes = Query(None, description="Filter by masterdata type"),
        search_str: str = None,
        session: DbSession,
) -> MasterDataResponse:
    """Retrieve a list of masterdatas from the database with pagination."""
    where_queries = __build_masterdata_where_query(search_str=search_str, type=type)

    if where_queries is not None:
        query = select(MasterData).where(where_queries).offset(skip).limit(limit)
        count_query = select(func.count()).select_from(MasterData).where(where_queries)
    else:
        query = select(MasterData).offset(skip).limit(limit)
        count_query = select(func.count()).select_from(MasterData)
    masterdatas = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()

    return MasterDataResponse(
        total_count=total_count,
        masterdatas=[MasterDataRead(**masterdata.model_dump()) for masterdata in masterdatas],
    )


def __build_masterdata_where_query(search_str=None, type=None):
    conditions = []

    if search_str:
        conditions.append(MasterData.search_field.ilike(f"%{search_str}%"))
    if type:
        type_value = type.value if isinstance(type, MasterDataTypes) else type
        conditions.append(MasterData.type == type_value)
    if conditions:
        return and_(*conditions)
    else:
        return None


@router.patch("/{masterdata_id}", response_model=MasterDataRead)
async def patch_masterdata(
        masterdata_id: UUID,
        request: MasterDataUpdateRequest,
        session: DbSession,
) -> MasterData:
    """Update an existing masterdata data."""
    if request.name:
        request.name = request.name.strip()

    validate_masterdata_info(request)

    if masterdata_db := await get_masterdata_by_id(session, masterdata_id):
        return await update_masterdata(masterdata_db, request, session)

    raise HTTPException(status_code=404, detail="Masterdata not found")


@router.delete("/{masterdata_id}")
async def delete_masterdata(
        masterdata_id: UUID,
        session: DbSession,
) -> dict:
    """Delete a masterdata from the database."""
    stmt = select(MasterData).where(MasterData.id == masterdata_id).options(selectinload(MasterData.agent_flows))
    masterdata_db = (await session.exec(stmt)).first()
    if not masterdata_db:
        raise HTTPException(status_code=404, detail="Masterdata not found")
    
    # Prevent deletion of default masterdatas
    default_masterdatas = get_all_default_masterdata()
    default_masterdata_names = [masterdata["name"] for masterdata in (default_masterdatas)]
    if masterdata_db.name in default_masterdata_names:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete default masterdata '{masterdata_db.name}'. Default masterdatas are protected."
        )

    # Check if masterdata is being used by any AgentFlow
    if masterdata_db.agent_flows and len(masterdata_db.agent_flows) > 0:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete masterdata '{masterdata_db.name}'. It is currently used by {len(masterdata_db.agent_flows)} agent flow(s)."
        )

    await session.delete(masterdata_db)
    await session.commit()

    return {"detail": "Masterdata deleted"}