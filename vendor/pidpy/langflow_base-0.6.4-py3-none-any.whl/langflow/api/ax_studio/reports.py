import os
import json
import asyncio
from enum import Enum
from urllib.request import urlopen
from fastapi import APIRouter
from sqlalchemy import func, and_
from sqlmodel import select
from datetime import datetime, timezone
from langflow.api.utils import DbSession
from langflow.services.database.models.masterdata.model import MasterData
from langflow.services.database.models.masterdata.constants import SYSTEM_CONFIG_OPTIONS
from langflow.services.database.models.agent_flow.model import AgentFlow
from langflow.services.database.models.agent_flow.constants import AgentFlowStatus
from langflow.services.database.models.group.model import Group
from langflow.services.database.models.group.constants import DEFAULT_GROUP_NAME
from langflow.services.database.models.group.crud import get_all_groups

router = APIRouter(tags=["REPORTS"], prefix="/reports")


class TIMESPANS(Enum):
    DAY = "DAY"
    MONTH = "MONTH"
    YEAR = "YEAR"


@router.get("/get_cost_limit")
async def get_cost_limit(
        *,
        session: DbSession,
) -> dict:
    """Retrieve axstudio cost limit configuration."""

    # Get Group Cost Limit from masterdata
    query = select(MasterData).where(
        and_(
            MasterData.name == "Group Cost Limit",
            MasterData.type == "SYSTEM_CONFIG"
        )
    )
    result = await session.exec(query)
    masterdata = result.first()
    
    for option in SYSTEM_CONFIG_OPTIONS:
        if option["name"] == "Group Cost Limit":
            cost_limit = option["value"]["value"]
            break

    group_cost_limit = cost_limit
    if masterdata and masterdata.value and "value" in masterdata.value:
        group_cost_limit = masterdata.value["value"]

    return {
        "detail": {
            "group_cost_limit": group_cost_limit
        }
    }


@router.get("/get_overall_statistics")
async def get_overall_statistics(
        *,
        session: DbSession,
        group_id: str = "all",
        timespan: TIMESPANS = TIMESPANS.DAY,
) -> dict:
    """Retrieve axstudio overall statistics report"""

    url_args = f"/v1/overall_statistics?group_id={group_id}&timespan={timespan.value}"
    data = await _get_overall_statistics_get_data(session, url_args, group_id)
    
    phoenix_detail = data[0]
    overall_statistics = phoenix_detail.get("overall_statistics", {})
    overall_statistics.update({
        "registered_agent_flow": data[1].get("not_deleted_count") or 0,
        "active_agent_flow": data[1].get("approved_count") or 0,
    })

    return {
        "detail": phoenix_detail
    }


async def _get_overall_statistics_get_data(session, url_args, group_id: str = "all"):
    # Run the synchronous HTTP call in a thread pool to avoid blocking
    loop = asyncio.get_event_loop()
    phoenix_data_task = loop.run_in_executor(None, __get_data_from_phoenix, url_args)
    
    return await asyncio.gather(
        phoenix_data_task,
        _get_agent_flow_statistic(session, group_id),
    )


async def _get_agent_flow_statistic(session, group_id: str = "all"):
    """Return counts of agent flows.

    If group_id is not "all", filter counts by AgentFlow.group_id == group_id.
    Returns dict with integer counts for not_deleted_count and approved_count.
    """
    # Base conditions
    not_deleted_condition = AgentFlow.status != AgentFlowStatus.DELETED.value
    approved_condition = AgentFlow.status == AgentFlowStatus.APPROVED.value

    # Add group filter when requested. Convert incoming group_id to UUID when possible.
    if group_id and group_id != "all":
        # Accept UUID instance, string, or dict containing an id key.
        group_value = group_id
        try:
            # If a dict was passed (e.g. from malformed frontend), try common keys
            if isinstance(group_value, dict):
                # support {'id': '...'} or {'group_id': '...'}
                group_value = group_value.get("id") or group_value.get("group_id") or group_value

            # Try to coerce to UUID instance if possible
            from uuid import UUID as _UUID

            if isinstance(group_value, str):
                try:
                    group_value = _UUID(group_value)
                except Exception:
                    # keep as string fallback
                    pass
        except Exception:
            # any unexpected shape, keep original
            group_value = group_id

        not_deleted_query = select(func.count()).select_from(AgentFlow).where(
            and_(
                AgentFlow.group_id == group_value,
                not_deleted_condition,
            )
        )
        approved_query = select(func.count()).select_from(AgentFlow).where(
            and_(
                AgentFlow.group_id == group_value,
                approved_condition,
            )
        )
    else:
        not_deleted_query = select(func.count()).select_from(AgentFlow).where(not_deleted_condition)
        approved_query = select(func.count()).select_from(AgentFlow).where(approved_condition)

    # Execute and coerce to int with safe fallback
    not_deleted_raw = (await session.exec(not_deleted_query)).first()
    approved_raw = (await session.exec(approved_query)).first()

    try:
        not_deleted_count = int(not_deleted_raw) if not_deleted_raw is not None else 0
    except Exception:
        not_deleted_count = 0

    try:
        approved_count = int(approved_raw) if approved_raw is not None else 0
    except Exception:
        approved_count = 0

    return {
        "not_deleted_count": not_deleted_count,
        "approved_count": approved_count,
    }


@router.get("/get_projects_status")
async def get_projects_status(
        *,
        group_id: str = "all",
) -> dict:
    """Retrieve axstudio project status report"""

    url_args = f"/v1/projects_status?group_id={group_id}"
    # Run the synchronous HTTP call in a thread pool to avoid blocking
    loop = asyncio.get_event_loop()
    data = await loop.run_in_executor(None, __get_data_from_phoenix, url_args)

    return {
        "detail": data
    }


@router.get("/get_detail_analysis_by_projects")
async def get_detail_analysis_by_projects(
        *,
        group_id: str = "all",
) -> dict:
    """Retrieve axstudio detail analysis by projects report"""

    url_args = f"/v1/detail_analysis_by_projects?group_id={group_id}"
    # Run the synchronous HTTP call in a thread pool to avoid blocking
    loop = asyncio.get_event_loop()
    data = await loop.run_in_executor(None, __get_data_from_phoenix, url_args)

    return {
        "detail": data
    }


@router.get("/get_organization_wide_analytics")
async def get_organization_wide_analytics(
        *,
        session: DbSession,
) -> dict:
    """Retrieve axstudio organization wide analytics report."""
    url_args = f"/v1/organization_wide_analytics"
    data = await _get_organization_wide_analytics_get_data(session, url_args)

    # Map group_id to group name in top_3_token_usage_by_team
    phoenix_data = data[0]
    top_3_token_usage_by_team = phoenix_data.get("top_3_token_usage_by_team", [])
    
    # Get group mapping
    groups = await get_all_groups(session)
    group_mapping = {
        group.id: (group.name_kr or group.name)
        for group in groups
    }
    
    # Update team_name from group_id to actual group name
    for item in top_3_token_usage_by_team:
        group_id = item.get("team_name")
        if group_id and group_id in group_mapping:
            item["team_name"] = group_mapping[group_id]
    
    phoenix_data["top_3_token_usage_by_team"] = top_3_token_usage_by_team
    top_3_agent_flows_count_by_team = data[1]
    
    return {
        "detail": {
            **phoenix_data,
            "top_3_agent_flows_count_by_team": top_3_agent_flows_count_by_team
        }
    }


async def _get_organization_wide_analytics_get_data(session, url_args):
    # Run the synchronous HTTP call in a thread pool to avoid blocking
    loop = asyncio.get_event_loop()
    phoenix_data_task = loop.run_in_executor(None, __get_data_from_phoenix, url_args)
    
    return await asyncio.gather(
        phoenix_data_task,
        _get_top_3_agent_flows(session),
    )


async def _get_top_3_agent_flows(session: DbSession) -> list[dict]:
    # Calculate date ranges
    now = datetime.now(timezone.utc)
    current_month_start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    
    # Calculate previous month start
    if current_month_start.month == 1:
        previous_month_start = current_month_start.replace(year=current_month_start.year - 1, month=12)
    else:
        previous_month_start = current_month_start.replace(month=current_month_start.month - 1)
    
    # Get all active groups with their agent flow counts
    groups_query = select(Group).where(Group.is_active == True and Group.name != DEFAULT_GROUP_NAME)
    groups = (await session.exec(groups_query)).fetchall()
    
    analytics = []
    
    for group in groups:
        # Count current month registrations (not deleted)
        current_month_query = select(func.count()).select_from(AgentFlow).where(
            and_(
                AgentFlow.group_id == group.id,
                AgentFlow.status != AgentFlowStatus.DELETED.value,
                AgentFlow.create_at >= current_month_start
            )
        )
        current_month_count = (await session.exec(current_month_query)).first() or 0
        
        # Count previous month registrations (not deleted)
        previous_month_query = select(func.count()).select_from(AgentFlow).where(
            and_(
                AgentFlow.group_id == group.id,
                AgentFlow.status != AgentFlowStatus.DELETED.value,
                AgentFlow.create_at >= previous_month_start,
                AgentFlow.create_at < current_month_start
            )
        )
        previous_month_count = (await session.exec(previous_month_query)).first() or 0
        
        # Calculate comparison
        difference = current_month_count - previous_month_count
        compare_str = f"+{difference}" if difference > 0 else "0"
        
        # Only include groups that have registrations
        if current_month_count > 0 or previous_month_count > 0:
            analytics.append({
                "team_name": group.name_kr or group.name,
                "agent_flow_count": str(current_month_count),
                "compare_to_last_month": compare_str,
            })
    
    # Sort by current count (descending)
    analytics.sort(key=lambda x: int(x["agent_flow_count"]), reverse=True)

    return analytics


def __get_data_from_phoenix(url_args: str) -> dict:
    phoenix_host = os.getenv("ARIZE_PHOENIX_HOST", "localhost")
    phoenix_port = os.getenv("ARIZE_PHOENIX_PORT", "6006")
    url = f"http://{phoenix_host}:{phoenix_port}{url_args}"
    
    try:
        with urlopen(url) as response:
            if response.status == 200:
                data = response.read()
                return json.loads(data).get("detail", {})
            else:
                print(f"Failed to retrieve data, status code: {response.status}")
                return {}
    except Exception as e:
        print(f"Exception: {str(e)}")
        return {}
