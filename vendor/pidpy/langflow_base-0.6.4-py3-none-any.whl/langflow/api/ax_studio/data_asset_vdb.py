from uuid import UUID
from typing import Optional
import asyncio

from fastapi import APIRouter, HTTPException
from sqlalchemy.exc import IntegrityError
from sqlmodel import select

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.services.database.models.datasource.model import Datasource
from langflow.services.database.models.datasource.crud import get_data_asset_by_id
from langflow.services.database.models.user_group.crud import get_one_membership_by_user_id
from langflow.services.database.models.datasource.constants import DataAssetType
from langflow.services.database.models.data_asset_vdb import (
    DataAssetConnectionVdb,
    DataAssetConnectionVdbCreate,
    DataAssetConnectionVdbRead,
    DataAssetConnectionVdbUpdate,
    get_vdb_config_by_data_asset_id,
    update_data_asset_vdb,
    delete_data_asset_vdb,
)
from langflow.services.database.models.data_asset_vdb.model import (
    VDBConnectionConf,
)
from langflow.services.vdb_connector.service import get_vdb_connector, VDBMetadata
from langflow.api.ax_studio.schemas import (
    VDBConnectionConfOrDataAsset,
)

from langflow.services.database.models.resource_permission.crud import create_resource_permission
from langflow.services.database.models.resource_permission.constants import ResourceTypes
from langflow.services.database.models.recent_activity.crud import add_recent_activity
from langflow.services.database.models.recent_activity.model import ActivityItemTypeEnum, ActivityTypeEnum
from langflow.services.database.models.datasource_history.constants import DatasourceHistoryAction
from langflow.services.database.models.datasource_history.crud import create_datasource_history

router = APIRouter(tags=["DATA_ASSET_VDB"], prefix="/data_asset_vdb")


@router.post("/", response_model=dict, status_code=201)
async def create_vdb_config(
        request: DataAssetConnectionVdbCreate,
        user: CurrentActiveUser,
        session: DbSession,
) -> dict:
    """Create a new VDB configuration along with its datasource.
    
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    membership = await get_one_membership_by_user_id(session, user.id)
    if not membership:
        raise ValueError("User must belong to a group to create an MCP server")

    # Validate datasource type is a VDB type
    vdb_types = [DataAssetType.CHROMADB, DataAssetType.MILVUS, DataAssetType.QDRANT]
    if request.datasource_type not in vdb_types:
        raise HTTPException(
            status_code=400,
            detail=f"Datasource type must be one of: {', '.join([vdb.value for vdb in vdb_types])}"
        )

    try:
        # Create Datasource first
        datasource = Datasource(
            name=request.name,
            description=request.description,
            datasource_type=request.datasource_type,
            is_active=True,
            group_id=membership.group_id,
            create_by=user.id,
        )
        # datasource.update_search_field()
        session.add(datasource)
        await session.flush()  # Flush to get the datasource.id

        # Create VDB configuration linked to the datasource
        new_vdb_config = DataAssetConnectionVdb(
            data_source_id=datasource.id,
            host=request.host,
            port=request.port,
            uri=request.uri,
            database_name=request.database_name,
            api_key=request.api_key,
            tenant_id=request.tenant_id,
            cached_metadata=request.cached_metadata,
        )
        session.add(new_vdb_config)
        
        # Commit both in a single transaction
        await session.commit()
        await session.refresh(datasource)
        await session.refresh(new_vdb_config)

        # Create history record (REVIEW_REQUESTED = newly created)
        await create_datasource_history(session, DatasourceHistoryAction.REVIEW_REQUESTED, user.id, datasource)

        # Create recent activity record
        await add_recent_activity(
            session=session,
            user_id=user.id,
            activity_type=ActivityTypeEnum.CREATED,
            item_id=datasource.id,
            item_type=ActivityItemTypeEnum.DATA_ASSET,
            title=f"{datasource.name}",
            description=f"{datasource.description or ''}",
        )

        await session.commit()

        # Build response
        response_data = datasource.model_dump()
        response_data["config"] = None
        if new_vdb_config:
            response_data["config"] = new_vdb_config.model_dump()
        
        return response_data
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(
            status_code=400,
            detail="Failed to create datasource and VDB configuration. Datasource name may already exist."
        ) from e
    except Exception as e:
        await session.rollback()
        raise HTTPException(
            status_code=400,
            detail=f"Failed to create datasource and VDB configuration: {str(e)}"
        ) from e


# @router.get("/list_collections")
async def list_collections(
        datasource_type: DataAssetType,
        host: Optional[str] = None,
        port: Optional[int] = None,
        uri: Optional[str] = None,
        database_name: Optional[str] = None,
        api_key: Optional[str] = None,
        tenant_id: Optional[str] = None,
) -> dict:
    """List collections in a VDB using provided credentials.
    """
    # Validate datasource type is a VDB type
    vdb_types = [DataAssetType.CHROMADB, DataAssetType.MILVUS, DataAssetType.QDRANT]
    if datasource_type not in vdb_types:
        raise HTTPException(
            status_code=400,
            detail=f"Datasource type must be one of: {', '.join([vdb.value for vdb in vdb_types])}"
        )

    try:
        # Create connection object based on VDB type
        connection = None
        connection = VDBConnectionConf(
            host=host,
            port=port,
            database_name=database_name,
            tenant_id=tenant_id,
            uri=uri,
            api_key=api_key,
        )

        # Get connector service
        connector = get_vdb_connector(datasource_type, connection)

        # Try to connect
        await connector.connect()

        # Try to list collections to verify connection works
        collections = await connector.list_tables()

        # Disconnect
        await connector.disconnect()

        return {
            "total_count": len(collections),
            "collections": collections
        }

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Connection test failed: {str(e)}"
        ) from e



@router.post("/fetch_metadata")
async def get_metadata(
        request: VDBConnectionConfOrDataAsset,
        session: DbSession,
        test_connection: bool = False,
) -> dict:
    """
    Get metadata for all collections in the VDB.
    Connects to VDB, lists all collections, and retrieves metadata for each collection.

    Response format:
    ```
    {
        "data_source_type": DataAssetType,
        "total_collections": 0,
        "collections": [
            {
                "collection_name": "string",
                "n_dimensions": 0,
                "distance_metric": "string",
                "n_rows": 0,
                "embedding_model": "string",
            }
        ],
    }
    ```
    """
    try:
        data_asset_id = request.datasource_id
        if data_asset_id:
            # Get the datasource
            data_asset = await get_data_asset_by_id(session, data_asset_id)

            # Get VDB configuration
            vdb_config = await get_vdb_config_by_data_asset_id(session, data_asset_id)
            if not vdb_config:
                raise HTTPException(status_code=404, detail="VDB configuration not found")

            # Create connection object based on VDB type
            connection = VDBConnectionConf(
                host=vdb_config.host,
                port=vdb_config.port,
                database_name=vdb_config.database_name,
                uri=vdb_config.uri,
                api_key=vdb_config.api_key,
                tenant_id=vdb_config.tenant_id,
            )
            data_asset_type = data_asset.datasource_type
        else:
            config = request.connection_config
            # Use connection info from request
            connection = VDBConnectionConf(
                host=config.host,
                port=config.port,
                database_name=config.database_name,
                uri=config.uri,
                api_key=config.api_key,
                tenant_id=config.tenant_id,
            )
            data_asset_type = request.datasource_type

        # Get connector service
        connector = get_vdb_connector(data_asset_type, connection)

        # Connect to VDB
        await connector.connect()

        # List all collections
        collections = await connector.list_tables()

        if test_connection:
            # Just testing connection, return collection names
            await connector.disconnect()
            return {
                "data_source_type": data_asset_type,
                "total_collections": len(collections),
                "collections": collections,
            }

        # Get metadata for each collection using asyncio.gather for concurrent fetching
        async def fetch_metadata(collection_name: str):
            try:
                metadata = await connector.get_table_metadata(collection_name)
                return metadata.to_dict()
            except Exception as e:
                # If we can't get metadata for a collection, log it and continue
                return {
                    "collection_name": collection_name,
                    "error": str(e)
                }
        
        collections_metadata = list(await asyncio.gather(*[fetch_metadata(name) for name in collections]))

        # Disconnect
        await connector.disconnect()
        
        if data_asset_id:
            # Update cached metadata in database
            vdb_update = DataAssetConnectionVdbUpdate(
                cached_metadata={
                    "total_collections": len(collections),
                    "collections": collections_metadata
                }
            )
            await update_data_asset_vdb(vdb_config, vdb_update, session)

        return {
            "data_source_type": data_asset_type,
            "total_collections": len(collections),
            "collections": collections_metadata,
        }

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Failed to fetch metadata: {str(e)}"
        ) from e


# @router.get("/{datasource_id}", response_model=DataAssetConnectionVdbRead)
async def get_vdb_config(
        datasource_id: UUID,
        session: DbSession,
) -> DataAssetConnectionVdb:
    """Get VDB configuration for a datasource."""
    vdb_config = await get_vdb_config_by_data_asset_id(session, datasource_id)
    if not vdb_config:
        raise HTTPException(status_code=404, detail="VDB configuration not found")

    return vdb_config


# @router.put("/{datasource_id}", response_model=DataAssetConnectionVdbRead)
async def update_vdb_config(
        datasource_id: UUID,
        request: DataAssetConnectionVdbUpdate,
        session: DbSession,
        user: CurrentActiveUser,
) -> DataAssetConnectionVdb:
    """Update VDB configuration for a datasource."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    vdb_config = await get_vdb_config_by_data_asset_id(session, datasource_id)
    if not vdb_config:
        raise HTTPException(status_code=404, detail="VDB configuration not found")

    return await update_data_asset_vdb(vdb_config, request, session)


# @router.delete("/{datasource_id}")
async def delete_vdb_config(
        datasource_id: UUID,
        session: DbSession,
        user: CurrentActiveUser,
) -> dict:
    """Delete VDB configuration for a datasource."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    vdb_config = await get_vdb_config_by_data_asset_id(session, datasource_id)
    if not vdb_config:
        raise HTTPException(status_code=404, detail="VDB configuration not found")

    await delete_data_asset_vdb(vdb_config, session)
    return {"detail": "VDB configuration deleted"}
    