"""RAG upload endpoints for vector database operations."""

import asyncio
import os
import io
from datetime import datetime, timezone
from typing import Annotated, Optional, Dict
from uuid import UUID, uuid4

import logging
import sys
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Avoid adding duplicate handlers if module is reloaded
if not logger.handlers:
    _handler = logging.StreamHandler(sys.stdout)  # Force output to stdout
    _handler.setLevel(logging.INFO)
    _formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - [%(threadName)s] - %(message)s'
    )
    _handler.setFormatter(_formatter)
    logger.addHandler(_handler)

# Ensure propagation is enabled (so root logger also sees it if configured)
logger.propagate = True


from fastapi import APIRouter, File, Form, HTTPException, UploadFile, Query, status
from sqlalchemy import and_, asc, desc, func, or_
from sqlmodel import select
from sqlalchemy.orm import selectinload
from chromadb.errors import InvalidArgumentError
from chromadb.utils.embedding_functions import OpenAIEmbeddingFunction
from minio import Minio


from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.services.database.models.vdb_upload_history import (
    VdbUploadHistory,
    VdbUploadHistoryCreate,
    VdbUploadHistoryRead,
    VdbUploadHistoryUpdate,
    VdbUploadHistoryReview,
    VdbUploadType,
    VdbUploadStatus
)
from langflow.services.database.models.vdb_upload_history.crud import (
    create_vdb_upload_history,
    get_vdb_upload_history_by_id,
    update_vdb_upload_history,
    delete_vdb_upload_history,
    get_vdb_upload_history_by_collection_name,
)
from langflow.services.deps import get_task_service
from langflow.services.rag_upload.task_func import (
    process_and_upload_documents,
    process_and_upload_raw_vectors,
    delete_vectors_from_collection,
    get_chromadb_client,
)
from langflow.services.rag_upload.task_func_2_csv_file import (
    process_and_upload_csv_file,
    create_record_in_vdb_upload_history,
)
from langflow.services.rag_upload.utils import convert_string_to_dict

from langflow.services.rag_upload.enums import BasicMetadtaColumns, ModelEmbeddingMetadata, VdbUploadStatusFields

from langflow.services.database.models.resource_permission.crud import create_resource_permission, delete_resource_permissions_by_resource_id
from langflow.services.database.models.resource_permission.constants import ResourceTypes
from langflow.services.database.models.resource_permission.model import ResourcePermission

from langflow.services.database.models.user_group.crud import get_one_membership_by_user_id, get_membership_by_user_id_and_group_id
from langflow.services.database.models.user_group.model import UserGroup
from langflow.services.rag_upload.enums import BasicMetadtaColumns, ModelEmbeddingMetadata, FileMetadataFields
from langflow.services.rag_upload.utils import *
from langflow.api.ax_studio.omnipotent_access_granter_2000 import has_permission, PermCheckActionEnum
from langflow.services.database.models.vdb_upload_action_history.constants import VdbUploadActionHistoryAction
from langflow.services.database.models.vdb_upload_action_history.crud import create_vdb_upload_action_history
from langflow.services.database.models.recent_activity.crud import add_recent_activity
from langflow.services.database.models.recent_activity.model import ActivityItemTypeEnum, ActivityTypeEnum
from langflow.services.database.minio.connection import get_minio_connection
from langflow.services.database.minio.enums import MinioBucket


router = APIRouter(tags=["RAG_UPLOAD"], prefix="/rag_upload")


def _build_preview_presigned_url(minio_conn: Minio, object_name: str) -> str:
    """Build a presigned URL with inline response headers for browser preview."""
    file_name = object_name.rsplit("/", maxsplit=1)[-1]
    return minio_conn.presigned_get_object(
        bucket_name=MinioBucket.LANGFLOW,
        object_name=object_name,
        response_headers={
            "response-content-type": "application/pdf",
            "response-content-disposition": f'inline; filename="{file_name}"',
        },
    )


async def update_upload_status(
    upload_id: UUID,
    task_id,
    task_service,
):
    """Update the status of a VdbUploadHistory entry using a fresh DB session."""
    from langflow.services.deps import session_scope

    while True:
        await asyncio.sleep(30)
        task = await task_service.get_task(task_id)
        if task.status != "PENDING":
            task_status = {
                "status": task.status,
                "result": task.result,
                "error": task.error_message,
                "traceback": task.traceback,
            }
            update_data = VdbUploadHistoryUpdate(
                status=VdbUploadStatus.PENDING if task.status == "SUCCESS" else VdbUploadStatus.UPLOAD_FAILED,
                task_id=task_id,
                task_status=task_status
            )
            async with session_scope() as session:
                await update_vdb_upload_history(session, upload_id, update_data)
            break


@router.get("/get_task/{task_id}", response_model=dict, status_code=200)
async def get_task_status(task_id: str):
    
    task_service = get_task_service()
    task = await task_service.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return {
        "task_id": task_id,
        "status": task.status,
        "result": task.result,
        "error": task.error_message,
        "traceback": task.traceback
    }


@router.post("/add_vectors", response_model=dict, status_code=202)
async def add_vectors(
    files: Annotated[list[UploadFile], File(description="Multiple files to upload")],
    collection_name: Annotated[str, Form(description="Name of the collection")],
    name: Annotated[str, Form(description="Name for this upload")] = None,
    description: Annotated[str, Form(description="Description of this upload")] = None,
    user: CurrentActiveUser = None,
    session: DbSession = None,
) -> dict:
    return await add_documents(
        files=files,
        collection_name=collection_name,
        name=name,
        description=description,
        user=user,
        session=session,
        upload_type=VdbUploadType.RAW_VECTOR,
    )


@router.post("/add_documents", response_model=dict)
async def add_documents(
    files: Annotated[list[UploadFile], File(description="Multiple files to upload")],
    collection_name: Annotated[str, Form(description="Name of the collection")],
    name: Annotated[str, Form(description="Name for this upload")],
    description: Annotated[str, Form(description="Description of this upload")] = None,
    chunk_size: Annotated[int, Form(description="Chunk size for document splitting")] = 500,
    overlap: Annotated[int, Form(description="Overlap size for document splitting")] = 50,
    embedding_model_name: Annotated[Optional[str], Form(description="Name of the embedding model used")] = None,
    # csv_config: Annotated[Optional[dict], Form(description="CSV configuration")] = None,
    user: CurrentActiveUser = None,
    session: DbSession = None,
    upload_type: Annotated[VdbUploadType, Form(description="Type of upload: DOCUMENT or RAW_VECTOR")] = VdbUploadType.DOCUMENT,
) -> dict:
    """Add documents to vector database with background processing.
    
    This endpoint:
    - Accepts multiple upload files and a collection name
    - Uses OpenAI text-embedding-3-small for embeddings
    - Vectorizes and uploads to ChromaDB
    - Runs as a background task
    - Creates an entry in VdbUploadHistory with PENDING status
    
    Args:
        files: List of files to upload
        collection_name: Name of the ChromaDB collection
        name: Name for this upload entry
        description: Description of this upload
        user: Current authenticated user
        session: Database session
        
    Returns:
        dict: Upload ID and status message
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    if not files:
        raise HTTPException(status_code=400, detail="No files provided")

    membership = await get_one_membership_by_user_id(session, user.id)
    if not membership:
        raise ValueError("User must belong to a group to create ChromaDB collection")
    
    # generate task_id 
    task_id = str(uuid4())

    # creating embedding function
    embedding_function = OpenAIEmbeddingFunction(
        api_key=os.getenv("OPENAI_EMB_API_KEY"),
        model_name=embedding_model_name,
    )

    # Create collections in vectorDB (Validate collection name)
    try:
        chroma_client = get_chromadb_client()
        chroma_client.get_or_create_collection(
            name=collection_name,
            embedding_function=embedding_function,
        )
    except InvalidArgumentError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # check group_id and model_name of the collection name
    record = await get_vdb_upload_history_by_collection_name(
        db=session,
        collection_name=collection_name,
    )

    if record and record.group_id != membership.group_id:
        msg = "Collection_name are created in different group."
        raise HTTPException(status_code=403, detail=msg)

    if record and record.embedding_model_name != embedding_model_name:
        msg = f"Current embedding model {embedding_model_name} is not same with the previous {record.embedding_model_name}"
        raise HTTPException(status_code=400, detail=msg)

    # Calculate file metadata
    total_count = len(files)
    file_details = []

    # create minio connection
    logger.info("Establishing connection to MinIO server...")
    minio_conn: Minio = get_minio_connection()    
    
    for file in files:
        # Read file to get size (we'll need to reset the file pointer)
        content = await file.read()

        # detect file type and prepare original storage path
        file_type = detech_file_type(file.filename)
        if file_type == "doc":
            # preparing paths
            original_path = preparing_original_path_for_doc_file(file_name=file.filename, group_id=membership.group_id)
            preview_path = preparing_preview_path_for_doc_file(file_name=file.filename, group_id=membership.group_id)
            
            # convert content
            converted_content = convert_doc_content_to_pdf_object(content)
            
            # store in MinIO
            minio_conn.put_object(
                bucket_name=MinioBucket.LANGFLOW,
                object_name=preview_path,
                data=io.BytesIO(converted_content),
                length=len(converted_content),
            )
            minio_conn.put_object(
                bucket_name=MinioBucket.LANGFLOW,
                object_name=original_path,
                data=io.BytesIO(content),
                length=len(content),
            )

        elif file_type == "pdf":
            original_path = preparing_original_path_for_pdf_file(file_name=file.filename, group_id=membership.group_id)
            preview_path = original_path  # For PDF, we can use the same file as preview
            minio_conn.put_object(
                bucket_name=MinioBucket.LANGFLOW,
                object_name=original_path,
                data=io.BytesIO(content),
                length=len(content),
            )

        elif file_type == "text":
            # preparing paths 
            original_path = preparing_original_path_for_text_file(file_name=file.filename, group_id=membership.group_id)
            preview_path = preparing_preview_path_for_text_file(file_name=file.filename, group_id=membership.group_id)
            
            # convert content
            converted_content = convert_text_content_to_pdf_object(content)
            
            # store in minio
            minio_conn.put_object(
                bucket_name=MinioBucket.LANGFLOW,
                object_name=preview_path,
                data=io.BytesIO(converted_content),
                length=len(converted_content),
            )
            minio_conn.put_object(
                bucket_name=MinioBucket.LANGFLOW,
                object_name=original_path,
                data=io.BytesIO(content),
                length=len(content),
            )


        file_size = len(content)
        await file.seek(0)  # Reset file pointer
        
        file_details.append({
            BasicMetadtaColumns.NAME: file.filename,
            BasicMetadtaColumns.SIZE: file_size,
            BasicMetadtaColumns.ORIGINAL_STORAGE_URL: original_path,
            BasicMetadtaColumns.PREVIEW_STORAGE_URL: preview_path,
            BasicMetadtaColumns.TYPE: file_type,

        })
    
    file_metadata = {
        FileMetadataFields.TOTAL_COUNT: total_count,
        FileMetadataFields.FILES: file_details,
    }
    
    # print("Insert record into VdbUploadHistory with metadata:", file_metadata)
    # Create upload history entry with PENDING status
    upload_create = VdbUploadHistoryCreate(
        name=collection_name,
        description=description or f"{total_count} files",
        collection_name=collection_name,
        upload_type=upload_type,
        created_by=user.id,
        file_metadata=file_metadata,
        embedding_model_name=embedding_model_name,
        group_id=membership.group_id,
        status=VdbUploadStatus.UPLOADING,
    )
    
    upload_history = await create_vdb_upload_history(session, upload_create)    

    # collection_name = str(upload_history.id)
    
    # Read all file contents as bytes before passing to background task
    file_data = []
    for file in files:
        await file.seek(0)
        content_bytes = await file.read()
        file_data.append({
            "filename": file.filename,
            "content": content_bytes
        })
    
    # Launch background task
    task_service = get_task_service()
    if upload_type == VdbUploadType.DOCUMENT:    
        task_id, task_result = await task_service.launch_task(
            process_and_upload_documents,
            file_data=file_data,
            collection_name=collection_name,
            upload_history_id=upload_history.id,
            chunk_size=chunk_size,
            overlap=overlap,
            model=embedding_model_name,
        )
    elif upload_type == VdbUploadType.RAW_VECTOR:
        task_id, task_result = await task_service.launch_task(
            process_and_upload_raw_vectors,
            file_data=file_data,
            collection_name=collection_name,
            upload_history_id=upload_history.id,
        )

    await task_service.launch_task(
        update_upload_status,
        upload_history.id, task_id, task_service
    )
    
    # Update upload history with task_id
    update_data = VdbUploadHistoryUpdate(
        task_id=task_id, 
        collection_name=collection_name
    )
    await update_vdb_upload_history(session, upload_history.id, update_data)

    await create_vdb_upload_action_history(session, VdbUploadActionHistoryAction.REVIEW_REQUESTED, user.id, upload_history)

    await add_recent_activity(
        session=session,
        user_id=user.id,
        activity_type=ActivityTypeEnum.CREATED,
        item_id=upload_history.id,
        item_type=ActivityItemTypeEnum.DATA_ASSET,
        title=f"{upload_history.name}",
        description=f"{upload_history.description or ''}",
    )

    await session.commit()
    return {
        "upload_id": str(upload_history.id),
        "task_id": task_id,
        "status": task_result.status,
        "message": f"Started processing {total_count} file(s) for collection '{collection_name}'",
    }


@router.post("/add_document/csv", response_model=dict)
async def add_csv_file(
    file: Annotated[UploadFile, File(description="Uploading CSV file")],
    collection_name: Annotated[str, Form(description="Name of the collection")],
    content_column: Annotated[str, Form(description="Name of content column in CSV file")],
    overlap: Annotated[int, Form(description="Overlap for chunking")],
    chunk_size: Annotated[int, Form(description="Chunk size for processing")],
    description: Annotated[str, Form(description="Description of this upload")] = None,
    model_name: Annotated[str, Form(description="Embedding model name")] = "text-embedding-3-small",
    metadata_columns: Annotated[list[str], Form(description="Additional metadata")] = None,
    custom_metadata: Annotated[str | None, Form(description="Custom metadata as JSON string")] = None,
    user: CurrentActiveUser = None,
    session: DbSession = None,
):
    # check permissions and file
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    if not file:
        raise HTTPException(status_code=400, detail="No file provided")

    if not file.filename or not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")

    membership = await get_one_membership_by_user_id(session, user.id)
    if not membership:
        raise ValueError("User must belong to a group to create ChromaDB collection")
    
    # generate task_id 
    task_id = str(uuid4())

    # creating embedding function
    embedding_function = OpenAIEmbeddingFunction(
        api_key=os.getenv("OPENAI_EMB_API_KEY"),
        model_name=model_name,
    )

    # Create collections in vectorDB (Validate collection name)
    try:
        chroma_client = get_chromadb_client()
        chroma_client.get_or_create_collection(
            name=collection_name,
            embedding_function=embedding_function,
        )
    except InvalidArgumentError as e:
        raise HTTPException(status_code=400, detail=str(e))

    # check group_id and model_name of the collection name
    record = await get_vdb_upload_history_by_collection_name(
        db=session,
        collection_name=collection_name,
    )

    if record and record.group_id != membership.group_id:
        msg = "Collection_name are created in different group."
        raise HTTPException(status_code=403, detail=msg)

    if record and record.embedding_model_name != model_name:
        msg = f"Current embedding model {model_name} is not same with the previous {record.embedding_model_name}"
        raise HTTPException(status_code=400, detail=msg)


    # reading content of the file as bytes to pass to background task
    content_bytes = await file.read()

    # create connection to minio
    logger.info("Establishing connection to MinIO server...")
    minio_conn: Minio = get_minio_connection()
    
    # prepare original store path for the uploaded file
    logger.info("Preparing storage paths for the uploaded file...")
    original_path = preparing_original_path_for_csv_file(group_id=membership.group_id, file_name=file.filename)
    
    logger.info(f"Original storage path prepared: {original_path}")
    preview_path = preparing_preview_path_for_csv_file(group_id=membership.group_id, file_name=file.filename)

    # convert file to pdf
    logger.info("Converting CSV file to PDF format for preview...")
    pdf_content = convert_text_content_to_pdf_object(content_bytes)

    # upload to minio
    logger.info("Uploading original file and preview to MinIO...")
    try:
        minio_conn.put_object(
            bucket_name=MinioBucket.LANGFLOW,
            object_name=original_path,
            data=io.BytesIO(content_bytes),
            length=len(content_bytes),
        )

        minio_conn.put_object(
            bucket_name=MinioBucket.LANGFLOW,
            object_name=preview_path,
            data=io.BytesIO(pdf_content),
            length=len(pdf_content),
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload file to storage: {str(e)}")
    logger.info("File upload to MinIO completed successfully.")
    # Parse custom_metadata JSON string
    custom_metadata, msg = convert_string_to_dict(custom_metadata)
    if custom_metadata is False:
        raise HTTPException(status_code=422, detail=msg)

    # create a record in VDB upload history with status 'UPLOADING'
    record, msg = await create_record_in_vdb_upload_history(
        db=session,
        file_name=file.filename,
        description=description,
        collection_name=collection_name,
        embedding_model_name=model_name,
        original_storage_url=original_path,
        preview_storage_url=preview_path,
        user_id=user.id,
        group_id=membership.group_id,
        task_id=task_id,
        size=len(content_bytes),
        status=VdbUploadStatus.UPLOADING.value,
        task_status={}
    )

    # Convert metadata list of column names to dict, then enrich with system fields
    logger.info("Preparing metadata for the uploaded file...")
    custom_metadata[BasicMetadtaColumns.NAME] = file.filename
    custom_metadata[BasicMetadtaColumns.TYPE] = "csv"
    custom_metadata[BasicMetadtaColumns.ORIGINAL_STORAGE_URL] = original_path
    custom_metadata[BasicMetadtaColumns.PREVIEW_STORAGE_URL] = preview_path
    custom_metadata[BasicMetadtaColumns.UPLOAD_DATE] = datetime.now(timezone.utc).isoformat()
    custom_metadata[BasicMetadtaColumns.UPLOAD_USER] = user.username
    custom_metadata[BasicMetadtaColumns.DESCRIPTION] = description
    custom_metadata[ModelEmbeddingMetadata.MODEL_NAME] = model_name
    custom_metadata[ModelEmbeddingMetadata.CHUNK_SIZE] = chunk_size
    custom_metadata[ModelEmbeddingMetadata.CHUNK_OVERLAP] = overlap
    custom_metadata[BasicMetadtaColumns.UPLOAD_HISTORY_ID] = str(record.id)

    logger.info(f"Preparing custom_metadata: {custom_metadata}")


    if not record:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
            detail=f"Failed to create upload history record: {msg}"
        )

    # Start and lunch background task
    task_service = get_task_service()
    await task_service.launch_task(
        process_and_upload_csv_file,
        file_content=content_bytes,
        content_column=content_column,
        overlap=overlap,
        chunk_size=chunk_size,
        embedding_model_name=model_name,
        collection_name=collection_name,
        metadata_columns=metadata_columns,
        task_id=task_id,
        record_id=record.id,
        custom_metadata=custom_metadata,
    )

    await create_resource_permission(session, {
        "user_id": [user.id],
        "resource_id": [record.id],
        "resource_type": ResourceTypes.SELF_HOSTED_VDB,
        "has_read_permission": True,
    }, user)

    await create_vdb_upload_action_history(session, VdbUploadActionHistoryAction.REVIEW_REQUESTED, user.id, record)

    await add_recent_activity(
        session=session,
        user_id=user.id,
        activity_type=ActivityTypeEnum.CREATED,
        item_id=record.id,
        item_type=ActivityItemTypeEnum.DATA_ASSET,
        title=f"{record.name}",
        description=f"{record.description or ''}",
    )

    await session.commit()

    return {
        "upload_id": str(record.id),
        "task_id": task_id,
        "status": {
            VdbUploadStatusFields.STATUS: VdbUploadStatus.UPLOADING.value,
            VdbUploadStatusFields.MESSAGE: None,
        },
        "message": f"Started processing file {file.filename} for collection '{collection_name}'",
    }


@router.get("/history", response_model=dict, status_code=200)
async def list_upload_history(
    session: DbSession,
    user: CurrentActiveUser,
    sort_by: str = Query("created_at", description="Field to sort by"),
    sort_direction: str = Query("desc", description="Sort direction: 'asc' or 'desc'"),
    status_filter: list[VdbUploadStatus] | None = Query(None, description="Filter by status"),
    search: Optional[str] = Query(None, description="Search in name or description"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(10, ge=1, le=100, description="Items per page"),
    filter_by_permission: bool = Query(False, description="Filter by user permissions"),
    group_ids: list[UUID] | None = Query(None, description="Filter by group IDs (multiple, superuser only)"),
) -> dict:
    """List document upload history with pagination and filtering.
    
    Args:
        session: Database session
        user: Current authenticated user
        sort_by: Field to sort by (default: created_at)
        sort_direction: Sort direction - 'asc' or 'desc' (default: desc)
        status_filter: Optional status filter
        search: Optional search term for name/description
        page: Page number (default: 1)
        page_size: Number of items per page (default: 10, max: 100)
        
    Returns:
        dict: Paginated list of upload history with metadata

    **Permission Logic:**
    - if is_superuser:
        + if group_ids is not None: filter_by group_ids
        + else: no group filter (get all)
    - else: filter_by current user's group_id
    - On top of filtering by group_id(s), also filter by ResourcePermission if filter_by_permission is True.
    """

    ### Why not use get_vdb_upload_history_list from crud.py?

    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    # Build base query
    query = select(VdbUploadHistory).options(
        selectinload(VdbUploadHistory.creator)
    ).where(
        # VdbUploadHistory.created_by == user.id
    )
    count_query = select(func.count()).select_from(VdbUploadHistory).where(
        # VdbUploadHistory.created_by == user.id
    )
    status_count_query = select(VdbUploadHistory.status, func.count()).select_from(VdbUploadHistory).where(
        # VdbUploadHistory.created_by == user.id
    ).group_by(VdbUploadHistory.status)

    is_superuser = getattr(user, "is_superuser", False)
    # get_by_membership
    if is_superuser:
        if group_ids:
            query = query.where(VdbUploadHistory.group_id.in_(group_ids))
            count_query = count_query.where(VdbUploadHistory.group_id.in_(group_ids))
            status_count_query = status_count_query.where(VdbUploadHistory.group_id.in_(group_ids))
    else:
        _ug_join = (UserGroup.group_id == VdbUploadHistory.group_id) & (UserGroup.user_id == user.id)
        query = query.join(UserGroup, _ug_join)
        count_query = count_query.join(UserGroup, _ug_join)
        status_count_query = status_count_query.join(UserGroup, _ug_join)
        if group_ids:
            query = query.where(VdbUploadHistory.group_id.in_(group_ids))
            count_query = count_query.where(VdbUploadHistory.group_id.in_(group_ids))
            status_count_query = status_count_query.where(VdbUploadHistory.group_id.in_(group_ids))
    
    # Permission Logic block
    if filter_by_permission:
        query = query.outerjoin(
                ResourcePermission,
                (ResourcePermission.resource_id == VdbUploadHistory.id) &
                (ResourcePermission.resource_type == ResourceTypes.SELF_HOSTED_VDB) &
                (ResourcePermission.has_read_permission == True) &
                (ResourcePermission.user_id == user.id),
            ).where(
                (VdbUploadHistory.created_by == user.id)
                | (
                    (VdbUploadHistory.status == VdbUploadStatus.APPROVED)
                    & (ResourcePermission.resource_id != None)
                )
            )
    
    # Apply filters
    if status_filter:
        query = query.where(VdbUploadHistory.status.in_(status_filter))
        count_query = count_query.where(VdbUploadHistory.status.in_(status_filter))
    
    if search:
        search_pattern = f"%{search}%"
        search_condition = or_(
            VdbUploadHistory.name.ilike(search_pattern),
            VdbUploadHistory.description.ilike(search_pattern),
        )
        query = query.where(search_condition)
        count_query = count_query.where(search_condition)
        status_count_query = status_count_query.where(search_condition)
    
    # Apply sorting
    sort_column = getattr(VdbUploadHistory, sort_by, VdbUploadHistory.created_at)
    if sort_direction.lower() == "asc":
        query = query.order_by(asc(sort_column))
    else:
        query = query.order_by(desc(sort_column))
    
    # Get total count
    total_count_result = await session.exec(count_query)
    total_count = total_count_result.one()
    
    # Get status counts
    status_count_result = await session.exec(status_count_query)
    status_counts = {status: 0 for status in VdbUploadStatus}
    status_counts |= {status: count for status, count in status_count_result.all()}
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    results = await session.exec(query)
    upload_histories = results.all()

    minio_conn: Minio | None = None
    try:
        minio_conn = get_minio_connection()
    except Exception as exc:
        logger.warning(f"Failed to initialize MinIO client for presigned URLs: {exc}")
    
    # Convert to response format
    items = []
    for history in upload_histories:
        history_data = history.model_dump()

        if minio_conn and history_data.get("file_metadata") and history_data["file_metadata"].get("files"):
            for metadata in history_data["file_metadata"]["files"]:
                original_path = metadata.get(BasicMetadtaColumns.ORIGINAL_STORAGE_URL)
                preview_path = metadata.get(BasicMetadtaColumns.PREVIEW_STORAGE_URL)

                if original_path and not str(original_path).startswith(("http://", "https://")):
                    metadata[BasicMetadtaColumns.ORIGINAL_STORAGE_URL] = minio_conn.presigned_get_object(
                        bucket_name=MinioBucket.LANGFLOW,
                        object_name=original_path,
                    )

                if preview_path and not str(preview_path).startswith(("http://", "https://")):
                    metadata[BasicMetadtaColumns.PREVIEW_STORAGE_URL] = _build_preview_presigned_url(
                        minio_conn=minio_conn,
                        object_name=preview_path,
                    )

        # Optionally load creator username if needed
        if history.creator:
            history_data["created_by_username"] = history.creator.username
        else:
            history_data["created_by_username"] = None
        items.append(VdbUploadHistoryRead(**history_data))
    
    # Calculate pagination metadata
    total_pages = (total_count + page_size - 1) // page_size
    
    return {
        "items": items,
        "pagination": {
            "page": page,
            "page_size": page_size,
            "total_count": total_count,
            "total_pages": total_pages,
        },
        "status_counts": status_counts,
    }


@router.get("/history/{upload_id}", response_model=VdbUploadHistoryRead, status_code=200)
async def get_upload_history_by_id(
    upload_id: UUID,
    session: DbSession,
    user: CurrentActiveUser,
) -> VdbUploadHistoryRead:
    """Get a specific upload history entry by ID.
    
    Args:
        upload_id: ID of the upload history entry
        session: Database session
        user: Current authenticated user
        
    Returns:
        VdbUploadHistoryRead: Upload history details
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    # Get the upload history entry
    upload_history = await get_vdb_upload_history_by_id(session, upload_id, load_creator=True)
    
    # Convert to response format
    history_data = upload_history.model_dump()
    if upload_history.creator:
        history_data["created_by_username"] = upload_history.creator.username
    else:
        history_data["created_by_username"] = None

    # replace original path and proceed path with presigned url
    minio_conn: Minio = get_minio_connection()

    # get files object info

    files_metadata = history_data["file_metadata"]["files"]
    for metadata in files_metadata:
        # preparing original path and preview path
        original_path = minio_conn.presigned_get_object(
            bucket_name=MinioBucket.LANGFLOW,
            object_name=metadata[BasicMetadtaColumns.ORIGINAL_STORAGE_URL],
        )
        preview_path = _build_preview_presigned_url(
            minio_conn=minio_conn,
            object_name=metadata[BasicMetadtaColumns.PREVIEW_STORAGE_URL],
        )
        metadata[BasicMetadtaColumns.ORIGINAL_STORAGE_URL] = original_path
        metadata[BasicMetadtaColumns.PREVIEW_STORAGE_URL] = preview_path

    
    await add_recent_activity(
        session=session,
        user_id=user.id,
        activity_type=ActivityTypeEnum.VIEWED,
        item_id=upload_history.id,
        item_type=ActivityItemTypeEnum.DATA_ASSET,
        title=f"{upload_history.name}",
        description=f"{upload_history.description or ''}",
    )

    return VdbUploadHistoryRead(**history_data)


@router.post("/history/{upload_id}/review", response_model=VdbUploadHistoryRead, status_code=200)
async def review_upload_history(
    upload_id: UUID,
    review: VdbUploadHistoryReview,
    session: DbSession,
    user: CurrentActiveUser,
) -> VdbUploadHistoryRead:
    """Review a specific upload history entry.
    
    Args:
        upload_id: ID of the upload history entry
        review: Review data containing status and review_comment
        session: Database session
        user: Current authenticated user
        
    Returns:
        VdbUploadHistoryRead: Updated upload history with review details
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    upload_history = await get_vdb_upload_history_by_id(session, upload_id, load_creator=True)

    action = PermCheckActionEnum.REJECT if review.status == VdbUploadStatus.REJECTED else PermCheckActionEnum.APPROVE
    membership = await get_membership_by_user_id_and_group_id(session, user.id, upload_history.group_id)
    if not await has_permission(resource=upload_history, action=action, user=user, membership=membership):
        raise HTTPException(status_code=403, detail="Permission denied: you cannot review this upload.")

    # Capture old values before update
    old_values = upload_history.model_dump_json()

    # Update with review information
    update_data = VdbUploadHistoryUpdate(
        status=review.status,
        reviewed_by=user.id,
        reviewed_at=datetime.now(timezone.utc),
        review_comment=review.review_comment,
    )
    
    updated_history = await update_vdb_upload_history(session, upload_history.id, update_data)

    # Create action history record
    history_action = (
        VdbUploadActionHistoryAction.REJECTED
        if review.status == VdbUploadStatus.REJECTED
        else VdbUploadActionHistoryAction.APPROVED
    )
    await create_vdb_upload_action_history(session, history_action, user.id, updated_history, old_values=old_values)

    await session.commit()
    
    # Convert to response format
    history_data = updated_history.model_dump()
    if updated_history.creator:
        history_data["created_by_username"] = updated_history.creator.username
    else:
        history_data["created_by_username"] = None

    # TODO: If approved, upload vectors to ChromaDB instead of doing it during initial upload
    if review.status == VdbUploadStatus.REJECTED:
        # Delete vectors from ChromaDB
        task_service = get_task_service()
        task_id, task_result = await task_service.launch_task(
            delete_vectors_from_collection,
            collection_name=updated_history.collection_name,
            upload_history_id=upload_id,
        )
    
    return VdbUploadHistoryRead(**history_data)


@router.delete("/history/{upload_id}", response_model=dict, status_code=200)
async def delete_upload_history(
    upload_id: UUID,
    session: DbSession,
    user: CurrentActiveUser,
) -> dict:
    """Delete an upload history entry and its vectors from ChromaDB.
    
    Args:
        upload_id: ID of the upload history entry to delete
        session: Database session
        user: Current authenticated user
        
    Returns:
        dict: Deletion status and message
    """
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    # Get the upload history entry
    upload_history = await get_vdb_upload_history_by_id(session, upload_id)

    membership = await get_membership_by_user_id_and_group_id(session, user.id, upload_history.group_id)
    if not await has_permission(resource=upload_history, action=PermCheckActionEnum.DELETE, user=user, membership=membership):
        raise HTTPException(status_code=403, detail="Permission denied: you cannot delete this upload.")

    collection_name = upload_history.collection_name
    old_values = upload_history.model_dump_json()
    
    # Delete vectors from ChromaDB
    task_service = get_task_service()
    await task_service.launch_task(
        delete_vectors_from_collection,
        collection_name=collection_name,
        upload_history_id=upload_id,
    )

    # delete object stored in minio
    minio_conn: Minio = get_minio_connection()
    files_metadata = upload_history.file_metadata["files"]
    for metadata in files_metadata:
        original_path = metadata.get(BasicMetadtaColumns.ORIGINAL_STORAGE_URL)
        preview_path = metadata.get(BasicMetadtaColumns.PREVIEW_STORAGE_URL)

        if original_path and not str(original_path).startswith(("http://", "https://")):
            try:
                minio_conn.remove_object(
                    bucket_name=MinioBucket.LANGFLOW,
                    object_name=original_path,
                )
            except Exception as e:
                logger.warning(f"Failed to delete original file from MinIO: {str(e)}")

        if preview_path and not str(preview_path).startswith(("http://", "https://")):
            try:
                minio_conn.remove_object(
                    bucket_name=MinioBucket.LANGFLOW,
                    object_name=preview_path,
                )
            except Exception as e:
                logger.warning(f"Failed to delete preview file from MinIO: {str(e)}")
    
    # Delete the upload history entry from database
    await delete_vdb_upload_history(session, upload_id)
    await delete_resource_permissions_by_resource_id(session, upload_id)

    await create_vdb_upload_action_history(session, VdbUploadActionHistoryAction.DELETED, user.id, upload_history, old_values=old_values)

    await add_recent_activity(
        session=session,
        user_id=user.id,
        activity_type=ActivityTypeEnum.DELETED,
        item_id=upload_history.id,
        item_type=ActivityItemTypeEnum.DATA_ASSET,
        title=f"{upload_history.name}",
        description=f"{upload_history.description or ''}",
    )

    await session.commit()
    
    return {
        "message": "Upload history and vectors deleted successfully",
        "upload_id": str(upload_id),
        "collection_name": collection_name,
    }

