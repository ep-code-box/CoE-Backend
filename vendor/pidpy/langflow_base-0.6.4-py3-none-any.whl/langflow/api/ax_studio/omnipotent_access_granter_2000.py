from enum import Enum


class PermCheckActionEnum(str, Enum):
    READ = "read"
    WRITE = "write"
    DELETE = "delete"
    CREATE = "create"
    BUY_A_COFFEE = "buy_a_coffee"
    APPROVE = "approve"
    REJECT = "reject"
    USE = "use"


# ── Action → column index
# APPROVE and REJECT are identical columns, so they share index 4.
# CREATE / BUY_A_COFFEE have no column → return False.
_ACTION_COL = {
    PermCheckActionEnum.READ:    0,
    PermCheckActionEnum.USE:     1,
    PermCheckActionEnum.CREATE:  2,
    PermCheckActionEnum.WRITE:   2,
    PermCheckActionEnum.DELETE:  3,
    PermCheckActionEnum.APPROVE: 4,
    PermCheckActionEnum.REJECT:  4,
}

# ── Actor row indices ─────────────────────────────────────────────────────────
_ADMIN             = 0
_CREATOR_IN_GROUP  = 1
_CREATOR_OUT_GROUP = 2
_SAME_GROUP        = 3
_OTHER_GROUP       = 4
_IN_GROUP_ADMIN    = 5

# ── Permission matrix  [actor][action_col] ────────────────────────────────────
_MATRIX = (
#     READ    USE (flow designer)   WRITE/CREATE   DELETE  APPROVE/REJECT
    ( True,   False,                True,          True,   True           ),   # ADMIN
    ( True,   True,                 True,          True,   False          ),   # CREATOR_IN_GROUP
    ( False,  False,                False,         False,  False          ),   # CREATOR_OUT_GROUP
    ( True,   False,                False,         False,  False          ),   # SAME_GROUP
    ( False,  False,                False,         False,  False          ),   # OTHER_GROUP
    ( True,   False,                True,          True,   True           ),   # IN_GROUP_ADMIN
)


async def _get_user_group_ids(user, membership) -> list:
    if membership:
        return [str(membership.group_id)]
    else:
        return []


async def _get_resource_creator_id(resource):
    # Each model uses a different field name for the creator:
    #   user_id    → MCPServer
    #   create_by  → AgentFlow, Datasource
    #   created_by → VdbUploadHistory
    #   creator_id → reserved for future models
    return str(
        getattr(resource, "user_id",    None)
        or getattr(resource, "create_by",  None)
        or getattr(resource, "created_by", None)
        or getattr(resource, "creator_id", None)
    )


async def _get_resource_group_id(resource):
    return str(
        getattr(resource, "group_id",    None)
    )


async def has_permission(
    resource,
    action: PermCheckActionEnum,
    user=None,
    user_id=None,
    membership=None,
) -> bool:
    """Return True/False for the given actor × action cell in the permission matrix.

    Actor resolution (first match wins):
        ADMIN             – user.is_superuser OR membership.is_group_admin
        CREATOR_IN_GROUP  – created the resource AND is in the resource's group
        CREATOR_OUT_GROUP – created the resource but is in a different group
        SAME_GROUP        – same group as the resource, not the creator
        OTHER_GROUP       – everything else
    """
    col = _ACTION_COL.get(action)
    if col is None:
        return False  # BUY_A_COFFEE, or any future unmapped action

    resource_creator_id = await _get_resource_creator_id(resource)
    resource_group_id   = await _get_resource_group_id(resource)
    user_group_ids      = await _get_user_group_ids(user, membership)

    is_admin      = getattr(user, "is_superuser", False)
    is_creator    = bool(user) and resource_creator_id == str(user.id)
    is_same_group = resource_group_id in user_group_ids
    is_group_admin = is_same_group and bool(membership.is_group_admin)

    if is_admin:
        actor = _ADMIN
    elif is_creator and is_same_group:
        actor = _CREATOR_IN_GROUP
    elif is_creator:
        actor = _CREATOR_OUT_GROUP
    elif is_same_group:
        actor = _SAME_GROUP
    elif is_group_admin:
        actor = _IN_GROUP_ADMIN
    else:
        actor = _OTHER_GROUP

    return _MATRIX[actor][col]

def is_global_admin(user) -> bool:
    """Return True if the user is a global admin."""
    if not user:
        return False
    return getattr(user, "is_superuser", False)