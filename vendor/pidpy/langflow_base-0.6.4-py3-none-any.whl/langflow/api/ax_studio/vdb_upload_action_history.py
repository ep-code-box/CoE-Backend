import json
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, desc
from sqlmodel import select
from sqlmodel.sql.expression import SelectOfScalar

from langflow.api.utils import DbSession
from langflow.services.database.models.vdb_upload_action_history.model import (
    VdbUploadActionHistory,
    VdbUploadActionHistoryRead,
    VdbUploadActionHistoryResponse,
)
from langflow.services.database.models.user.model import User

router = APIRouter(tags=["VDB_UPLOAD_ACTION_HISTORY"], prefix="/vdb_upload_action_history")


@router.get("/{history_id}", response_model=VdbUploadActionHistoryRead)
async def read_vdb_upload_action_history_by_id(
    *,
    history_id: UUID,
    session: DbSession,
) -> VdbUploadActionHistoryRead:
    """Retrieve a single vdb upload action history record by ID."""
    query: SelectOfScalar = select(VdbUploadActionHistory).where(VdbUploadActionHistory.id == history_id)
    history = (await session.exec(query)).first()

    if history is None:
        raise HTTPException(status_code=404, detail="VDB upload action history not found")

    history_dict = history.model_dump()
    history_dict["old_values"] = json.loads(history_dict.get("old_values") or "{}")
    history_dict["new_values"] = json.loads(history_dict.get("new_values") or "{}")

    creator_q = select(User).where(User.id == history.create_by)
    creator = (await session.exec(creator_q)).first()
    history_dict["created_by_username"] = creator.username if creator else None

    return VdbUploadActionHistoryRead(**history_dict)


@router.get("/", response_model=VdbUploadActionHistoryResponse)
async def read_all_vdb_upload_action_histories(
    *,
    skip: int = Query(0, description="Number of items to skip"),
    limit: int = Query(10, description="Maximum number of items to return"),
    upload_id: UUID = Query(..., description="Upload ID is required"),
    session: DbSession,
) -> VdbUploadActionHistoryResponse:
    """Retrieve paginated action history records for a given upload."""
    query = select(VdbUploadActionHistory)
    count_query = select(func.count()).select_from(VdbUploadActionHistory)

    where_condition = VdbUploadActionHistory.upload_id == upload_id
    query = query.where(where_condition)
    count_query = count_query.where(where_condition)

    query = query.order_by(desc(VdbUploadActionHistory.create_at))
    query = query.offset(skip).limit(limit)

    histories_raw = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()

    histories = []
    for h in histories_raw:
        h_dict = h.model_dump()
        h_dict["old_values"] = json.loads(h_dict.get("old_values") or "{}")
        h_dict["new_values"] = json.loads(h_dict.get("new_values") or "{}")

        creator_q = select(User).where(User.id == h.create_by)
        creator = (await session.exec(creator_q)).first()
        h_dict["created_by_username"] = creator.username if creator else None

        histories.append(VdbUploadActionHistoryRead(**h_dict))

    return VdbUploadActionHistoryResponse(
        total_count=total_count,
        upload_action_histories=histories,
    )
