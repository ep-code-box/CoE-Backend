from uuid import UUID
from sqlalchemy.exc import IntegrityError
from fastapi import APIRouter, HTTPException, Query, Depends
from sqlalchemy import func, and_, asc, desc
from sqlalchemy.orm import selectinload
from sqlmodel import select
from typing import Annotated
from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.services.auth.utils import get_current_active_superuser
from langflow.api.ax_studio.schemas import ResourcePermissionResponse, ResourcePermissionCreateRequest, ResourcePermissionUpdateRequest
from langflow.services.database.models.resource_permission.crud import (
    get_resource_permission_by_id,
    create_resource_permission,
    update_resource_permission,
)
from langflow.services.database.models.resource_permission.model import (
    ResourcePermission, 
    ResourcePermissionRead,
)
from langflow.services.database.models.resource_permission.constants import ResourceTypes
from langflow.services.database.models.user_group.model import UserGroup
from langflow.services.database.models.agent_flow.model import AgentFlow
from langflow.services.database.models.datasource.model import Datasource
from langflow.services.database.models.mcp.models import MCPServer
from langflow.services.database.models.vdb_upload_history.model import VdbUploadHistory
from langflow.services.database.models.user.model import User
from langflow.api.ax_studio.omnipotent_access_granter_2000 import is_global_admin

router = APIRouter(tags=["RESOURCE_PERMISSION"], prefix="/resource_permission")

@router.post("/", response_model=list[ResourcePermissionRead], status_code=201)
async def add_resource_permission(
        request: ResourcePermissionCreateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> list[ResourcePermission]:
    """Add new resource permissions to the database (supports bulk creation, updates duplicates)."""
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")
    
    try:
        input_obj = {
            "user_id": request.user_id,
            "resource_id": request.resource_id,
            "resource_type": request.resource_type.value,
            "has_read_permission": request.has_read_permission if request.has_read_permission else False,
        }

        result_permissions = await create_resource_permission(session, input_obj, user)
        await session.commit()
        
        # Refresh all permissions
        for permission in result_permissions:
            await session.refresh(permission)
            
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail="Failed to create resource permissions.") from e

    return result_permissions


@router.get("/approval-list")
async def list_resource_permissions(
    *,
    group_id: UUID = Query(..., description="Filter by group ID (required)"),
    page: int = Query(1, ge=1, description="Page number (starts at 1)"),
    page_size: int = Query(10, ge=1, le=100, description="Number of items per page"),
    member_name: str = Query(None, description="Filter by member name (partial match)"),
    resource_type: ResourceTypes = Query(None, description="Filter by resource type"),
    sort_by: str = Query("create_at", description="Field to sort by: member_name, create_at, resource_type"),
    sort_direction: str = Query("desc", description="Sort direction: asc or desc"),
    user: Annotated[User, Depends(get_current_active_superuser)],
    session: DbSession = None,
) -> dict:
    """
    Get approval/consent list with member details, approval date, resource type, and resource name.
    
    **Permission:** Only superusers (admins) can access this endpoint.
    
    **Columns:**
    - member_name: Name of the member who received permission
    - create_at: Approval/permission grant date
    - resource_type: Type of resource (AGENT_FLOW, MCP, DATABASE, SELF_HOSTED_VDB)
    - resource_name: Name of the resource
    
    **Sorting Options:**
    - member_name: Sort by member name
    - create_at: Sort by approval date (default)
    - resource_type: Sort by resource type
    
    **Pagination:**
    - page: Page number starting from 1
    - page_size: Number of items per page (1-100)
    
    **Example Response:**
    ```json
    {
        "total": 3,
        "page": 1,
        "page_size": 10,
        "data": [
            {
                "id": "perm-uuid-1",
                "member_name": "Kim Eun Jeong",
                "member_email": "kim.eun@company.com",
                "create_at": "2025-11-28T07:44:56",
                "resource_type": "MCP",
                "resource_name": "Enterprise CRM MCP",
                "has_read_permission": true
            },
            {
                "id": "perm-uuid-2",
                "member_name": "Park Seo Yeon",
                "member_email": "park.seo@company.com",
                "create_at": "2025-11-28T07:44:56",
                "resource_type": "DATABASE",
                "resource_name": "Enterprise CRM MCP",
                "has_read_permission": true
            }
        ]
    }
    ```
    """
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")

    try:
        # Build filter conditions
        conditions = []
        
        # Filter by resource type
        if resource_type:
            conditions.append(ResourcePermission.resource_type == resource_type.value)
        
        # Filter by member name (case-insensitive partial match)
        if member_name:
            conditions.append(User.username.ilike(f"%{member_name}%"))
        
        # Base query with explicit join on user_id (not create_by)
        # Also join Membership to filter by group_id
        base_query = select(ResourcePermission).join(
            UserGroup, ResourcePermission.user_id == UserGroup.user_id
        ).join(
            User, ResourcePermission.user_id == User.id
        ).where(
            UserGroup.group_id == group_id
        ).options(
            selectinload(ResourcePermission.user)
        )
        
        if conditions:
            base_query = base_query.where(and_(*conditions))
        
        # Apply sorting (before fetching all for grouping)
        sort_direction_lower = sort_direction.lower()
        if sort_by == "member_name":
            sort_column = User.username
        elif sort_by == "resource_type":
            sort_column = ResourcePermission.resource_type
        else:  # Default to create_at
            sort_column = ResourcePermission.create_at

        if sort_direction_lower == "asc":
            base_query = base_query.order_by(asc(sort_column))
        else:
            base_query = base_query.order_by(desc(sort_column))

        # Fetch all permissions matching filters (no offset/limit yet)
        permissions = (await session.exec(base_query)).all()
        
        # Batch fetch resource names to avoid N+1 queries
        resource_names = {}
        
        # Group resource IDs by type
        agent_flow_ids = [perm.resource_id for perm in permissions if perm.resource_type == ResourceTypes.AGENT_FLOW]
        mcp_ids = [perm.resource_id for perm in permissions if perm.resource_type == ResourceTypes.MCP]
        datasource_ids = [perm.resource_id for perm in permissions if perm.resource_type == ResourceTypes.DATABASE]
        vdb_ids = [perm.resource_id for perm in permissions if perm.resource_type == ResourceTypes.SELF_HOSTED_VDB]
        
        # Fetch all resources in batch queries (not per record)
        if agent_flow_ids:
            flows = await session.exec(select(AgentFlow.id, AgentFlow.name).where(AgentFlow.id.in_(agent_flow_ids)))
            for flow_id, flow_name in flows.all():
                resource_names[(ResourceTypes.AGENT_FLOW, flow_id)] = flow_name
        
        if mcp_ids:
            mcps = await session.exec(select(MCPServer.id, MCPServer.name).where(MCPServer.id.in_(mcp_ids)))
            for mcp_id, mcp_name in mcps.all():
                resource_names[(ResourceTypes.MCP, mcp_id)] = mcp_name
        
        if datasource_ids:
            datasources = await session.exec(select(Datasource.id, Datasource.name).where(Datasource.id.in_(datasource_ids)))
            for ds_id, ds_name in datasources.all():
                resource_names[(ResourceTypes.DATABASE, ds_id)] = ds_name
        
        if vdb_ids:
            vdbs = await session.exec(select(VdbUploadHistory.id, VdbUploadHistory.name).where(VdbUploadHistory.id.in_(vdb_ids)))
            for vdb_id, vdb_name in vdbs.all():
                resource_names[(ResourceTypes.SELF_HOSTED_VDB, vdb_id)] = vdb_name
        
        # Enrich data with resource names and group by resource_type + member_name
        grouped_data = {}
        for perm in permissions:
            # Get resource name from pre-fetched cache (no query)
            resource_name = resource_names.get((perm.resource_type, perm.resource_id), "Unknown")

            member_name = perm.user.username if perm.user else "Unknown"
            member_email = perm.user.email if perm.user else "Unknown"
            resource_type = perm.resource_type

            # Create group key: resource_type + member_name
            group_key = f"{resource_type}|{member_name}"

            if group_key not in grouped_data:
                grouped_data[group_key] = {
                    "resource_type": resource_type,
                    "member_name": member_name,
                    "member_email": member_email,
                    "create_at": perm.create_at.isoformat() if perm.create_at else None,
                    "resources": []
                }

            grouped_data[group_key]["resources"].append({
                "id": str(perm.id),
                "resource_name": resource_name,
                "has_read_permission": perm.has_read_permission,
            })

        # Convert grouped data to list
        data = list(grouped_data.values())

        # Calculate pagination on grouped data
        total_count = len(data)
        start = (page - 1) * page_size
        end = start + page_size
        paged_data = data[start:end]

        return {
            "total": total_count,
            "page": page,
            "page_size": page_size,
            "data": paged_data,
        }
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve approval list: {str(e)}")


@router.get("/{resource_permission_id}")
async def read_resource_permission_by_id(
        *,
        resource_permission_id: UUID,
        user: CurrentActiveUser,
        session: DbSession,
) -> ResourcePermissionRead:
    """Retrieve resource permission's data by id."""
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")

    resource_permission = await get_resource_permission_by_id(session, resource_permission_id)

    if resource_permission is None:
        raise HTTPException(status_code=404, detail="ResourcePermission not found")

    return ResourcePermissionRead(**resource_permission.model_dump())



@router.patch("/{resource_permission_id}", response_model=ResourcePermissionRead)
async def patch_resource_permission(
        resource_permission_id: UUID,
        request: ResourcePermissionUpdateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> ResourcePermission:
    """Update an existing resource permission."""
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")

    resource_permission_db = await get_resource_permission_by_id(session, resource_permission_id)
    if not resource_permission_db:
        raise HTTPException(status_code=404, detail="Resource permission not found")
    
    return await update_resource_permission(resource_permission_db, request, session)


@router.delete("/{resource_permission_id}")
async def delete_resource_permission(
        resource_permission_id: UUID,
        user: CurrentActiveUser,
        session: DbSession,
) -> dict:
    """Delete a resource permission from the database."""
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")

    resource_permission_db = await get_resource_permission_by_id(session, resource_permission_id)
    if not resource_permission_db:
        raise HTTPException(status_code=404, detail="Resource permission not found")

    await session.delete(resource_permission_db)
    await session.commit()

    return {"detail": "Resource permission deleted"}
