from uuid import UUID
from typing import Optional
from sqlalchemy.exc import IntegrityError
from fastapi import APIRouter, HTTPException, Query
from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.schemas import (
    DatasourceResponse,
    DatasourceUpdateRequest,
    DatasourceCreateRequestForRdb,
    DatasourceCreateRequestForS3,
    TestConnectionRequest,
    VDBConnectionConfOrDataAsset,
)
from langflow.services.database.models.datasource.crud import (
    get_data_asset_by_id,
    get_all_data_asset,
    create_data_asset, 
    update_data_asset
)
from langflow.services.database.models.datasource.model import (
    Datasource,
    DatasourceRead,
    DatasourceUpdate
)
from langflow.services.database.models.datasource.constants import (
    DatasourceStatus,
    DatasourceGroup,
    DataAssetType,
    DatasourceRDB,
    DatasourceVectorDB,
)
from langflow.services.database.models.data_asset_vdb.crud import get_vdb_config_by_data_asset_id
from langflow.services.database.models.datasource_rdb import (
    get_datasource_rdb_by_datasource_id,
    rdb_perform_connect,
)
from langflow.services.database.models.datasource_s3 import (
    get_datasource_s3_by_datasource_id,
    s3_perform_connect,
)
from langflow.api.ax_studio.data_asset_vdb import get_metadata

from langflow.services.database.models.recent_activity.crud import add_recent_activity
from langflow.services.database.models.recent_activity.model import (
    ActivityItemTypeEnum,
    ActivityTypeEnum,
)
from langflow.services.database.models.user_group.crud import get_membership_by_user_id_and_group_id
from langflow.services.database.models.user_group.model import UserGroup
from langflow.services.database.models.resource_permission.crud import delete_resource_permissions_by_resource_id
from langflow.api.ax_studio.omnipotent_access_granter_2000 import has_permission, PermCheckActionEnum
from langflow.services.database.models.datasource_history.constants import DatasourceHistoryAction
from langflow.services.database.models.datasource_history.crud import create_datasource_history

router = APIRouter(tags=["DATA_ASSET"], prefix="/datasource")


@router.post("/rdb", response_model=dict, status_code=201)
async def create_data_asset_with_rdb(
        request: DatasourceCreateRequestForRdb,
        user: CurrentActiveUser,
        session: DbSession,
) -> dict:
    """Create a new rdb data_asset."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    # Validate required fields
    if not all([request.host, request.port, request.database_name, request.username, request.password]):
        raise HTTPException(
            status_code=400, 
            detail="Data asset requires host, port, database_name, username, and password"
        )
    
    if request.name:
        request.name = request.name.strip()

        if not (1 <= len(request.name) <= 50):
            raise HTTPException(
                status_code=400,
                detail="Data asset name must be between 1 and 50 characters long.",
            )
    
    if request.description:
        request.description = request.description.strip()
    else:
        request.description = ""
    
    response_data = await create_data_asset(session, user, request, datasource_type="RDB")

    datasource_obj = await get_data_asset_by_id(session, response_data["id"])
    await create_datasource_history(session, DatasourceHistoryAction.REVIEW_REQUESTED, user.id, datasource_obj)

    await add_recent_activity(
        session=session,
        user_id=user.id,
        activity_type=ActivityTypeEnum.CREATED,
        item_id=datasource_obj.id,
        item_type=ActivityItemTypeEnum.DATA_ASSET,
        title=f"{datasource_obj.name}",
        description=f"{datasource_obj.description or ''}",
    )
    await session.commit()

    return response_data


@router.post("/s3", response_model=dict, status_code=201)
async def create_data_asset_with_s3(
        request: DatasourceCreateRequestForS3,
        user: CurrentActiveUser,
        session: DbSession,
) -> dict:
    """Create a new s3 data_asset."""
    if not user or not user.id:
        raise HTTPException(status_code=403, detail="Permission denied")

    # Validate required fields
    if not all([request.aws_s3_region, request.aws_s3_public_key, request.aws_s3_secret_key]):
        raise HTTPException(
            status_code=400,
            detail="Data asset requires aws_s3_region, aws_s3_public_key, and aws_s3_secret_key"
        )
    
    if request.name:
        request.name = request.name.strip()
    
    if request.description:
        request.description = request.description.strip()
    else:
        request.description = ""
    
    response_data = await create_data_asset(session, user, request, datasource_type="S3")

    datasource_obj = await get_data_asset_by_id(session, response_data["id"])
    await create_datasource_history(session, DatasourceHistoryAction.REVIEW_REQUESTED, user.id, datasource_obj)

    await add_recent_activity(
        session=session,
        user_id=user.id,
        activity_type=ActivityTypeEnum.CREATED,
        item_id=datasource_obj.id,
        item_type=ActivityItemTypeEnum.DATA_ASSET,
        title=f"{datasource_obj.name}",
        description=f"{datasource_obj.description or ''}",
    )
    await session.commit()

    return response_data


@router.post("/test_connection")
async def test_connection(
        session: DbSession,
        request: TestConnectionRequest,
) -> dict:
    """Test connection for a data_asset."""
    if request.datasource_type.value in [rdb.value for rdb in DatasourceRDB]:
        engine, conn, metadata = await rdb_perform_connect(
            session, 
            request.datasource_id, 
            request.datasource_type, 
            request.connection_config
        )

        result = {
            "check_access": engine is not None,
            "get_database": conn is not None,
            "get_schema": conn is not None,
            "get_table": len(metadata.tables) > 0,
        }

        if conn:
            conn.close()
        if engine:
            engine.dispose()
        
        return {"detail": result}
    elif request.datasource_type == DataAssetType.S3:
        s3_client, region = await s3_perform_connect(
            session, 
            request.datasource_id, 
            request.connection_config
        )

        # Test connection by listing buckets
        _ = [
            bucket["Name"] for bucket in s3_client.list_buckets()["Buckets"] 
            if s3_client.get_bucket_location(Bucket=bucket['Name'])['LocationConstraint'] == region
        ]

        result = {
            "check_access": s3_client is not None,
            "get_bucket": s3_client is not None,
            "get_file": s3_client is not None,
        }

        return {"detail": result}
    elif request.datasource_type.value in [vdb.value for vdb in DatasourceVectorDB]:
        _ = await get_metadata(
            request=VDBConnectionConfOrDataAsset(
                datasource_type=request.datasource_type,
                connection_config=request.connection_config,
            ),
            test_connection=True,
            session=session,
        )
        return {
            "status": "Success",
            "detail": {
                "get_connection": True,
                "get_collections": True,
                "get_metadata": True,
            },
        }
    else:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported data_asset type for connection test: {request.datasource_type}"
        )


@router.get("/{data_asset_id}")
async def read_data_asset_by_id(
    *,
    data_asset_id: UUID,
    session: DbSession,
    current_user: CurrentActiveUser,
) -> dict:
    """Retrieve data_asset's data by id, optionally with configuration."""
    data_asset = await get_data_asset_by_id(session, data_asset_id)

    membership = await get_membership_by_user_id_and_group_id(session, current_user.id, data_asset.group_id)
    if not await has_permission(resource=data_asset, action=PermCheckActionEnum.READ, user=current_user, membership=membership):
        raise HTTPException(status_code=403, detail="Permission denied: you cannot read this data_asset.")

    data_asset_data = DatasourceRead(**data_asset.model_dump())
    response_data = data_asset_data.model_dump()
    response_data["config"] = await __get_data_asset_config(session, response_data["datasource_type"], data_asset_id)
    response_data["creator_name"] = data_asset.user.username if data_asset.user else None
    response_data["group_name"] = data_asset.group.name if data_asset.group else None
    response_data["approver_name"] = data_asset.approver.username if data_asset.approver else None
    
    return response_data


@router.get("/")
async def read_all_data_asset(
        *,
        skip: int = Query(0, description="Number of items to skip"),
        limit: int = Query(10, description="Maximum number of items to return"),
        search_str: str = None,
        datasource_group: Optional[DatasourceGroup] = None,
        datasource_type: Optional[DataAssetType] = None,
        status: Optional[DatasourceStatus] = None,
        group_ids: list[UUID] | None = None,
        user: CurrentActiveUser,
        session: DbSession,
        filter_by_permission: bool = Query(default=False, description="Add filtering based on ResourcePermission"),
        sort_by: str = Query(default="create_at", description="Field to sort by"),
        sort_direction: str = Query(default="desc", description="Sort direction (asc or desc)"),
) -> DatasourceResponse:
    """Retrieve a list of data_assets from the database with pagination.
    
    **Permission Logic:**
    - if is_superuser:
        + if group_ids is not None: filter_by group_ids
        + else: no group filter (get all)
    - else: filter_by current user's group_id
    - On top of filtering by group_id(s), also filter by ResourcePermission if filter_by_permission is True.

    TODO: change queries, fix N+1
    TODO: support group_ids
    """
    # get_by_membership
    get_by_membership = not user.is_superuser


    data_assets, total_count, status_count = await get_all_data_asset(
        db=session,
        datasource_type=datasource_type.value.upper() if datasource_type else None,
        datasource_group=datasource_group.value if datasource_group else None,
        status=status.value if status else None,
        group_ids=group_ids,
        search_str=search_str,
        skip=skip,
        limit=limit,
        user=user,
        filter_by_permission=filter_by_permission,
        sort_by=sort_by,
        sort_direction=sort_direction,
        get_by_membership=get_by_membership,
        user_id=user.id,
    )

    data_asset_list = []
    for data_asset in data_assets:
        data_asset_data = DatasourceRead(**data_asset.model_dump())
        data_asset_dict = data_asset_data.model_dump()
        data_asset_dict["config"] = await __get_data_asset_config(session, data_asset_dict["datasource_type"], data_asset.id)
        data_asset_dict["creator_name"] = data_asset.user.username if data_asset.user else None
        data_asset_dict["group_name"] = data_asset.group.name if data_asset.group else None
        data_asset_dict["approver_name"] = data_asset.approver.username if data_asset.approver else None
        
        data_asset_list.append(data_asset_dict)

    return DatasourceResponse(
        total_count=total_count,
        datasources=data_asset_list,
        status_count=status_count,
    )
    

async def __get_data_asset_config(session: DbSession, datasource_type: str, datasource_id: UUID):
    if datasource_type.lower() in [rdb.value.lower() for rdb in DatasourceRDB]:
        rdb_config = await get_datasource_rdb_by_datasource_id(session, datasource_id)
        return rdb_config.model_dump() if rdb_config else None
    elif datasource_type.lower() == DataAssetType.S3.value.lower():
        s3_config = await get_datasource_s3_by_datasource_id(session, datasource_id)
        return s3_config.model_dump() if s3_config else None
    elif datasource_type.lower() in [vdb.value.lower() for vdb in DatasourceVectorDB]:
        vdb_config = await get_vdb_config_by_data_asset_id(session, datasource_id)
        return vdb_config.model_dump() if vdb_config else None
    else:
        return None


@router.patch("/{data_asset_id}", response_model=DatasourceRead)
async def patch_data_asset(
        data_asset_id: UUID,
        request: DatasourceUpdateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> Datasource:
    """Update an existing data_asset's data."""
    try:
        data_asset_old = await get_data_asset_by_id(session, data_asset_id)

        membership = await get_membership_by_user_id_and_group_id(session, user.id, data_asset_old.group_id)
        if not await has_permission(resource=data_asset_old, action=PermCheckActionEnum.WRITE, user=user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied: you cannot edit this data_asset.")

        # Capture old values before modification
        old_values = data_asset_old.model_dump_json()

        # Convert request to DatasourceUpdate model
        data_asset_update = DatasourceUpdate(
            name=request.name.strip() if request.name else None,
            description=request.description.strip() if request.description else None,
            status=request.status if request.status else None,
            reject_approve_reason=request.reject_approve_reason if request.reject_approve_reason else "",
            is_active=request.is_active
        )
        updated_data_asset = await update_data_asset(data_asset_old, data_asset_update, session, user=user)

        if request.connection_config:
            # Update connection config based on data_asset type
            if updated_data_asset.datasource_type.name in [rdb.name for rdb in DatasourceRDB]:
                rdb_config = await get_datasource_rdb_by_datasource_id(session, data_asset_id)
                for key, value in request.connection_config.items():
                    if hasattr(rdb_config, key):
                        setattr(rdb_config, key, value)
                session.add(rdb_config)
            elif updated_data_asset.datasource_type.name == DataAssetType.S3.name:
                s3_config = await get_datasource_s3_by_datasource_id(session, data_asset_id)
                for key, value in request.connection_config.items():
                    if hasattr(s3_config, key):
                        setattr(s3_config, key, value)
                session.add(s3_config)
            elif updated_data_asset.datasource_type.name in [vdb.name for vdb in DatasourceVectorDB]:
                vdb_config = await get_vdb_config_by_data_asset_id(session, data_asset_id)
                for key, value in request.connection_config.items():
                    if hasattr(vdb_config, key):
                        setattr(vdb_config, key, value)
                session.add(vdb_config)
            else:
                raise HTTPException(
                    status_code=400,
                    detail=f"Unsupported data_asset type for update: {updated_data_asset.datasource_type}"
                )

        # Determine history action based on new status
        new_status = request.status
        if new_status == DatasourceStatus.APPROVED.value:
            history_action = DatasourceHistoryAction.APPROVED
        elif new_status == DatasourceStatus.REJECTED.value:
            history_action = DatasourceHistoryAction.REJECTED
        else:
            history_action = DatasourceHistoryAction.UPDATED

        await create_datasource_history(session, history_action, user.id, updated_data_asset, old_values=old_values)

        await add_recent_activity(
            session=session,
            user_id=user.id,
            activity_type=ActivityTypeEnum.UPDATED,
            item_id=data_asset_id,
            item_type=ActivityItemTypeEnum.DATA_ASSET,
            title=f"{updated_data_asset.name}",
            description=f"{updated_data_asset.description}",
        )
        await session.commit()
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e
    
    return updated_data_asset


@router.delete("/{data_asset_id}")
async def delete_data_asset(
        data_asset_id: UUID,
        user: CurrentActiveUser,
        session: DbSession,
) -> dict:
    """Delete an data_asset from the database."""
    data_asset = await get_data_asset_by_id(session, data_asset_id)

    membership = await get_membership_by_user_id_and_group_id(session, user.id, data_asset.group_id)
    if not await has_permission(resource=data_asset, action=PermCheckActionEnum.DELETE, user=user, membership=membership):
        raise HTTPException(status_code=403, detail="Permission denied: you cannot delete this data asset.")

    old_values = data_asset.model_dump_json()
    data_asset_update = DatasourceUpdate(is_active=False)
    updated_data_asset = await update_data_asset(data_asset, data_asset_update, session)
    await delete_resource_permissions_by_resource_id(session, data_asset_id)

    await create_datasource_history(session, DatasourceHistoryAction.DELETED, user.id, updated_data_asset, old_values=old_values)

    await add_recent_activity(
        session=session,
        user_id=user.id,
        activity_type=ActivityTypeEnum.DELETED,
        item_id=data_asset_id,
        item_type=ActivityItemTypeEnum.DATA_ASSET,
        title=f"{data_asset.name}",
        description=f"{data_asset.description}",
    )
    await session.commit()

    return {"detail": "Data asset deleted"}
