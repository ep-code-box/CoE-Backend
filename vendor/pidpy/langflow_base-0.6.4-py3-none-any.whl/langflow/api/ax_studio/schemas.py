from datetime import datetime
from pydantic import BaseModel
from uuid import UUID
from typing import List, Optional

from langflow.services.database.models.user_group.model import MembershipUpdate
from langflow.services.database.models.user_role.model import UserRoleRead
from langflow.services.database.models.group.model import GroupRead, GroupReadNonAdmin
from langflow.services.database.models.datasource.model import DatasourceRead
from langflow.services.database.models.datasource.constants import (
    DataAssetType, 
    DatasourceStatus, 
    DatasourceRDB, 
    DatasourceStorageService
)
from langflow.services.database.models.agent_flow.model import ExportedFlowRead
from langflow.services.database.models.agent_flow.constants import AgentFlowStatus
from langflow.services.database.models.agent_flow_history import AgentFlowHistoryRead
from langflow.services.database.models.masterdata.model import MasterDataRead
from langflow.services.database.models.masterdata.constants import MasterDataTypes
from langflow.services.database.models.resource_permission.model import ResourcePermissionRead
from langflow.services.database.models.resource_permission.constants import ResourceTypes
from langflow.services.database.models.data_asset_vdb.model import (
    VDBConnectionConf,
)

class BulkUpdateUsersRequest(BaseModel):
    user_ids: List[UUID]
    updates: MembershipUpdate


class UserRoleCreateRequest(BaseModel):
    name: str


class UserRoleUpdateRequest(BaseModel):
    name: str


class UserRoleResponse(BaseModel):
    total_count: int
    user_roles: list[UserRoleRead]


class GroupCreateRequest(BaseModel):
    name: str
    name_kr: Optional[str] = None
    description: Optional[str] = None
    color: Optional[str] = None


class GroupUpdateRequest(BaseModel):
    name: Optional[str] = None
    name_kr: Optional[str] = None
    description: Optional[str] = None
    color: Optional[str] = None


class GroupResponse(BaseModel):
    total_count: int
    groups: list[GroupRead]


class GroupResponseNonAdmin(BaseModel):
    total_count: int
    groups: list[GroupReadNonAdmin]


class DatasourceCreateRequestForRdb(BaseModel):
    name: str
    description: Optional[str] = None
    datasource_type: DatasourceRDB
    host: Optional[str] = None
    port: Optional[int] = None
    database_name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    metadata_obj: Optional[dict] = None


class DatasourceCreateRequestForS3(BaseModel):
    name: str
    description: Optional[str] = None
    datasource_type: DatasourceStorageService
    aws_s3_region: Optional[str] = None
    aws_s3_public_key: Optional[str] = None
    aws_s3_secret_key: Optional[str] = None
    metadata_obj: Optional[dict] = None


class DatasourceUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[DatasourceStatus] = None
    is_active: Optional[bool] = None
    reject_approve_reason: Optional[str] = None
    connection_config: Optional[dict] = None


class DatasourceResponse(BaseModel):
    total_count: int
    datasources: list[DatasourceRead]
    status_count: dict[str, int] = {}


class DatasourceRDBUpdateRequest(BaseModel):
    host: Optional[str] = None
    port: Optional[int] = None
    database_name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    schema_stored_value: Optional[dict] = None


class DatasourceS3UpdateRequest(BaseModel):
    aws_s3_region: Optional[str] = None
    aws_s3_public_key: Optional[str] = None
    aws_s3_secret_key: Optional[str] = None
    schema_stored_value: Optional[dict] = None


class TestConnectionRequest(BaseModel):
    datasource_id: Optional[UUID] = None
    datasource_type: Optional[DataAssetType] = None
    connection_config: Optional[dict] = None
    

class FetchMetadataRdbRequest(BaseModel):
    datasource_id: Optional[UUID] = None
    datasource_type: Optional[DatasourceRDB] = None
    connection_config: Optional[dict] = None


class FetchMetadataS3Request(BaseModel):
    datasource_id: Optional[UUID] = None
    datasource_type: Optional[DatasourceStorageService] = None
    connection_config: Optional[dict] = None


class AgentFlowCreateRequest(BaseModel):
    lf_flow_id: UUID
    name: str
    description: Optional[str] = None
    endpoint: Optional[str] = None
    context: Optional[str] = None
    flow_operation: Optional[bool] = False
    langgraph_group_id: Optional[UUID] = None
    save_with_api_key: Optional[bool] = False
    json_setting: Optional[str] = None


class CoEBackendRequest(BaseModel):
    """Request model for CoE Backend API"""
    endpoint: str
    description: Optional[str] = None
    flow_body: dict
    flow_id: UUID
    contexts: list[str]
    context_groups: list[dict]


class CoEBackendResponse(BaseModel):
    """Response model from CoE Backend API"""
    success: bool
    status_code: Optional[int] = None
    response_text: Optional[str] = None
    error: Optional[str] = None


class AgentFlowUpdateRequest(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[AgentFlowStatus] = None
    endpoint: Optional[str] = None
    context: Optional[str] = None
    flow_operation: Optional[bool] = None
    langgraph_group_id: Optional[UUID] = None
    save_with_api_key: Optional[bool] = None
    last_used: Optional[datetime] = None
    json_setting: Optional[str] = None
    reject_approve_reason: Optional[str] = None


class ExportedFlowResponse(BaseModel):
    total_count: int
    agent_flows: list[ExportedFlowRead]
    status_counts: dict[str, int] = {}


class AgentFlowHistoryResponse(BaseModel):
    total_count: int
    agent_flow_histories: list[AgentFlowHistoryRead]


class MasterDataCreateRequest(BaseModel):
    name: str
    type: MasterDataTypes


class MasterDataUpdateRequest(BaseModel):
    name: Optional[str] = None
    value: Optional[dict] = None


class MasterDataResponse(BaseModel):
    total_count: int
    masterdatas: list[MasterDataRead]


class ResourcePermissionCreateRequest(BaseModel):
    user_id: List[UUID]
    resource_id: List[UUID]
    resource_type: ResourceTypes
    has_read_permission: Optional[bool] = False


class ResourcePermissionUpdateRequest(BaseModel):
    user_id: Optional[UUID] = None
    resource_id: Optional[UUID] = None
    resource_type: Optional[ResourceTypes] = None
    has_read_permission: Optional[bool] = None


class ResourcePermissionResponse(BaseModel):
    total_count: int
    resource_permissions: list[ResourcePermissionRead]



class VDBConnectionConfOrDataAsset(BaseModel):
    datasource_id: UUID | None = None
    datasource_type: DataAssetType | None = None
    connection_config: VDBConnectionConf | None = None


class GuideOrderItem(BaseModel):
    id: str
    order: int


class GuideOrderRequest(BaseModel):
    data: list[GuideOrderItem]
