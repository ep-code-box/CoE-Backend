from datetime import datetime
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlmodel import select, delete

from langflow.api.utils import DbSession
from langflow.services.database.models.recent_activity.model import RecentActivityRead, RecentActivity
from langflow.services.database.models.recent_activity.crud import list_recent_activities
from pydantic import BaseModel
from langflow.api.utils import CurrentActiveUser

class RecentActivityResponse(BaseModel):
    total_count: int
    activities: list[RecentActivityRead]


router = APIRouter(tags=["RECENT_ACTIVITY"], prefix="/recent_activities")


@router.get("/")
async def read_recent_activities(
    *,
    session: DbSession,
    current_user: CurrentActiveUser,
    activity_type: Optional[str] = Query(None, description="Filter by activity type (created, updated, deleted, viewed)"),
    item_type: Optional[str] = Query(None, description="Filter by item type (flow, mcp, data_asset)"),
    search_term: Optional[str] = Query(None, description="Search in title and description"),
    start_time: Optional[datetime] = Query(None, description="Start time for time range filter"),
    end_time: Optional[datetime] = Query(None, description="End time for time range filter"),
    sort_by: str = Query("timestamp", description="Field to sort by"),
    sort_dir: str = Query("desc", description="Sort direction (asc or desc)"),
    skip: int = Query(0, description="Number of items to skip", ge=0),
    limit: int = Query(50, description="Maximum number of items to return", ge=1, le=100),
) -> RecentActivityResponse:
    """
    Retrieve a list of recent activities with filtering, sorting, and pagination.
    
    Query parameters:
    - activity_type: Filter by activity type (created, updated, deleted, viewed)
    - item_type: Filter by item type (flow, mcp, data_asset)
    - search_term: Search in title and description fields
    - start_time: Filter activities from this timestamp onwards
    - end_time: Filter activities up to this timestamp
    - sort_by: Field to sort by (default: timestamp)
    - sort_dir: Sort direction - asc or desc (default: desc)
    - skip: Number of records to skip for pagination
    - limit: Maximum number of records to return (1-100, default: 50)
    """
    user_id: UUID = current_user.id
    # Build filter dictionary
    filter_by = {}
    if activity_type:
        filter_by["activity_type"] = activity_type
    if item_type:
        filter_by["item_type"] = item_type
    
    # Build time range tuple
    time_range = None
    if start_time or end_time:
        time_range = (start_time, end_time)
    
    try:
        # Query activities
        activities, total_count = await list_recent_activities(
            session=session,
            user_id=user_id,
            filter_by=filter_by if filter_by else None,
            sort_by=sort_by,
            sort_dir=sort_dir,
            limit=limit,
            offset=skip,
            search_term=search_term,
            time_range=time_range,
            distinct_by_item_id=True,
        )
        
        # Convert to read models
        activity_reads = [
            RecentActivityRead(**activity.model_dump())
            for activity in activities
        ]
        
        return RecentActivityResponse(
            total_count=total_count,
            activities=activity_reads,
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving recent activities: {str(e)}")


@router.delete("/")
async def delete_recent_activities(
    *,
    session: DbSession,
    current_user: CurrentActiveUser,
    user_id: Optional[UUID] = Query(None, description="User ID to delete activities for. If None and admin, deletes all activities. If None and non-admin, deletes own activities."),
) -> dict:
    """
    Delete recent activities.
    
    Query parameters:
    - user_id: If provided (admin only), deletes all activities for that user.
               If None and admin, deletes ALL activities.
               If None and non-admin, deletes activities for current user.
    """
    try:
        if user_id is None:
            if current_user.is_superuser:
                # Admin: Delete all activities
                stmt = delete(RecentActivity)
                result = await session.exec(stmt)
                await session.commit()
                deleted_count = result.rowcount
                return {
                    "message": "All recent activities deleted successfully",
                    "deleted_count": deleted_count,
                }
            else:
                # Non-admin: Delete own activities
                stmt = delete(RecentActivity).where(RecentActivity.user_id == current_user.id)
                result = await session.exec(stmt)
                await session.commit()
                deleted_count = result.rowcount
                return {
                    "message": "Your recent activities deleted successfully",
                    "deleted_count": deleted_count,
                }
        else:
            # Delete activities for specific user - admin only
            if user_id != current_user.id and not current_user.is_superuser:
                raise HTTPException(
                    status_code=403,
                    detail="Only administrators can delete activities for other users"
                )
            
            stmt = delete(RecentActivity).where(RecentActivity.user_id == user_id)
            result = await session.exec(stmt)
            await session.commit()
            deleted_count = result.rowcount
            return {
                "message": f"Recent activities for user {user_id} deleted successfully",
                "deleted_count": deleted_count,
            }
    except HTTPException:
        raise
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=f"Error deleting recent activities: {str(e)}")
