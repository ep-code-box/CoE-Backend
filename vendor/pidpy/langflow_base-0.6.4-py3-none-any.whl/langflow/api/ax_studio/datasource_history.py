import json
import re
from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, desc
from sqlmodel import select
from sqlmodel.sql.expression import SelectOfScalar

from langflow.api.utils import DbSession
from langflow.services.database.models.datasource_history.model import (
    DatasourceHistory,
    DatasourceHistoryRead,
    DatasourceHistoryResponse,
)
from langflow.services.database.models.user.model import User

_DATETIME_RE = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?([+-]\d{2}:\d{2}|Z)?$"
)


def _ensure_utc_in_dict(data: dict) -> dict:
    """Recursively normalize datetime strings inside a dict to UTC (appending 'Z' or converting offsets)."""
    result = {}
    for key, value in data.items():
        if isinstance(value, str) and _DATETIME_RE.match(value):
            try:
                normalized = value.replace("Z", "+00:00")
                dt = datetime.fromisoformat(normalized)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                else:
                    dt = dt.astimezone(timezone.utc)
                result[key] = dt.strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"
            except ValueError:
                result[key] = value
        elif isinstance(value, dict):
            result[key] = _ensure_utc_in_dict(value)
        elif isinstance(value, list):
            result[key] = [
                _ensure_utc_in_dict(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[key] = value
    return result

router = APIRouter(tags=["DATASOURCE_HISTORY"], prefix="/datasource_history")


@router.get("/{datasource_history_id}", response_model=DatasourceHistoryRead)
async def read_datasource_history_by_id(
    *,
    datasource_history_id: UUID,
    session: DbSession,
) -> DatasourceHistoryRead:
    """Retrieve a single datasource history record by ID."""
    query: SelectOfScalar = select(DatasourceHistory).where(DatasourceHistory.id == datasource_history_id)
    history = (await session.exec(query)).first()

    if history is None:
        raise HTTPException(status_code=404, detail="Datasource history not found")

    history_dict = history.model_dump()
    history_dict["old_values"] = _ensure_utc_in_dict(json.loads(history_dict.get("old_values") or "{}"))
    history_dict["new_values"] = _ensure_utc_in_dict(json.loads(history_dict.get("new_values") or "{}"))

    creator_q = select(User).where(User.id == history.create_by)
    creator = (await session.exec(creator_q)).first()
    history_dict["created_by_username"] = creator.username if creator else None

    return DatasourceHistoryRead(**history_dict)


@router.get("/", response_model=DatasourceHistoryResponse)
async def read_all_datasource_histories(
    *,
    skip: int = Query(0, description="Number of items to skip"),
    limit: int = Query(10, description="Maximum number of items to return"),
    datasource_id: UUID = Query(..., description="Datasource ID is required"),
    session: DbSession,
) -> DatasourceHistoryResponse:
    """Retrieve paginated history records for a given datasource."""
    query = select(DatasourceHistory)
    count_query = select(func.count()).select_from(DatasourceHistory)

    where_condition = DatasourceHistory.datasource_id == datasource_id
    query = query.where(where_condition)
    count_query = count_query.where(where_condition)

    query = query.order_by(desc(DatasourceHistory.create_at))
    query = query.offset(skip).limit(limit)

    histories_raw = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()

    histories = []
    for h in histories_raw:
        h_dict = h.model_dump()
        h_dict["old_values"] = _ensure_utc_in_dict(json.loads(h_dict.get("old_values") or "{}"))
        h_dict["new_values"] = _ensure_utc_in_dict(json.loads(h_dict.get("new_values") or "{}"))

        creator_q = select(User).where(User.id == h.create_by)
        creator = (await session.exec(creator_q)).first()
        h_dict["created_by_username"] = creator.username if creator else None

        histories.append(DatasourceHistoryRead(**h_dict))

    return DatasourceHistoryResponse(
        total_count=total_count,
        datasource_histories=histories,
    )
