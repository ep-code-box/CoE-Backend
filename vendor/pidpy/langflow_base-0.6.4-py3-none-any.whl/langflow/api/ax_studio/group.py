from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import func, and_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import selectinload
from sqlmodel import select

from langflow.api.utils import DbSession, CurrentActiveUser
from langflow.api.ax_studio.omnipotent_access_granter_2000 import is_global_admin
from langflow.api.ax_studio.schemas import (
    GroupResponse, 
    GroupResponseNonAdmin,
    GroupCreateRequest, 
    GroupUpdateRequest
)
from langflow.services.database.models.group.crud import get_group_by_id, update_group
from langflow.services.database.models.group.model import (
    Group,
    GroupRead,
    GroupCreate,
    GroupUpdate
)
from langflow.services.database.models.group.constants import DEFAULT_GROUP_NAME
from langflow.services.database.models.user_group.crud import get_one_admin_membership_by_group_id

router = APIRouter(tags=["GROUP"], prefix="/group")


@router.get("/non_admin_groups")
async def non_admin_groups(
        *,
        skip: int = Query(0, description="Number of items to skip"),
        limit: int = Query(10, description="Maximum number of items to return"),
        search_str: str = None,
        session: DbSession,
) -> GroupResponseNonAdmin:
    """Retrieve a list of groups from the database with pagination."""
    # Handle "undefined" or "null" string from frontend
    if search_str in ("undefined", "null", ""):
        search_str = None
    
    where_queries = __build_group_where_query(search_str=search_str)

    query = select(Group).where(where_queries).offset(skip).limit(limit)
    count_query = select(func.count()).select_from(Group).where(where_queries)

    groups = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()

    groups_response_list = []
    for group in groups:
        group_dict = group.model_dump()
        groups_response_list.append(GroupRead(**group_dict))

    return GroupResponseNonAdmin(
        total_count=total_count,
        groups=groups_response_list,
    )


@router.post("/", response_model=GroupRead, status_code=201)
async def add_group(
        request: GroupCreateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> Group:
    """Add a new group to the database."""
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")
    
    group_name = request.name.strip()
    group_name_kr = request.name_kr.strip() if request.name_kr else ""

    if not 1 < len(group_name) < 50:
        raise HTTPException(status_code=400, detail="Group name must be between 1 and 50 characters.")
    
    if group_name_kr and not 1 < len(group_name_kr) < 50:
        raise HTTPException(status_code=400, detail="Group name (KR) must be between 1 and 50 characters.")

    group_create = GroupCreate(
        name=group_name,
        name_kr=group_name_kr,
        description=request.description.strip() if request.description else "",
        color=request.color,
        create_by=user.id
    )

    new_group = Group.model_validate(group_create, from_attributes=True)
    new_group.update_search_field()
    try:
        session.add(new_group)
        await session.commit()
        await session.refresh(new_group)
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail="This group name is unavailable.") from e

    return new_group


@router.get("/{group_id}")
async def read_group_by_id(
        *,
        user: CurrentActiveUser,
        group_id: UUID,
        session: DbSession,
) -> GroupRead:
    """Retrieve group's data by id."""
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")

    group = await get_group_by_id(session, group_id, load_user_groups=True)
    if group is None:
        raise HTTPException(status_code=404, detail="Group not found")

    # Check if group has an admin
    group_admin = await get_one_admin_membership_by_group_id(session, group_id)

    group_dict = group.model_dump()
    group_dict["total_users"] = __count_non_admin_users(group.user_groups)
    group_dict["total_datasources"] = len(group.datasources)
    group_dict["is_have_group_admin"] = group_admin is not None
    group_dict["group_admin_name"] = group_admin.user.username if group_admin and group_admin.user else None

    return GroupRead(**group_dict)


@router.get("/")
async def read_all_groups(
        *,
        skip: int = Query(0, description="Number of items to skip"),
        limit: int = Query(10, description="Maximum number of items to return"),
        search_str: str = None,
        user: CurrentActiveUser,
        session: DbSession,
) -> GroupResponse:
    """
    Retrieve a list of groups from the database with pagination.
    TODO: refactor, fix N+1
    """

    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")
 
    where_queries = __build_group_where_query(search_str=search_str)

    query = select(Group) \
        .where(where_queries) \
        .offset(skip) \
        .limit(limit) \
        .options(
            selectinload(Group.user_groups),
            selectinload(Group.datasources),
    )
    count_query = select(func.count()).select_from(Group).where(where_queries)

    groups = (await session.exec(query)).fetchall()
    total_count = (await session.exec(count_query)).first()

    groups_response_list = []
    for group in groups:
        # Check if group has an admin
        group_admin = await get_one_admin_membership_by_group_id(session, group.id)
        
        group_dict = group.model_dump()
        group_dict["total_users"] = __count_non_admin_users(group.user_groups)
        group_dict["total_datasources"] = len(group.datasources)
        group_dict["is_have_group_admin"] = group_admin is not None
        group_dict["group_admin_name"] = group_admin.user.username if group_admin and group_admin.user else None
        groups_response_list.append(GroupRead(**group_dict))

    return GroupResponse(
        total_count=total_count,
        groups=groups_response_list,
    )


def __build_group_where_query(search_str=None):
    conditions = [
        # Group.name != DEFAULT_GROUP_NAME, 
        Group.is_active == True,
    ]

    if search_str:
        conditions.append(Group.search_field.ilike(f"%{search_str}%"))

    return and_(*conditions)


def __count_non_admin_users(user_groups) -> int:
    return sum(1 for user_group in user_groups if not user_group.is_group_admin)


@router.patch("/{group_id}", response_model=GroupRead)
async def patch_group(
        group_id: UUID,
        request: GroupUpdateRequest,
        user: CurrentActiveUser,
        session: DbSession,
) -> Group:
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")

    """Update an existing group's data."""
    group_name = request.name.strip() if request.name else ""
    group_name_kr = request.name_kr.strip() if request.name_kr else ""

    if not 1 <= len(group_name) <= 50:
        raise HTTPException(status_code=400, detail="Group name must be between 1 and 50 characters.")
    
    if group_name_kr and not 1 <= len(group_name_kr) <= 50:
        raise HTTPException(status_code=400, detail="Group name (KR) must be between 1 and 50 characters.")

    if group_db := await get_group_by_id(session, group_id):
        if group_db.name == DEFAULT_GROUP_NAME:
            raise HTTPException(status_code=400, detail="Cannot update the default group.")
        group_update = GroupUpdate(
            name=group_name,
            name_kr=group_name_kr,
            description=request.description.strip() if request.description else "",
            color=request.color
        )
        return await update_group(group_db, group_update, session)

    raise HTTPException(status_code=404, detail="Group not found")


@router.delete("/{group_id}")
async def delete_group(
        group_id: UUID,
        user: CurrentActiveUser,
        session: DbSession,
) -> dict:
    if not is_global_admin(user):
        raise HTTPException(status_code=403, detail="Permission denied")

    """Delete an group from the database. (Soft deleted)"""
    group_db = await get_group_by_id(session, group_id, load_user_groups=True)
    if not group_db:
        raise HTTPException(status_code=404, detail="Group not found")
    
    # Prevent deletion of default group
    if group_db.name == DEFAULT_GROUP_NAME:
        raise HTTPException(
            status_code=400, 
            detail="Cannot delete the default group."
        )

    # Check if group has any users
    if group_db.user_groups and len(group_db.user_groups) > 0:
        raise HTTPException(
            status_code=400, 
            detail="Cannot delete group with users. Please remove all users first."
        )

    group_update = GroupUpdate()
    group_update.is_active = False
    await update_group(group_db, group_update, session)

    return {"detail": "Group deleted"}
