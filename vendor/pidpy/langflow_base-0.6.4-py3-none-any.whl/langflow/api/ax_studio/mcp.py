from uuid import UUID
from datetime import datetime, timezone
import logging
import sys

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Avoid adding duplicate handlers if module is reloaded
if not logger.handlers:
    _handler = logging.StreamHandler(sys.stdout)  # Force output to stdout
    _handler.setLevel(logging.INFO)
    _formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - [%(threadName)s] - %(message)s'
    )
    _handler.setFormatter(_formatter)
    logger.addHandler(_handler)

# Ensure propagation is enabled (so root logger also sees it if configured)
logger.propagate = True


from fastapi import APIRouter, HTTPException, Query
from fastapi import Depends
from sqlalchemy.exc import IntegrityError

from langflow.api.utils import CurrentActiveUser, DbSession
from langflow.services.database.models.mcp.crud import (
    create_mcp_server,
    delete_mcp_server,
    get_mcp_server_by_id,
    get_mcp_server_list,
    update_mcp_server,
)
from langflow.services.database.models.mcp.models import (
    MCPServer,
    MCPServerCreate,
    MCPServerList,
    MCPServerRead,
    MCPServerUpdate,
    MCPServerStatusEnum,
    MCPServerTypeEnum,
)
from langflow.services.mcp_hub import MCPHubService
import os
from langflow.api.v2.mcp import upload_server_config
from langflow.services.deps import get_settings_service, get_storage_service

from pydantic import BaseModel

from langflow.services.database.models.user_group.crud import get_membership_by_user_id_and_group_id
from langflow.services.database.models.user_group.model import UserGroup

from sqlmodel import select, func

from langflow.services.database.models.mcp_template.crud import get_all_mcp_server_templates, get_mcp_server_template_by_id
from langflow.services.database.models.mcp_template.models import MCPServerTemplateRead

from langflow.services.database.models.resource_permission.crud import create_resource_permission, delete_resource_permissions_by_resource_id
from langflow.services.database.models.resource_permission.constants import ResourceTypes
from langflow.services.database.models.resource_permission.model import ResourcePermission

from langflow.services.database.models.recent_activity.crud import add_recent_activity, get_mcp_extra_info
from langflow.services.database.models.recent_activity.model import (
    ActivityItemTypeEnum,
    ActivityTypeEnum,
)
from langflow.api.ax_studio.omnipotent_access_granter_2000 import has_permission, PermCheckActionEnum
from langflow.services.database.models.mcp_server_history.constants import MCPServerHistoryAction
from langflow.services.database.models.mcp_server_history.crud import create_mcp_server_history

router = APIRouter(tags=["AX Studio MCP"], prefix="/mcp")


# Endpoint: Get all MCP server templates

@router.get("/templates", response_model=list[MCPServerTemplateRead])
async def get_templates(
    session: DbSession,
):
    """Get all available MCP server templates.
    
    Returns a list of predefined MCP server configuration templates that users can use
    to quickly set up common MCP servers like GitHub, Slack, Google Drive, etc.
    
    """
    try:
        templates = await get_all_mcp_server_templates(session)
        return templates
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.get("/templates/{template_id}", response_model=MCPServerTemplateRead)
async def get_template_by_id(
    template_id: UUID,
    session: DbSession,
):
    """Get a specific MCP server template by ID.
    
    Returns the details of a single MCP server template.
    """
    try:
        template = await get_mcp_server_template_by_id(session, template_id)
        if template is None:
            raise HTTPException(status_code=404, detail="MCP Server Template not found")
        
        return MCPServerTemplateRead.model_validate(template, from_attributes=True)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


# Endpoint: Count MCP servers by status for current user's group

@router.get("/servers/status-count", response_model=dict)
async def count_servers_by_status(
    current_user: CurrentActiveUser,
    session: DbSession,
    type: list[MCPServerTypeEnum] | None = Query(
        default=None,
        description="Filter by type (can specify multiple). Available values: EXTERNAL_STDIO, EXTERNAL_SSE, SELF_HOSTED"
    ),
    is_from_template: bool | None = Query(default=None, description="Filter by whether the server was created from a template"),
    group_ids: list[UUID] | None = Query(default=None, description="Filter by group IDs (multiple, superuser only)"),
    name: str | None = Query(default=None, description="Filter by name (partial match)"),
    filter_by_permission: bool = Query(default=False, description="Add filtering based on ResourcePermission. Only applicable for non-superusers with 'mine' selected."),
):
    """
    Count MCP servers of each status using SQL aggregation.
    Returns a dict: {status: count}
    
    **Type values:**
    - `EXTERNAL_STDIO`: External server using STDIO protocol
    - `EXTERNAL_SSE`: External server using Server-Sent Events
    - `SELF_HOSTED`: Self-hosted MCP server
    
    **Permission Logic:**
    - if is_superuser:
        + if group_ids is not None: filter_by group_ids
        + else: no group filter (get all)
    - else: filter_by current user's group_id
    """
    
    is_superuser = current_user.is_superuser

    query = select(MCPServer.status, func.count())

    # get_by_membership
    if is_superuser:
        if group_ids is not None:
            query = query.where(MCPServer.group_id.in_(group_ids))
    else:
        query = query.join(
            UserGroup,
            (UserGroup.group_id == MCPServer.group_id) & (UserGroup.user_id == current_user.id),
        )
        if group_ids is not None:
            query = query.where(MCPServer.group_id.in_(group_ids))

    # Apply filter_by_permission: mirror the same JOIN logic used in get_mcp_server_list
    if filter_by_permission:
        query = query.outerjoin(
            ResourcePermission,
            (ResourcePermission.resource_id == MCPServer.id)
            & (ResourcePermission.resource_type == ResourceTypes.MCP)
            & (ResourcePermission.has_read_permission == True)
            & (ResourcePermission.user_id == current_user.id),
        ).where(
            (MCPServer.user_id == current_user.id)
            | (
                (MCPServer.status == MCPServerStatusEnum.ACTIVE)
                & (ResourcePermission.resource_id != None)
            )
        )
    
    # Apply type filter if provided
    if type is not None:
        # Convert list of enums to list of string values for filtering
        type_values = [t.value for t in type]
        query = query.where(MCPServer.type.in_(type_values))
    
    # Apply is_from_template filter if provided
    if is_from_template is not None:
        query = query.where(MCPServer.is_from_template == is_from_template)
    
    # Apply name filter if provided
    if name is not None:
        query = query.where(MCPServer.name.contains(name))
    
    query = query.group_by(MCPServer.status)
    result = await session.exec(query)
    rows = result.all()

    # Build result dict with all possible statuses
    status_counts = {status.value: 0 for status in MCPServerStatusEnum}
    for status, count in rows:
        # status may be enum or string
        key = status.value if hasattr(status, "value") else str(status)
        status_counts[key] = count

    return status_counts


class MCPServersListResponse(dict):
    """Response model for MCP servers list with pagination."""

    servers: list[MCPServerList]
    total: int
    page: int
    page_size: int


@router.get("/servers", response_model=dict)
async def get_servers(
    current_user: CurrentActiveUser,
    session: DbSession,
    sort_by: str = Query(default="created_at", description="Field to sort by"),
    sort_direction: str = Query(default="desc", description="Sort direction (asc or desc)"),
    status: MCPServerStatusEnum | None = Query(
        default=None,
        description="Filter by status. Available values: PENDING, REJECTED, ACTIVE"
    ),
    type: list[MCPServerTypeEnum] | None = Query(
        default=None,
        description="Filter by type (can specify multiple). Available values: EXTERNAL_STDIO, EXTERNAL_SSE, SELF_HOSTED"
    ),
    name: str | None = Query(default=None, description="Filter by name (partial match)"),
    is_online: bool | None = Query(default=None, description="Currently useless"),
    is_from_template: bool | None = Query(default=None, description="Filter by whether the server was created from a template"),
    group_ids: list[UUID] | None = Query(default=None, description="Filter by group IDs (multiple, superuser only)"),
    page: int = Query(default=1, ge=1, description="Page number"),
    page_size: int = Query(default=10, ge=1, le=100, description="Items per page"),
    filter_by_permission: bool = Query(default=False, description="Add filtering based on ResourcePermission"),
):
    """Get the list of available MCP servers with pagination, sorting, and filtering.
    
    **Status values:**
    - `PENDING`: Server is pending approval
    - `REJECTED`: Server has been rejected
    - `ACTIVE`: Server is active and available
    
    **Type values:**
    - `EXTERNAL_STDIO`: External server using STDIO protocol
    - `EXTERNAL_SSE`: External server using Server-Sent Events
    - `SELF_HOSTED`: Self-hosted MCP server
    
    **Permission Logic:**
    - if is_superuser:
        + if group_ids is not None: filter_by group_ids
        + else: no group filter (get all)
    - else: filter_by current user's group_id
    - On top of filtering by group_id(s), also filter by ResourcePermission if filter_by_permission is True.
    """
    is_superuser = current_user.is_superuser
    try:
        # Build filter dictionary
        filter_by = {}
        get_by_membership = False
        
        # Handle group filtering based on user role
        if not is_superuser:
            # Non-superuser: use their group_id
            get_by_membership = True
        
        if group_ids is not None:
            filter_by["group_ids"] = group_ids
        if status is not None:
            filter_by["status"] = status.value
        if type is not None:
            # Convert list of enums to list of string values
            filter_by["type"] = [t.value for t in type]
        if name is not None:
            filter_by["name"] = name
        if is_online is not None:
            filter_by["is_online"] = is_online
        if is_from_template is not None:
            filter_by["is_from_template"] = is_from_template

        servers, total = await get_mcp_server_list(
            session=session,
            sort_by=sort_by,
            sort_direction=sort_direction,
            filter_by=filter_by if filter_by else None,
            page=page,
            page_size=page_size,
            user_id=current_user.id,
            filter_by_permission=filter_by_permission,
            get_by_membership=get_by_membership,
        )

        return {
            "servers": servers,
            "total": total,
            "page": page,
            "page_size": page_size,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/servers", status_code=201, response_model=MCPServerRead)
async def create_server(
    req: MCPServerCreate,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Create a new MCP server.
    
    **Note:** Status is automatically set to `PENDING` upon creation.

    if type is EXTERNAL_STDIO:
    ```
    "config": {
      "command": "string",
      "args": [
        "string"
      ],
      "env": {
        "string": "string"
      }
    }
    ```

    if type is EXTERNAL_SSE:
    ```
    "config": {
        "url": "string",
        "headers": {
            "string": "string"
        },
        "env": {
            "string": "string"
        }
    }
    ```
    
    if type is SELF_HOSTED:
    ```
    "config": {
      "baseUrl": "string",
      "authType": "string or None",
      "authKey": "string or None",
      "authValue": "string or None",
      "defaultHeaders": {
        "string": "string"
      }
    }
    ```
    """
    mcp_hub_service = MCPHubService()
    try:
        membership = await get_membership_by_user_id_and_group_id(session, current_user.id, req.group_id)
        if not await has_permission(resource=membership, action=PermCheckActionEnum.CREATE, user=current_user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied")

        # Verify config for all server types
        if req.config:
            mcp_hub_service.verify_mcp_server_config(req.type.value, req.config)
        
        # Create the MCP server in the database
        mcp_server = await create_mcp_server(
            session=session,
            mcp_server_create=req,
            user_id=current_user.id,
            group_id=req.group_id,
        )
        
        await session.commit()
        await session.refresh(mcp_server)
        
        # Sync to MCP Hub if SELF_HOSTED
        if req.type == MCPServerTypeEnum.SELF_HOSTED and mcp_server.config:
            mcp_server_name = str(mcp_server.id)
            server_create_hub = MCPServerCreate(
                name=mcp_server_name,
                description=mcp_server.description,
                tags=mcp_server.tags,
                type=mcp_server.type,
                config=mcp_server.config,
            )
            await mcp_hub_service.create_or_update_mcp_server(server_create_hub, mcp_server.config)
        
        await create_mcp_server_history(session, MCPServerHistoryAction.REVIEW_REQUESTED, current_user.id, mcp_server)
        await add_recent_activity(
            session=session,
            user_id=current_user.id,
            activity_type=ActivityTypeEnum.CREATED,
            item_id=mcp_server.id,
            item_type=ActivityItemTypeEnum.MCP,
            title=f"{mcp_server.name}",
            description=f"{mcp_server.description or ''}",
            extra_info=get_mcp_extra_info(mcp_server),
        )
        await session.commit()

        return MCPServerRead(**mcp_server.model_dump())
    except ValueError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail=str(e)) from e
    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail="MCP server with this name already exists.") from e
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()


@router.get("/servers/{mcp_server_id}", response_model=MCPServerRead)
async def get_server(
    mcp_server_id: UUID,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Get a specific MCP server by ID."""
    try:
        mcp_server: MCPServerRead = await get_mcp_server_by_id(
            session=session,
            mcp_server_id=mcp_server_id,
        )
        if mcp_server is None:
            raise HTTPException(status_code=404, detail="MCP Server not found")
        
        return mcp_server
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.put("/servers/{mcp_server_id}", response_model=MCPServerRead)
async def update_server(
    mcp_server_id: UUID,
    req: MCPServerUpdate,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Update an existing MCP server.
    
    **Status values:**
    - `PENDING`: Server is pending approval
    - `REJECTED`: Server has been rejected
    - `ACTIVE`: Server is active and available
    
    **Note:** Only the fields provided in the request will be updated. Status will be reset to PENDING.
    """
    mcp_hub_service = MCPHubService()
    try:
        # Get the existing server to check its type
        existing_server = await get_mcp_server_by_id(
            session=session,
            mcp_server_id=mcp_server_id,
        )
        if existing_server is None:
            raise HTTPException(status_code=404, detail="MCP Server not found")

        membership = await get_membership_by_user_id_and_group_id(session, current_user.id, existing_server.group_id)
        if not await has_permission(resource=existing_server, action=PermCheckActionEnum.WRITE, user=current_user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied")

        # Set status to PENDING on update
        req.status = MCPServerStatusEnum.PENDING
        
        # Verify config if it's being updated for SELF_HOSTED type
        if existing_server.type == MCPServerTypeEnum.SELF_HOSTED and req.config is not None:
            mcp_hub_service.verify_mcp_server_config(existing_server.type.value, req.config)
        
        # Update the MCP server in the database
        mcp_server = await update_mcp_server(
            session=session,
            mcp_server_id=mcp_server_id,
            mcp_server_update=req,
            user_id=current_user.id,
        )
        
        await add_recent_activity(
            session=session,
            user_id=current_user.id,
            activity_type=ActivityTypeEnum.UPDATED,
            item_id=mcp_server_id,
            item_type=ActivityItemTypeEnum.MCP,
            title=f"{mcp_server.name}",
            description=f"{mcp_server.description or ''}",
            extra_info=get_mcp_extra_info(mcp_server),
        )
        await create_mcp_server_history(session, MCPServerHistoryAction.UPDATED, current_user.id, mcp_server, old_values=existing_server.model_dump_json())
        await session.commit()
        
        # Sync to MCP Hub if SELF_HOSTED
        if existing_server.type == MCPServerTypeEnum.SELF_HOSTED and mcp_server.config:
            mcp_server_name = str(mcp_server_id)
            server_create_hub = MCPServerCreate(
                name=mcp_server_name,
                description=mcp_server.description,
                tags=mcp_server.tags,
                type=mcp_server.type,
                config=mcp_server.config,
            )
            await mcp_hub_service.create_or_update_mcp_server(server_create_hub, mcp_server.config)
        
        return mcp_server
    except HTTPException:
        raise
    except ValueError as e:
        await session.rollback()
        raise HTTPException(status_code=404, detail=str(e)) from e
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()


@router.delete("/servers/{mcp_server_id}", status_code=204)
async def delete_server(
    mcp_server_id: UUID,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Delete an MCP server."""
    mcp_hub_service = MCPHubService()
    try:
        # Get the server before deleting to check its type and name
        logger.info(f"Attempting to delete MCP server with ID: {mcp_server_id} by user: {current_user.id}")
        existing_server = await get_mcp_server_by_id(
            session=session,
            mcp_server_id=mcp_server_id,
        )

        logger.info("Check existing server: %s", existing_server)
        if existing_server is None:
            raise HTTPException(status_code=404, detail="MCP Server not found")

        logger.info("Checking permissions for user %s on server %s", current_user.id, existing_server.id)
        membership = await get_membership_by_user_id_and_group_id(session, current_user.id, existing_server.group_id)
        if not await has_permission(resource=existing_server, action=PermCheckActionEnum.DELETE, user=current_user, membership=membership):
            logger.info("Permission denied for user %s to delete server %s", current_user.id, existing_server.id)
            raise HTTPException(status_code=403, detail="Permission denied")
        
        logger.info("Permission granted for user %s to delete server %s", current_user.id, existing_server.id)
        # Delete from database
        logger.info("Deleting MCP server with ID: %s from database", mcp_server_id)
        await delete_mcp_server(
            session=session,
            mcp_server_id=mcp_server_id,
            user_id=current_user.id,
        )
        await delete_resource_permissions_by_resource_id(session, mcp_server_id)

        await add_recent_activity(
            session=session,
            user_id=current_user.id,
            activity_type=ActivityTypeEnum.DELETED,
            item_id=mcp_server_id,
            item_type=ActivityItemTypeEnum.MCP,
            title=f"{existing_server.name}",
            description=f"{existing_server.description or ''}",
            extra_info=get_mcp_extra_info(existing_server),
        )
        await create_mcp_server_history(session, MCPServerHistoryAction.DELETED, current_user.id, existing_server, old_values=existing_server.model_dump_json())
        await session.commit()
        
        # If SELF_HOSTED, also delete from MCP Hub
        if existing_server.type == MCPServerTypeEnum.SELF_HOSTED:
            try:
                await mcp_hub_service.delete_mcp_server(existing_server.name)
            except Exception as hub_error:
                # Log the error but don't fail the request
                # The server is deleted from DB, but MCP Hub deletion failed
                logger.warning("Failed to delete from MCP Hub: %s", hub_error)
        
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    except Exception as e:
        logger.info("Unexpected error occurred: %s", e)
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()

class MCPServerReview(BaseModel):
    status: MCPServerStatusEnum
    review_comment: str | None = None

@router.post("/servers/{mcp_server_id}/review", response_model=MCPServerRead)
async def review_server(
    mcp_server_id: UUID,
    req: MCPServerReview,
    current_user: CurrentActiveUser,
    session: DbSession,
):
    """Activate an MCP server (change status from PENDING to ACTIVE).
    
    **Authorization:** Requires superuser privileges.
    
    This endpoint changes the status of an MCP server from PENDING to ACTIVE.
    Only users with superuser privileges can activate servers.
    """
    try:
        # Get the existing server first so has_permission can inspect it
        existing_server = await get_mcp_server_by_id(
            session=session,
            mcp_server_id=mcp_server_id,
        )
        if existing_server is None:
            raise HTTPException(status_code=404, detail="MCP Server not found")

        action = PermCheckActionEnum.APPROVE if req.status == MCPServerStatusEnum.ACTIVE else PermCheckActionEnum.REJECT
        membership = await get_membership_by_user_id_and_group_id(session, current_user.id, existing_server.group_id)
        if not await has_permission(resource=existing_server, action=action, user=current_user, membership=membership):
            raise HTTPException(status_code=403, detail="Permission denied: only admins can review MCP servers.")
        
        # Update status to ACTIVE and set reviewed_by, reviewed_at, and review_comment
        update_data = MCPServerUpdate(
            status=req.status,
            reviewed_by=current_user.id,
            reviewed_at=datetime.now(timezone.utc),
            review_comment=req.review_comment,
        )
        mcp_server = await update_mcp_server(
            session=session,
            mcp_server_id=mcp_server_id,
            mcp_server_update=update_data,
            user_id=current_user.id,
        )

        # if req.status == MCPServerStatusEnum.ACTIVE:
        #     await sync_servers_to_hub(
        #         current_user=current_user,
        #         session=session,
        #         mcp_server_id=mcp_server_id,
        #     )

        history_action = (
            MCPServerHistoryAction.APPROVED
            if req.status == MCPServerStatusEnum.ACTIVE
            else MCPServerHistoryAction.REJECTED
        )
        await create_mcp_server_history(session, history_action, current_user.id, mcp_server, old_values=existing_server.model_dump_json())
        await session.commit()

        return mcp_server
    except HTTPException:
        raise
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/servers/sync", status_code=200)
async def sync_servers_to_hub(
    current_user: CurrentActiveUser,
    session: DbSession,
    mcp_server_id: UUID | None = Query(default=None, description="Specific MCP server ID to sync. If not provided, syncs all SELF_HOSTED servers."),
):
    """Sync MCP servers and their tools to the MCP Hub.
    
    This endpoint will sync SELF_HOSTED MCP servers and their associated tools to the external MCP Hub.
    
    **Parameters:**
    - `mcp_server_id` (optional): If provided, syncs only the specified server and its tools. 
      If not provided, syncs all SELF_HOSTED servers.
    
    **Returns:**
    - Summary of sync operation including successful and failed syncs
    """
    from sqlmodel import select
    from langflow.services.database.models.mcp_tools.models import MCPTool
    
    mcp_hub_service = MCPHubService()
    sync_results = {
        "servers_synced": 0,
        "servers_failed": 0,
        "tools_synced": 0,
        "tools_failed": 0,
        "errors": [],
    }
    
    try:
        # Determine which servers to sync
        if mcp_server_id:
            # Sync specific server
            server = await get_mcp_server_by_id(
                session=session,
                mcp_server_id=mcp_server_id,
            )
            if server is None:
                raise HTTPException(status_code=404, detail="MCP Server not found")
            
            servers = [server] if server.type == MCPServerTypeEnum.SELF_HOSTED else []
            if not servers:
                return {
                    **sync_results,
                    "message": "Server is not SELF_HOSTED type, skipping sync",
                }
        else:
            # Sync all SELF_HOSTED servers that have ACTIVE status
            query = select(MCPServer).where(
                MCPServer.type == MCPServerTypeEnum.SELF_HOSTED,
                MCPServer.status == MCPServerStatusEnum.ACTIVE
            )
            result = await session.exec(query)
            servers = result.all()
        
        # Sync each server and its tools
        for server in servers:
            try:
                # Verify and sync server
                if not server.config:
                    sync_results["servers_failed"] += 1
                    sync_results["errors"].append(f"Server '{server.name}' has no config")
                    continue
                
                mcp_hub_service.verify_mcp_server_config(server.type.value, server.config)

                mcp_server_name = server.name.replace(" ", "_").lower()
                mcp_server_name = str(server.id)
                
                # Create MCPServerCreate object
                server_create = MCPServerCreate(
                    name=mcp_server_name,
                    description=server.description,
                    tags=server.tags,
                    type=server.type,
                    config=server.config,
                )
                
                if mcp_server_id:
                    await mcp_hub_service.delete_mcp_server(mcp_server_name)
                await mcp_hub_service.create_or_update_mcp_server(server_create, server.config)
                sync_results["servers_synced"] += 1

                # Query and sync all tools for this server that have ACTIVE status
                tools_query = select(MCPTool).where(
                    MCPTool.mcp_server_id == server.id,
                    MCPTool.status == MCPServerStatusEnum.ACTIVE
                )
                tools_result = await session.exec(tools_query)
                tools = tools_result.all()
                
                
                for tool in tools:
                    try:
                        # Create MCPToolCreate object
                        from langflow.services.database.models.mcp_tools.models import MCPToolCreate
                        
                        tool_create = MCPToolCreate(
                            name=tool.name,
                            description=tool.description,
                            http_method=tool.http_method,
                            path_template=tool.path_template,
                            input_schema=tool.input_schema,
                            path_mapping=tool.path_mapping,
                            query_mapping=tool.query_mapping,
                            headers_mapping=tool.headers_mapping,
                            body_mapping=tool.body_mapping,
                            raw_body_key=tool.raw_body_key,
                            response_mapping=tool.response_mapping,
                            mcp_server_id=server.id,
                        )
                        
                        await mcp_hub_service.create_or_update_mcp_tool(tool_create, mcp_server_name)
                        sync_results["tools_synced"] += 1
                        
                    except Exception as tool_error:
                        sync_results["tools_failed"] += 1
                        sync_results["errors"].append(f"Tool '{tool.name}': {str(tool_error)}")
                
            except Exception as server_error:
                sync_results["servers_failed"] += 1
                sync_results["errors"].append(f"Server '{server.name}': {str(server_error)}")
        
        return {
            **sync_results,
            "message": f"Sync completed. Servers: {sync_results['servers_synced']} synced, {sync_results['servers_failed']} failed. Tools: {sync_results['tools_synced']} synced, {sync_results['tools_failed']} failed.",
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e
    finally:
        await mcp_hub_service.close()


# @router.post("/servers/copy-config", status_code=200)
async def copy_mcp_config(
    current_user: CurrentActiveUser,
    session: DbSession,
    storage_service=Depends(get_storage_service),
    settings_service=Depends(get_settings_service),
):
    """
    Copy all ACTIVE MCP servers for the current user's group_id into a config file and upload it.
    For EXTERNAL_STDIO and EXTERNAL_SSE: use the server's config.
    For SELF_HOSTED: use a url pointing to the SSE endpoint on MCP_HUB_URL.
    """
    from langflow.services.database.models.mcp.models import MCPServerTypeEnum, MCPServerStatusEnum, MCPServer
    from sqlmodel import select

    group_id = getattr(await get_one_membership_by_user_id(session, current_user.id), "group_id", None)

    # Query all ACTIVE servers for this group
    query = select(MCPServer).where(
        MCPServer.group_id == group_id,
        MCPServer.status == MCPServerStatusEnum.ACTIVE
    )
    result = await session.exec(query)
    servers = result.all()

    mcp_servers_config = {}
    mcp_hub_url = os.getenv("MCP_HUB_URL", "http://localhost:8000")

    for server in servers:
        if server.type in [MCPServerTypeEnum.EXTERNAL_STDIO, MCPServerTypeEnum.EXTERNAL_SSE]:
            mcp_servers_config[server.name] = server.config
        elif server.type == MCPServerTypeEnum.SELF_HOSTED:
            mcp_servers_config[server.name] = {
                "url": f"{mcp_hub_url}/mcp-servers/{server.name}/sse"
            }

    json_config = {"mcpServers": mcp_servers_config}

    # Use upload_server_config from v2/mcp.py
    return await upload_server_config(
        json_config,
        current_user,
        session,
        storage_service,
        settings_service,
    )
