from datetime import datetime, timezone
from typing import Annotated, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, and_, case
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload
from sqlmodel import select
from sqlmodel.sql.expression import SelectOfScalar

from langflow.api.utils import CurrentActiveUser, DbSession
from langflow.api.v1.schemas import UsersResponse, UserCreateRequest
from langflow.initial_setup.setup import get_or_create_default_folder
from langflow.services.database.models.group.crud import get_group_by_id
from langflow.services.auth.utils import (
    get_current_active_superuser,
    get_password_hash,
    verify_password,
)
from langflow.services.database.models.user.crud import (
    get_user_by_id,
    get_user_by_email,
    update_user,
    user_add_default_group,
    validate_user_info
)
from langflow.services.database.models.user.model import User, UserCreate, UserRead, UserUpdate
from langflow.services.database.models.user.utils import get_user_role_and_admin_permission, prepare_user_dict_response
from langflow.services.database.models.user_group.model import UserGroup
from langflow.services.database.models.masterdata.crud import get_first_three_homepage_config

router = APIRouter(tags=["Users"], prefix="/users")

# mutilated from original users.py

@router.post("/", response_model=UserRead, status_code=201)
async def add_user(
        request: UserCreateRequest,
        session: DbSession,
) -> User:
    """Add a new user to the database."""
    # Validate user info
    validate_user_info(request)

    # Check for duplicate email
    if request.email:
        existing = await get_user_by_email(session, request.email)
        if existing:
            raise HTTPException(status_code=400, detail="이미 등록된 이메일입니다.")

    user = UserCreate(
        username=request.username,
        password=request.password,
        email=request.email,
        role_id=request.role_id,
        optins=request.optins,
    )

    # Role handling
    role_id, is_superuser = await get_user_role_and_admin_permission(session, user.role_id)
    user.role_id = role_id
    user.is_superuser = is_superuser

    new_user = User.model_validate(user, from_attributes=True)
    try:
        new_user.password = get_password_hash(user.password)
        new_user.is_active = False # New users are inactive by default
        new_user.is_pending = True # New users are pending by default
        new_user.update_search_field()

        # add default homepage_config
        first_three_masterdatas = await get_first_three_homepage_config(session)
        if first_three_masterdatas:
            new_user.homepage_config = ",".join([str(md.id) for md in first_three_masterdatas])
        
        # Add user to session and flush to generate ID
        session.add(new_user)
        await session.flush()
        
        # Add user to group (now that new_user.id exists)
        if not request.group_id:
            user_group = await user_add_default_group(session, new_user)
            session.add(user_group)
        else:
            group = await get_group_by_id(session, request.group_id)
            if not group:
                raise HTTPException(status_code=404, detail="Group not found")
            
            user_group = UserGroup(
                user_id=new_user.id,
                group_id=group.id,
                is_group_admin=False,
                create_by=new_user.id
            )
            session.add(user_group)
        
        await session.commit()
        await session.refresh(new_user)
        
        folder = await get_or_create_default_folder(session, new_user.id)
        if not folder:
            raise HTTPException(status_code=500, detail="Error creating default project")

    except IntegrityError as e:
        await session.rollback()
        raise HTTPException(status_code=400, detail="This username is unavailable.") from e

    # Reload the user with group relationship eager loaded
    user = await get_user_by_id(session, new_user.id)
    user_dict = prepare_user_dict_response(user)
    return UserRead(**user_dict)


@router.get("/whoami", response_model=UserRead)
async def read_current_user(
        current_user: CurrentActiveUser,
        session: DbSession,
) -> User:
    """Retrieve the current user's data."""
    # Check if user has a group, if not assign to default group
    if not current_user.user_groups:
        user_group = await user_add_default_group(session, current_user)
        session.add(user_group)
        await session.commit()

    current_user = await get_user_by_id(session, current_user.id)
    user_dict = prepare_user_dict_response(current_user)
    return UserRead(**user_dict)


@router.get("/{user_id}")
async def read_user_by_id(
        *,
        user_id: UUID,
        session: DbSession,
) -> UserRead:
    """Retrieve user's data by id."""
    user = await get_user_by_id(session, user_id)

    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    user_dict = prepare_user_dict_response(user)
    return UserRead(**user_dict)


@router.get("/")
async def read_all_users(
        *,
        skip: int = 0,
        limit: int = 10,
        is_active: Optional[bool] = None,
        is_pending: Optional[bool] = None,
        group_id: Optional[UUID] = None,
        search_str: Optional[str] = None,
        order_by: str = "create_at",
        order_direction: str = "desc",
        user: CurrentActiveUser,
        session: DbSession,
) -> UsersResponse:
    """Retrieve a list of users from the database with pagination."""
    where_queries = __build_user_where_query(search_str=search_str,
                                             is_active=is_active,
                                             is_pending=is_pending,
                                             group_id=group_id,
                                             current_user=user)

    base_query = select(User).options(
        joinedload(User.user_groups).joinedload(UserGroup.group),
        joinedload(User.role)
    )

    sort_column = getattr(User, order_by, User.create_at)
    sort_expr = sort_column.desc() if order_direction.lower() == "desc" else sort_column.asc()

    query: SelectOfScalar = (base_query.where(where_queries) if where_queries is not None else base_query).order_by(sort_expr).offset(skip).limit(limit)

    users = (await session.exec(query)).unique().fetchall()

    # Count active and inactive users with the same filters (excluding is_active/is_pending filter)
    base_where = __build_user_where_query(search_str=search_str, group_id=group_id, current_user=user)
    counts_query = select(
        func.sum(case((User.is_pending == False, 1), else_=0)),
        func.sum(case((User.is_pending == True, 1), else_=0)),
    ).select_from(User)
    if base_where is not None:
        counts_query = counts_query.where(base_where)
    counts_result = (await session.exec(counts_query)).first()
    active_count = counts_result[0] or 0
    pending_count = counts_result[1] or 0

    users_response_list = []
    for user in users:
        user_dict = prepare_user_dict_response(user)
        users_response_list.append(UserRead(**user_dict))

    return UsersResponse(
        total_count=active_count + pending_count,
        active_count=active_count,
        inactive_count=pending_count,
        users=users_response_list
    )


def __build_user_where_query(search_str=None, is_active=None, is_pending=None, group_id=None, current_user=None):
    conditions = [User.id != current_user.id]

    if is_active is not None:
        conditions.append(User.is_active == is_active)
    if group_id:
        # Filter by group through the junction table
        conditions.append(User.user_groups.any(UserGroup.group_id == group_id))
    if search_str:
        conditions.append(User.search_field.ilike(f"%{search_str}%"))
    if is_pending is not None:
        conditions.append(User.is_pending == is_pending)
    if conditions:
        return and_(*conditions)
    else:
        return None


@router.patch("/{user_id}", response_model=UserRead)
async def patch_user(
        user_id: UUID,
        user_update: UserUpdate,
        user: CurrentActiveUser,
        session: DbSession,
) -> User:
    """Update an existing user's data."""
    # Permission checks
    if not user.is_superuser and user_update.is_superuser:
        raise HTTPException(status_code=403, detail="Permission denied")

    if not user.is_superuser and user.id != user_id:
        raise HTTPException(status_code=403, detail="Permission denied")
    
    # Validate user info
    validate_user_info(user_update)

    # Fetch user with relationships (single query with eager loading)
    user_db = await get_user_by_id(session, user_id)
    if not user_db:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Ensure user has at least one group
    if not user_db.user_groups:
        user_group = await user_add_default_group(session, user_db)
        session.add(user_group)
        await session.commit()
        await session.refresh(user_db)
    
    # Password handling
    update_password = bool(user_update.password)
    if update_password:
        user_update.password = get_password_hash(user_update.password)
    
    if not update_password:
        user_update.password = user_db.password

    # Role handling
    if user_update.role_id:
        role_id, is_superuser = await get_user_role_and_admin_permission(session, user_update.role_id)
        user_update.role_id = role_id
        user_update.is_superuser = is_superuser
    
    # Update group relationship
    group_updated = False
    if user_update.group_id:
        group = await get_group_by_id(session, user_update.group_id)
        if not group:
            raise HTTPException(status_code=404, detail="Group not found")
        
        current_user_group = user_db.user_groups[0]
        current_user_group.group_id = user_update.group_id
        current_user_group.joined_at = datetime.now(timezone.utc)
        current_user_group.updated_at = datetime.now(timezone.utc)
        session.add(current_user_group)
        group_updated = True

    # Update user
    user_updated = await update_user(user_db, user_update, session, group_updated=group_updated)
    
    # Commit group changes if any
    if group_updated:
        await session.commit()
        await session.refresh(user_updated)
    
    # Build response
    user_dict = prepare_user_dict_response(user_updated)
    return UserRead(**user_dict)


@router.patch("/{user_id}/reset-password", response_model=UserRead)
async def reset_password(
        user_id: UUID,
        user_update: UserUpdate,
        user: CurrentActiveUser,
        session: DbSession,
) -> User:
    """Reset an user's password."""
    if user_id != user.id:
        raise HTTPException(status_code=400, detail="You can't change another user's password")

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if verify_password(user_update.password, user.password):
        raise HTTPException(status_code=400, detail="You can't use your current password")
    
    validate_user_info(user_update)

    new_password = get_password_hash(user_update.password)
    user.password = new_password
    user.updated_at = datetime.now(timezone.utc)

    await session.commit()
    await session.refresh(user)

    user_dict = prepare_user_dict_response(user)
    return UserRead(**user_dict)


@router.delete("/{user_id}")
async def delete_user(
        user_id: UUID,
        current_user: Annotated[User, Depends(get_current_active_superuser)],
        session: DbSession,
) -> dict:
    """Delete an user from the database permanently."""
    if not current_user.is_superuser:
        raise HTTPException(status_code=403, detail="Permission denied")

    if current_user.id == user_id:
        raise HTTPException(status_code=400, detail="You can't delete your own user account")

    user_db = await get_user_by_id(session, user_id)
    if not user_db:
        raise HTTPException(status_code=404, detail="User not found")

    # Hard delete the user
    await session.delete(user_db)
    await session.commit()

    return {"detail": "User deleted successfully."}
