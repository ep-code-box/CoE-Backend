from typing import Any, Dict

Event = Dict[str, Any]
Hint = Dict[str, Any]
