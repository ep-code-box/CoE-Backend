class UsageError(Exception):
    """Error in plugin usage."""

    __module__ = "builtins"
